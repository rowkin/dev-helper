/**
 * DevHelper - 公共工具函数（CSP 安全版）
 * 所有工具页面共享：Toast、复制、导航栏创建、主题切换、AI 设置
 * 注意：不能使用 onclick="" 内联事件，必须使用 addEventListener
 */

// ─── 浏览器原生运行兼容环境 Mock (供本地预览/截图使用) ─────────────────
if (typeof chrome === 'undefined') {
  window.chrome = {};
}
if (!chrome.runtime) {
  chrome.runtime = {
    getURL: function(path) {
      // 兼容从 pages/ 目录跳转其他页面的相对路径
      if (path.startsWith('pages/')) {
        return path.replace('pages/', '');
      }
      return path;
    }
  };
}
if (!chrome.tabs) {
  chrome.tabs = {
    create: function(opts) {
      if (opts && opts.url) {
        window.open(opts.url, '_blank');
      }
    }
  };
}
if (!chrome.storage) {
  chrome.storage = {
    local: {
      get: function(keys, callback) {
        const res = {};
        const keyList = Array.isArray(keys) ? keys : [keys];
        keyList.forEach(k => {
          const val = localStorage.getItem('mock-chrome-storage-' + k);
          if (val !== null) {
            try {
              res[k] = JSON.parse(val);
            } catch {
              res[k] = val;
            }
          }
        });
        if (callback) {
          callback(res);
        }
        return Promise.resolve(res);
      },
      set: function(items, callback) {
        Object.keys(items).forEach(k => {
          localStorage.setItem('mock-chrome-storage-' + k, JSON.stringify(items[k]));
        });
        if (callback) {
          callback();
        }
        return Promise.resolve();
      }
    }
  };
}

/* ==================== 主题管理 ==================== */

/**
 * 初始化主题（从 localStorage 读取用户偏好）
 * 默认为 light 模式
 */
function initTheme() {
  const manual = localStorage.getItem('devhelper-theme-manual') === 'true';
  let theme = 'light';
  if (manual) {
    theme = localStorage.getItem('devhelper-theme') || 'light';
  } else {
    const hour = new Date().getHours();
    theme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
    localStorage.setItem('devhelper-theme', theme);
  }
  document.documentElement.setAttribute('data-theme', theme);
  return theme;
}

/**
 * 切换 light / dark 主题
 */
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('devhelper-theme', next);
  localStorage.setItem('devhelper-theme-manual', 'true');

  // 同步到 chrome.storage（如果可用）
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.set({ 'devhelper-theme': next, 'devhelper-theme-manual': 'true' }).catch(() => {});
  }

  // 更新所有主题图标
  document.querySelectorAll('.theme-toggle-icon').forEach(el => {
    el.textContent = next === 'dark' ? '☀️' : '🌙';
  });
}

/* ==================== Toast 通知 ==================== */

/**
 * 显示 Toast 通知
 * @param {string} message
 * @param {'success'|'error'|'info'} type
 * @param {number} duration 毫秒
 */
function showToast(message, type = 'success', duration = 2500) {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = {
    success: '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>',
    error:   '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>',
    info:    '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>',
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  // innerHTML 中无事件处理器，CSP 安全
  toast.innerHTML = `${icons[type] || icons.info}<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 200);
  }, duration);
}

/* ==================== 复制工具 ==================== */

/**
 * 复制文本到剪贴板
 * @param {string} text
 * @param {HTMLElement|null} btn 触发复制的按钮（可选，提供视觉反馈）
 */
async function copyText(text, btn = null) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('已复制到剪贴板');
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>';
      btn.classList.add('copy-success');
      setTimeout(() => {
        btn.innerHTML = orig;
        btn.classList.remove('copy-success');
      }, 1800);
    }
  } catch {
    showToast('复制失败，请手动选择', 'error');
  }
}

/* ==================== 导航栏 ==================== */

const LOGO_SVG = `<svg viewBox="0 0 32 32" fill="none">
  <rect width="32" height="32" rx="8" fill="url(#ng)"/>
  <path d="M8 12L13 17L8 22M15 22H24" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  <defs>
    <linearGradient id="ng" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#6366f1"/>
      <stop offset="100%" stop-color="#8b5cf6"/>
    </linearGradient>
  </defs>
</svg>`;

/**
 * 创建统一导航栏（CSP 安全 - 所有事件用 addEventListener）
 * @param {string} toolName 当前工具名称
 */
function createNavbar(toolName) {
  // 初始化主题（在创建导航前确保主题已设置）
  const theme = initTheme();

  const navbar = document.createElement('nav');
  navbar.className = 'navbar';

  // 不使用 onclick="" 内联事件，只用结构 HTML
  navbar.innerHTML = `
    <div class="navbar-brand" id="navHome" role="button" tabindex="0">
      <div class="navbar-logo">${LOGO_SVG}</div>
      <span class="navbar-name">DevHelper</span>
    </div>
    <div class="navbar-divider"></div>
    <span class="navbar-title">${toolName}</span>
    <div class="navbar-spacer"></div>
    <div class="navbar-actions">
      <button class="btn btn-ghost btn-sm" id="navAIAssist" title="AI 助手">
        <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/></svg>
        AI 助手
      </button>
      <button class="btn btn-ghost btn-sm" id="navAISettings" title="AI 设置">
        <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
        AI 设置
      </button>
      <button class="theme-toggle" id="navThemeToggle" title="切换主题">
        <span class="theme-toggle-icon">${theme === 'dark' ? '☀️' : '🌙'}</span>
      </button>
    </div>`;

  document.body.prepend(navbar);

  // 所有事件用 addEventListener，CSP 安全
  // 点击品牌跳转至全景工具导航页
  navbar.querySelector('#navHome').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL('pages/index.html') });
    }
  });

  navbar.querySelector('#navAIAssist').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL('pages/ai-assistant.html') });
    }
  });

  navbar.querySelector('#navAISettings').addEventListener('click', showAISettingsModal);

  navbar.querySelector('#navThemeToggle').addEventListener('click', toggleTheme);
}

/* ==================== AI 设置模态框 ==================== */

/**
 * 显示 AI 设置模态框（CSP 安全）
 */
async function showAISettingsModal() {
  // 兼容：AI 服务可能未加载
  const config = (typeof DevHelperAI !== 'undefined') ? await DevHelperAI.getAIConfig() : {};
  const builtinAvailable = (typeof DevHelperAI !== 'undefined') ? await DevHelperAI.checkBuiltinAI() : false;

  let overlay = document.getElementById('aiSettingsOverlay');
  if (overlay) { overlay.remove(); }

  overlay = document.createElement('div');
  overlay.id = 'aiSettingsOverlay';
  overlay.className = 'modal-overlay';

  const box = document.createElement('div');
  box.className = 'modal-box';

  // 构造表单 DOM（不使用 onclick）
  const titleRow = document.createElement('div');
  titleRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:20px';

  const titleEl = document.createElement('h2');
  titleEl.style.cssText = 'font-size:17px;font-weight:700;color:var(--text-primary)';
  titleEl.textContent = '⚙️ AI 设置';

  const closeBtn = document.createElement('button');
  closeBtn.style.cssText = 'border:none;background:transparent;color:var(--text-secondary);cursor:pointer;font-size:22px;line-height:1;padding:0 4px';
  closeBtn.textContent = '×';
  closeBtn.addEventListener('click', () => overlay.remove());

  titleRow.appendChild(titleEl);
  titleRow.appendChild(closeBtn);

  // Provider 选择
  const providerGroup = document.createElement('div');
  providerGroup.className = 'form-group';
  const providerLabel = document.createElement('label');
  providerLabel.className = 'form-label';
  providerLabel.textContent = 'AI 服务商';
  const providerSelect = document.createElement('select');
  providerSelect.id = 'aiProvider';
  providerSelect.className = 'form-input form-select';

  const optBuiltin = document.createElement('option');
  optBuiltin.value = 'builtin';
  optBuiltin.textContent = `Chrome 内置 AI${builtinAvailable ? '' : '（不可用）'}`;
  optBuiltin.disabled = !builtinAvailable;
  if (config.provider === 'builtin') optBuiltin.selected = true;

  const optOpenAI = document.createElement('option');
  optOpenAI.value = 'openai';
  optOpenAI.textContent = '自定义（OpenAI 兼容）';
  if (config.provider !== 'builtin') optOpenAI.selected = true;

  providerSelect.appendChild(optBuiltin);
  providerSelect.appendChild(optOpenAI);
  providerGroup.appendChild(providerLabel);
  providerGroup.appendChild(providerSelect);

  // OpenAI 字段组
  const openaiFields = document.createElement('div');
  openaiFields.id = 'openaiFields';
  openaiFields.style.display = (config.provider === 'builtin') ? 'none' : '';

  const createField = (id, label, type, placeholder, value = '') => {
    const group = document.createElement('div');
    group.className = 'form-group';
    const lbl = document.createElement('label');
    lbl.className = 'form-label';
    lbl.textContent = label;
    const input = document.createElement('input');
    input.id = id;
    input.type = type;
    input.className = 'form-input';
    input.placeholder = placeholder;
    input.value = value;
    group.appendChild(lbl);
    group.appendChild(input);
    return group;
  };

  openaiFields.appendChild(createField('aiApiKey', 'API Key', 'password', '请输入 API Key', config.apiKey || ''));
  openaiFields.appendChild(createField('aiApiUrl', 'API URL', 'text', 'https://api.openai.com/v1/chat/completions', config.apiUrl || ''));
  openaiFields.appendChild(createField('aiModel', '模型名称', 'text', 'gpt-4o-mini', config.model || ''));

  const hint = document.createElement('p');
  hint.style.cssText = 'font-size:12px;color:var(--text-tertiary);margin-bottom:16px';
  hint.textContent = '支持任何 OpenAI Chat Completions 兼容 API（SiliconFlow、Azure 等）';
  openaiFields.appendChild(hint);

  // Provider 切换联动
  providerSelect.addEventListener('change', (e) => {
    openaiFields.style.display = e.target.value === 'builtin' ? 'none' : '';
  });

  // 保存按钮
  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.style.width = '100%';
  saveBtn.textContent = '保存设置';
  saveBtn.addEventListener('click', async () => {
    const provider = providerSelect.value;
    if (typeof DevHelperAI !== 'undefined') {
      await DevHelperAI.saveAIConfig({
        provider,
        apiKey:  box.querySelector('#aiApiKey')?.value || '',
        apiUrl:  box.querySelector('#aiApiUrl')?.value || 'https://api.openai.com/v1/chat/completions',
        model:   box.querySelector('#aiModel')?.value || 'gpt-4o-mini',
      });
    }
    showToast('AI 设置已保存');
    overlay.remove();
  });

  box.appendChild(titleRow);
  box.appendChild(providerGroup);
  box.appendChild(openaiFields);
  box.appendChild(saveBtn);

  overlay.appendChild(box);
  document.body.appendChild(overlay);

  // 点击遮罩关闭
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
}

/* ==================== AI 解读面板 ==================== */

/**
 * 在工具页面底部创建内嵌 AI 解读面板（CSP 安全）
 * @param {string} containerId 挂载容器 ID
 * @param {function} getContext 获取当前内容的函数
 * @param {string} systemPrompt 工具专属系统提示
 */
function createInlineAIPanel(containerId, getContext, systemPrompt) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const panel = document.createElement('div');
  panel.className = 'ai-inline-panel';

  const header = document.createElement('div');
  header.className = 'ai-inline-panel-header';

  const titleEl = document.createElement('div');
  titleEl.className = 'ai-inline-panel-title';
  titleEl.innerHTML = `<svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/></svg> AI 解读`;

  const btnGroup = document.createElement('div');
  btnGroup.style.cssText = 'display:flex;gap:6px';

  const runBtn = document.createElement('button');
  runBtn.className = 'btn btn-sm btn-primary';
  runBtn.style.cssText = 'font-size:11px;padding:4px 10px';
  runBtn.textContent = 'AI 解读';

  const closeBtn = document.createElement('button');
  closeBtn.className = 'btn btn-sm btn-ghost';
  closeBtn.style.cssText = 'font-size:11px;padding:4px 8px';
  closeBtn.textContent = '×';

  btnGroup.appendChild(runBtn);
  btnGroup.appendChild(closeBtn);
  header.appendChild(titleEl);
  header.appendChild(btnGroup);

  const resultDiv = document.createElement('div');
  resultDiv.className = 'ai-inline-panel-result';
  resultDiv.style.display = 'none';

  panel.appendChild(header);
  panel.appendChild(resultDiv);
  container.appendChild(panel);

  // 使用 addEventListener，CSP 安全
  runBtn.addEventListener('click', async () => {
    const context = getContext();
    if (!context?.trim()) {
      showToast('请先输入内容', 'info');
      return;
    }

    resultDiv.style.display = 'block';
    resultDiv.innerHTML = '<div class="loading-spinner" style="margin:0 auto"></div>';
    runBtn.disabled = true;
    runBtn.textContent = 'AI 分析中...';

    try {
      if (typeof DevHelperAI === 'undefined') {
        throw new Error('AI 服务未加载，请检查配置');
      }
      await DevHelperAI.callAI(systemPrompt, context, (chunk) => {
        resultDiv.innerHTML = renderInlineMarkdown(chunk);
      });
    } catch (err) {
      resultDiv.innerHTML = `<span style="color:var(--danger)">AI 调用失败：${err.message}</span>`;
      // 提供设置入口（使用 data 属性代替 onclick）
      const settingsBtn = document.createElement('button');
      settingsBtn.className = 'btn btn-sm btn-ghost';
      settingsBtn.style.marginTop = '8px';
      settingsBtn.textContent = '⚙️ 配置 AI 设置';
      settingsBtn.addEventListener('click', showAISettingsModal);
      resultDiv.appendChild(document.createElement('br'));
      resultDiv.appendChild(settingsBtn);
    } finally {
      runBtn.disabled = false;
      runBtn.textContent = 'AI 解读';
    }
  });

  closeBtn.addEventListener('click', () => {
    resultDiv.style.display = 'none';
  });
}

/* ==================== 轻量 Markdown 渲染（AI 解读面板专用）==================== */

/**
 * 将 Markdown 文本转换为安全 HTML（不依赖任何第三方库）
 * 支持：代码块、内联代码、粗/斜体、标题、有序/无序列表、分隔线、换行
 */
function renderInlineMarkdown(text) {
  if (!text) return '';

  // XSS 防御：转义原始 HTML 字符
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // 1. 代码块优先处理，防止内容被后续规则污染
  let r = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre style="background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:6px;padding:10px 12px;font-family:var(--mono-font,monospace);font-size:12px;overflow-x:auto;margin:8px 0;white-space:pre-wrap"><code>${esc(code.trim())}</code></pre>`);

  // 2. 标题
  r = r
    .replace(/^### (.+)$/gm, '<h3 style="font-size:13px;font-weight:700;margin:10px 0 4px;color:var(--text-primary)">$1</h3>')
    .replace(/^## (.+)$/gm,  '<h2 style="font-size:14px;font-weight:700;margin:12px 0 6px;color:var(--primary)">$1</h2>')
    .replace(/^# (.+)$/gm,   '<h1 style="font-size:16px;font-weight:800;margin:14px 0 8px;color:var(--primary)">$1</h1>');

  // 3. 有序列表（连续行）
  r = r.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^\d+\.\s*/, '')}</li>`).join('');
    return `<ol style="padding-left:20px;margin:6px 0">${items}</ol>`;
  });

  // 4. 无序列表（连续行）
  r = r.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^[-*]\s*/, '')}</li>`).join('');
    return `<ul style="padding-left:20px;margin:6px 0">${items}</ul>`;
  });

  // 5. 内联格式
  r = r
    .replace(/`([^`]+)`/g,   '<code style="background:var(--bg-elevated);padding:1px 5px;border-radius:3px;font-family:var(--mono-font,monospace);font-size:12px">$1</code>')
    .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g,  '<em>$1</em>')
    .replace(/~~(.+?)~~/g,  '<del>$1</del>');

  // 6. 分隔线
  r = r.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid var(--border-light);margin:12px 0">');

  // 7. 换行（非 HTML 标签前）
  r = r.replace(/\n(?!<)/g, '<br>');

  return r;
}

/* ==================== 全局暴露 ==================== */
window.showToast = showToast;
window.copyText = copyText;
window.createNavbar = createNavbar;
window.createInlineAIPanel = createInlineAIPanel;
window.showAISettingsModal = showAISettingsModal;
window.toggleTheme = toggleTheme;
window.initTheme = initTheme;
window.renderInlineMarkdown = renderInlineMarkdown;

/* ==================== 全局一键清空输入框交互 ==================== */

/**
 * 全局初始化一键清空输入框交互
 * 扫描页面所有非只读、非禁用的文本输入框和文本域，动态注入悬浮的“×”清空按钮
 */
function initGlobalClearButtons() {
  // 选取所有文本域及主要类型的文本输入框，并过滤出没有 type 属性的默认文本框
  const inputs = document.querySelectorAll(
    'textarea, input[type="text"], input[type="search"], input[type="url"], input[type="password"], input:not([type])'
  );
  
  inputs.forEach(el => {
    // 边界条件：只读、禁用、隐藏或声明了 no-clear 排除类的不做处理
    if (el.readOnly || el.disabled || el.type === 'hidden') return;
    if (el.classList.contains('no-clear')) return;
    
    // 边界条件：检查是否已经包裹过，防止在页面动态渲染时重复执行
    if (el.dataset.hasClear === 'true') return;
    const parent = el.parentElement;
    if (!parent) return;
    
    // 创建一键清空的外部 Wrapper 容器以保证清空按钮绝对在输入框内部定位
    const wrapper = document.createElement('div');
    wrapper.className = 'input-clear-wrapper';
    
    // 获取输入框的计算样式以复制关键布局属性，防止包裹后原本的弹性布局（Flex）失效
    const elStyle = window.getComputedStyle(el);
    
    // 1. 若输入框原本是 flex 的子项，使 wrapper 承接同样的 flex 特性以防容器尺寸塌陷
    if (elStyle.flex && elStyle.flex !== '0 1 auto' && elStyle.flex !== 'none') {
      wrapper.style.flex = elStyle.flex;
    } else {
      // 分别复制 flex-grow/shrink 属性，增强在复杂布局下的适配效果
      if (elStyle.flexGrow && elStyle.flexGrow !== '0') {
        wrapper.style.flexGrow = elStyle.flexGrow;
      }
      if (elStyle.flexShrink && elStyle.flexShrink !== '1') {
        wrapper.style.flexShrink = elStyle.flexShrink;
      }
    }
    
    // 2. 复制宽度、高度、外边距，并将 display 模式设为 input 的外显流布局样式
    wrapper.style.width = elStyle.width;
    wrapper.style.height = elStyle.height;
    wrapper.style.margin = elStyle.margin;
    wrapper.style.display = elStyle.display === 'block' ? 'block' : 'inline-block';
    
    // 3. 将输入框设为宽度 100% 且外边距清零，同时设为 block 消除行内元素基线留白导致的高度误差
    el.style.width = '100%';
    el.style.margin = '0';
    el.style.display = 'block';
    
    // 创建“×”悬浮清空按钮
    const clearBtn = document.createElement('span');
    clearBtn.className = 'input-clear-btn';
    clearBtn.innerHTML = '×';
    clearBtn.title = '清空内容';
    
    // 根据是 textarea 还是普通 input 决定应用的悬浮布局类
    const isTextarea = el.tagName.toLowerCase() === 'textarea';
    clearBtn.classList.add(isTextarea ? 'is-textarea' : 'is-input');
    
    // 避让机制：若为多行文本框稍微偏左以避开拉伸手柄；若为单行的 datetime-local 避开内置图标
    let rightOffset = 12;
    if (isTextarea) {
      rightOffset = 18; // 避开 textarea 右下角的拉伸手柄
    } else if (el.type === 'datetime-local') {
      rightOffset = 30; // 避开单行内置的调整/日历按钮
    } else {
      // 检查原父容器中是否含有浮动在右侧的功能按钮（例如“复制”按钮等）
      const hasSiblingBtn = parent.querySelector('.base-copy-btn') || 
                            parent.querySelector('.copy-btn') || 
                            parent.querySelector('button.btn') ||
                            parent.querySelector('.btn-icon') ||
                            el.classList.contains('base-input'); // 针对特殊的 base-input 类名做兜底判定
      if (hasSiblingBtn) {
        rightOffset = 48; // 偏移 48px 避开右侧复制/功能按钮位置
      }
    }
    clearBtn.style.right = rightOffset + 'px';
    
    // 智能防遮挡：动态检查并增大输入框的右内边距，确保长文本不会被清空按钮遮挡
    const currentPaddingRight = parseFloat(elStyle.paddingRight) || 0;
    const neededPadding = rightOffset + 18;
    if (currentPaddingRight < neededPadding) {
      el.style.paddingRight = neededPadding + 'px';
    }
    
    // 执行 DOM 包裹挂载操作，将 wrapper 插入原本 el 的位置，并把 el 和 clearBtn 装入 wrapper
    parent.insertBefore(wrapper, el);
    wrapper.appendChild(el);
    wrapper.appendChild(clearBtn);
    
    // 标记为已处理
    el.dataset.hasClear = 'true';
    
    // 控制清空按钮“有内容”状态的逻辑（配合 CSS :hover/:focus-within 实现智能显隐）
    const toggleBtn = () => {
      if (el.value.length > 0) {
        clearBtn.classList.add('has-value');
      } else {
        clearBtn.classList.remove('has-value');
      }
    };
    
    // 监听输入和变更事件以实时展示/隐藏清空按钮
    el.addEventListener('input', toggleBtn);
    el.addEventListener('change', toggleBtn);
    
    // 绑定清空事件
    clearBtn.addEventListener('click', (e) => {
      e.stopPropagation(); // 阻止事件冒泡
      el.value = '';       // 清空输入框内容
      toggleBtn();
      el.focus();          // 重新聚焦输入框
      
      // 关键逻辑：手动触发原生的 input 与 change 事件，以激活该输入框在对应页面上绑定的关联交互（如实时计算、转换）
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    });
    
    // 初始化时执行一次，以便在页面带入初始默认值时显示清空按钮
    toggleBtn();
  });
}

window.initGlobalClearButtons = initGlobalClearButtons;

// 页面 DOM 加载完成后自动触发初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGlobalClearButtons);
} else {
  initGlobalClearButtons();
}


