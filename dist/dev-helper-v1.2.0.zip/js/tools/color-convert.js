/**
 * 颜色转换工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('颜色转换');

  const presets = ['#6366f1','#8b5cf6','#ec4899','#ef4444','#f59e0b','#10b981','#06b6d4','#3b82f6','#1f2937','#ffffff','#000000','#f3f4f6'];

  function hexToRgb(hex) {
    return { r: parseInt(hex.slice(1, 3), 16), g: parseInt(hex.slice(3, 5), 16), b: parseInt(hex.slice(5, 7), 16) };
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    if (max === min) { h = s = 0; } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
        case g: h = ((b - r) / d + 2) / 6; break;
        case b: h = ((r - g) / d + 4) / 6; break;
      }
    }
    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  function updateColor(hex) {
    if (!/^#[0-9A-Fa-f]{6}$/.test(hex)) return;
    document.getElementById('colorPreview').style.background = hex;
    document.getElementById('colorPicker').value = hex;
    document.getElementById('hexInput').value = hex;

    const { r, g, b } = hexToRgb(hex);
    const { h, s, l } = rgbToHsl(r, g, b);

    const items = [
      { label: 'HEX', value: hex.toUpperCase() },
      { label: 'RGB', value: `rgb(${r}, ${g}, ${b})` },
      { label: 'RGBA', value: `rgba(${r}, ${g}, ${b}, 1)` },
      { label: 'HSL', value: `hsl(${h}, ${s}%, ${l}%)` },
      { label: 'CSS var', value: `--color: ${hex};` },
    ];
    const container = document.getElementById('colorResults');
    container.innerHTML = '';
    items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'color-item';
      div.innerHTML = `<div class="color-item-label">${item.label}</div><div class="color-item-value">${item.value}</div>`;
      div.addEventListener('click', () => copyText(item.value));
      container.appendChild(div);
    });
  }

  document.getElementById('colorPicker').addEventListener('input', e => updateColor(e.target.value));
  document.getElementById('hexInput').addEventListener('input', e => {
    let v = e.target.value.trim();
    if (!v.startsWith('#')) v = '#' + v;
    if (/^#[0-9A-Fa-f]{6}$/.test(v)) updateColor(v);
  });

  const palette = document.getElementById('palette');
  presets.forEach(c => {
    const el = document.createElement('div');
    el.className = 'palette-color';
    el.style.cssText = `width:32px;height:32px;border-radius:var(--radius-sm);background:${c};cursor:pointer;border:2px solid transparent;transition:all .2s`;
    el.title = c;
    el.addEventListener('click', () => updateColor(c));
    el.addEventListener('mouseenter', () => { el.style.borderColor = 'var(--primary)'; el.style.transform = 'scale(1.15)'; });
    el.addEventListener('mouseleave', () => { el.style.borderColor = 'transparent'; el.style.transform = 'scale(1)'; });
    palette.appendChild(el);
  });

  updateColor('#6366f1');

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const hex = document.getElementById('hexInput').value;
      const rgb = Array.from(document.querySelectorAll('#colorResults .color-item-value')).find(el => el.textContent.startsWith('rgb'))?.textContent || '';
      const hsl = Array.from(document.querySelectorAll('#colorResults .color-item-value')).find(el => el.textContent.startsWith('hsl'))?.textContent || '';
      return `HEX: ${hex}\nRGB: ${rgb}\nHSL: ${hsl}`;
    },
    'You are a design and color theory expert. Analyze the selected color (HEX, RGB, HSL): suggest beautiful matching color palettes (complementary, analogous, triadic), explain the psychological effect of this color, and provide UI design best practices. Reply in Chinese.'
  );
})();
