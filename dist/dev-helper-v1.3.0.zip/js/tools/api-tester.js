/**
 * API 调试工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('API 调试');

  let lastResponse = null;
  const customHeaders = [];
  const customParams = [];

  // 请求面板标签切换
  document.querySelectorAll('[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    });
  });

  // 响应面板标签切换
  document.querySelectorAll('[data-res-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-res-tab]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      ['resBodyPanel', 'resHeadersPanel', 'resAiPanel'].forEach(id => {
        document.getElementById(id).style.display = 'none';
      });
      const tabMap = { body: 'resBodyPanel', headers: 'resHeadersPanel', ai: 'resAiPanel' };
      document.getElementById(tabMap[btn.dataset.resTab]).style.display = 'block';
    });
  });

  function addKvRow(containerId, list, ph1 = 'Key', ph2 = 'Value') {
    const container = document.getElementById(containerId);
    const row = document.createElement('div');
    row.className = 'kv-row';
    const entry = { key: '', value: '' };
    list.push(entry);
    const k = document.createElement('input');
    k.className = 'kv-input';
    k.placeholder = ph1;
    k.addEventListener('input', e => { entry.key = e.target.value; });
    const v = document.createElement('input');
    v.className = 'kv-input';
    v.placeholder = ph2;
    v.addEventListener('input', e => { entry.value = e.target.value; });
    const del = document.createElement('button');
    del.className = 'kv-del';
    del.textContent = '×';
    del.addEventListener('click', () => {
      const idx = list.indexOf(entry);
      if (idx > -1) list.splice(idx, 1);
      row.remove();
    });
    row.appendChild(k);
    row.appendChild(v);
    row.appendChild(del);
    container.appendChild(row);
  }

  document.getElementById('btnAddHeader').addEventListener('click', () => addKvRow('headersList', customHeaders));
  document.getElementById('btnAddParam').addEventListener('click', () => addKvRow('paramsList', customParams, 'Param', 'Value'));

  document.getElementById('btnFormatBody').addEventListener('click', () => {
    try {
      const v = document.getElementById('bodyInput').value.trim();
      document.getElementById('bodyInput').value = JSON.stringify(JSON.parse(v), null, 2);
    } catch { showToast('非合法 JSON', 'error'); }
  });

  function escHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function renderResponse(res) {
    const statusClass = res.status < 300 ? 'status-2xx' : res.status < 500 ? 'status-4xx' : 'status-5xx';
    const resHeader = document.getElementById('resHeader');
    resHeader.innerHTML = `
      <span class="status-badge ${statusClass}">${res.status} ${res.statusText}</span>
      <span class="res-time">${res.elapsed}ms</span>
      <div style="flex:1"></div>`;
    const copyResBtn = document.createElement('button');
    copyResBtn.className = 'btn btn-ghost btn-sm';
    copyResBtn.textContent = '复制';
    copyResBtn.addEventListener('click', () => copyText(document.getElementById('resPre')?.textContent || ''));
    resHeader.appendChild(copyResBtn);

    let display = res.body;
    try { display = JSON.stringify(JSON.parse(res.body), null, 2); } catch { /* not JSON */ }
    document.getElementById('resBodyPanel').innerHTML = `<pre class="res-pre" id="resPre">${escHtml(display)}</pre>`;

    const hList = Object.entries(res.headers).map(([k, v]) => `<div><span class="key">${k}</span>: ${v}</div>`).join('');
    document.getElementById('resHeadersList').innerHTML = hList;

    const aiBtn = document.getElementById('btnAiAnalyze');
    if (aiBtn) aiBtn.disabled = false;
  }

  async function sendRequest() {
    const url = document.getElementById('urlInput').value.trim();
    if (!url) { showToast('请输入请求 URL', 'info'); return; }

    const method = document.getElementById('method').value;
    const headers = {};

    if (document.getElementById('chkJson').checked) headers['Content-Type'] = 'application/json';
    if (document.getElementById('chkAuth').checked) {
      const token = document.getElementById('authToken').value.trim();
      if (token) headers['Authorization'] = `Bearer ${token}`;
    }
    customHeaders.forEach(h => { if (h.key) headers[h.key] = h.value; });

    let finalUrl = url;
    const params = customParams.filter(p => p.key);
    if (params.length) {
      const qs = params.map(p => `${encodeURIComponent(p.key)}=${encodeURIComponent(p.value)}`).join('&');
      finalUrl += (url.includes('?') ? '&' : '?') + qs;
    }

    const bodyVal = document.getElementById('bodyInput').value.trim();
    const body = method !== 'GET' && method !== 'HEAD' && bodyVal ? bodyVal : undefined;

    const btn = document.getElementById('btnSend');
    const bar = document.getElementById('loadingBar');
    btn.disabled = true;
    btn.textContent = '请求中...';
    bar.style.width = '60%';

    const start = Date.now();
    try {
      const res = await fetch(finalUrl, { method, headers, body });
      const elapsed = Date.now() - start;
      const text = await res.text();
      lastResponse = {
        status: res.status,
        statusText: res.statusText,
        elapsed,
        headers: Object.fromEntries(res.headers.entries()),
        body: text,
      };
      renderResponse(lastResponse);
    } catch (err) {
      document.getElementById('resBodyPanel').innerHTML = `<div style="color:var(--danger);padding:20px;font-family:var(--mono-font);font-size:13px">请求失败: ${err.message}</div>`;
      showToast('请求失败: ' + err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '发送';
      bar.style.width = '0';
    }
  }

  document.getElementById('btnSend').addEventListener('click', sendRequest);

  // Enter 键发送
  document.getElementById('urlInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') sendRequest();
  });

  // AI 分析响应
  const aiAnalyzeBtn = document.getElementById('btnAiAnalyze');
  if (aiAnalyzeBtn) {
    aiAnalyzeBtn.addEventListener('click', async () => {
      if (!lastResponse) return;
      const content = document.getElementById('aiResContent');
      aiAnalyzeBtn.disabled = true;
      aiAnalyzeBtn.textContent = 'AI 分析中...';
      const ctx = `HTTP ${document.getElementById('method').value} ${document.getElementById('urlInput').value}\nStatus: ${lastResponse.status}\nResponse Headers: ${JSON.stringify(lastResponse.headers, null, 2)}\nResponse Body: ${lastResponse.body.slice(0, 3000)}`;
      try {
        content.innerHTML = '<div class="loading-spinner" style="margin:20px auto"></div>';
        await DevHelperAI.callAI(
          '你是一个 API 调试专家。请分析以下 HTTP 响应：解释数据结构，指出可能存在的异常或错误，对非 200 的状态码给出修复建议，并提示安全隐患。请务必使用简体中文回答，若有英文术语或代码，支持双语对照形式展示。',
          ctx,
          chunk => {
            content.innerHTML = chunk.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
          }
        );
      } catch (err) {
        content.innerHTML = `<span style="color:var(--danger)">AI 调用失败: ${err.message}</span>`;
      } finally {
        aiAnalyzeBtn.disabled = false;
        aiAnalyzeBtn.textContent = 'AI 分析响应';
      }
    });
  }
})();
