/**
 * 二维码工具 - 业务逻辑脚本（基于本地 qrcode.min.js）
 */
(function () {
  'use strict';

  createNavbar('二维码工具');

  // 防抖定时器句柄，用于输入文本时的自动实时生成
  let autoTimer;

  /**
   * 使用本地 qrcode.min.js 在隐藏容器生成二维码，并通过 Canvas 绘制自定义背景与留白边距
   * @param {string} text 二维码载荷文本
   * @param {number} size 二维码核心矩阵大小（不含留白）
   * @param {string} colorDark 前景色 Hex 字符串
   * @param {string} colorLight 背景色 Hex 字符串
   * @param {string} ecLevel 纠错级别 L/M/Q/H
   * @param {number} padding 留白边距大小（像素值）
   * @returns {Promise<HTMLCanvasElement>} 返回带有留白与边距的高清 Canvas 元素
   */
  function drawQRCodeLocal(text, size, colorDark, colorLight, ecLevel, padding) {
    return new Promise((resolve, reject) => {
      // 创建隐藏的临时 DOM 节点用于接收 QRCode 库的同步输出
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.width = size + 'px';
      tempDiv.style.height = size + 'px';
      document.body.appendChild(tempDiv);

      try {
        const levelMap = {
          L: QRCode.CorrectLevel.L,
          M: QRCode.CorrectLevel.M,
          Q: QRCode.CorrectLevel.Q,
          H: QRCode.CorrectLevel.H
        };

        // 实例化 QRCode 库
        new QRCode(tempDiv, {
          text: text,
          width: size,
          height: size,
          colorDark: colorDark,
          colorLight: colorLight,
          correctLevel: levelMap[ecLevel] || QRCode.CorrectLevel.M
        });

        // 延迟一小段时间等待库内部 Canvas 或 Image 写入完成
        setTimeout(() => {
          try {
            const qrCanvas = tempDiv.querySelector('canvas');
            const qrImg = tempDiv.querySelector('img');
            const targetCanvas = document.createElement('canvas');
            
            // 计算外包留白后的最终画布分辨率
            const paddingPx = Math.round(padding);
            const totalSize = size + paddingPx * 2;
            targetCanvas.width = totalSize;
            targetCanvas.height = totalSize;

            const ctx = targetCanvas.getContext('2d');
            
            // 1. 先用用户设定的背景色铺满整张画布，作为留白处的背景底色
            ctx.fillStyle = colorLight;
            ctx.fillRect(0, 0, totalSize, totalSize);

            // 2. 将库生成的二维码主体矩阵居中绘制到画布上
            if (qrCanvas) {
              ctx.drawImage(qrCanvas, paddingPx, paddingPx, size, size);
              document.body.removeChild(tempDiv);
              resolve(targetCanvas);
            } else if (qrImg) {
              // 针对不支持直接 Canvas 输出的环境，回退渲染生成的 IMG 数据
              if (qrImg.complete) {
                ctx.drawImage(qrImg, paddingPx, paddingPx, size, size);
                document.body.removeChild(tempDiv);
                resolve(targetCanvas);
              } else {
                qrImg.onload = () => {
                  ctx.drawImage(qrImg, paddingPx, paddingPx, size, size);
                  document.body.removeChild(tempDiv);
                  resolve(targetCanvas);
                };
                qrImg.onerror = () => {
                  document.body.removeChild(tempDiv);
                  reject(new Error('图片加载失败'));
                };
              }
            } else {
              document.body.removeChild(tempDiv);
              reject(new Error('生成二维码节点失败'));
            }
          } catch (err) {
            if (tempDiv.parentNode) document.body.removeChild(tempDiv);
            reject(err);
          }
        }, 50);
      } catch (err) {
        if (tempDiv.parentNode) document.body.removeChild(tempDiv);
        reject(err);
      }
    });
  }

  /**
   * 读取当前配置面板上的全部参数并执行二维码生成渲染
   */
  async function doGenerate() {
    const text = document.getElementById('qrInput').value.trim();
    // 内容为空时不执行生成动作，以防页面初始化或清空时报错
    if (!text) { return; }

    const ecLevel = document.getElementById('ecLevel').value;
    const colorDark = document.getElementById('colorDark').value;
    const colorLight = document.getElementById('colorLight').value;
    const padding = parseInt(document.getElementById('qrPadding').value) || 0;

    // 二维码核心尺寸，不含留白边距
    const size = 240;
    const container = document.getElementById('qrWrap');
    
    // 设置加载态
    container.innerHTML = '<div style="color:var(--text-tertiary);font-size:12px;text-align:center;padding:20px">正在生成...</div>';

    try {
      const canvas = await drawQRCodeLocal(text, size, colorDark, colorLight, ecLevel, padding);
      canvas.id = 'qrCanvas';
      canvas.style.maxWidth = '100%';
      canvas.style.maxHeight = '100%';
      canvas.style.objectFit = 'contain';
      
      container.innerHTML = '';
      container.appendChild(canvas);

      // 解锁下载和复制功能按钮
      document.getElementById('btnDownloadQR').disabled = false;
      document.getElementById('btnCopyQR').disabled = false;
    } catch (err) {
      container.innerHTML = `<div style="color:var(--danger);font-size:12px;text-align:center;padding:20px">生成失败: ${err.message}</div>`;
    }
  }

  // ----------------------------------------------------------------
  // 交互事件绑定与参数数据联动逻辑
  // ----------------------------------------------------------------

  // 1. “生成”按钮主动触发
  document.getElementById('btnGenQR').addEventListener('click', doGenerate);

  // 2. 纠错级别切换联动
  document.getElementById('ecLevel').addEventListener('change', doGenerate);

  // 3. 留白与边距滑块联动
  const paddingInput = document.getElementById('qrPadding');
  const paddingValSpan = document.getElementById('paddingVal');
  paddingInput.addEventListener('input', () => {
    paddingValSpan.textContent = paddingInput.value;
    doGenerate();
  });

  // 4. 留白快捷按钮事件委派
  document.querySelectorAll('.padding-preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const padVal = btn.dataset.padding;
      paddingInput.value = padVal;
      paddingValSpan.textContent = padVal;
      doGenerate();
    });
  });

  // 5. 颜色双向联动逻辑 (Color Picker <-> Hex Text Box)
  const colorDarkPicker = document.getElementById('colorDark');
  const colorDarkText = document.getElementById('colorDarkText');
  const colorLightPicker = document.getElementById('colorLight');
  const colorLightText = document.getElementById('colorLightText');

  // 前景色联动
  colorDarkPicker.addEventListener('input', () => {
    colorDarkText.value = colorDarkPicker.value.toUpperCase();
    doGenerate();
  });
  colorDarkText.addEventListener('input', () => {
    const val = colorDarkText.value.trim();
    // 正则表达式验证十六进制颜色值的合法性
    if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
      colorDarkPicker.value = val;
      doGenerate();
    }
  });

  // 背景色联动
  colorLightPicker.addEventListener('input', () => {
    colorLightText.value = colorLightPicker.value.toUpperCase();
    doGenerate();
  });
  colorLightText.addEventListener('input', () => {
    const val = colorLightText.value.trim();
    if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
      colorLightPicker.value = val;
      doGenerate();
    }
  });

  // 6. 预设渐变/双色主题按钮一键配置
  document.querySelectorAll('.preset-theme-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const darkColor = btn.dataset.dark;
      const lightColor = btn.dataset.light;
      
      // 更新前景色配置
      colorDarkPicker.value = darkColor;
      colorDarkText.value = darkColor.toUpperCase();
      
      // 更新背景色配置
      colorLightPicker.value = lightColor;
      colorLightText.value = lightColor.toUpperCase();
      
      doGenerate();
    });
  });

  // 7. 重置为默认设置
  document.getElementById('btnResetSettings').addEventListener('click', () => {
    // 恢复前景色默认黑
    colorDarkPicker.value = '#000000';
    colorDarkText.value = '#000000';
    
    // 恢复背景色默认白
    colorLightPicker.value = '#ffffff';
    colorLightText.value = '#ffffff';
    
    // 恢复留白默认10像素
    paddingInput.value = 10;
    paddingValSpan.textContent = 10;
    
    // 恢复纠错级别默认中级
    document.getElementById('ecLevel').value = 'M';
    
    doGenerate();
  });

  // 8. 输入框字符变动自动触发防抖生成
  document.getElementById('qrInput').addEventListener('input', () => {
    clearTimeout(autoTimer);
    autoTimer = setTimeout(() => {
      doGenerate();
    }, 600);
  });

  // 9. 下载高清 PNG 功能
  document.getElementById('btnDownloadQR').addEventListener('click', () => {
    const canvas = document.getElementById('qrCanvas');
    if (!canvas) return;
    const a = document.createElement('a');
    a.download = 'qrcode.png';
    a.href = canvas.toDataURL();
    a.click();
  });

  // 10. 复制二维码图片到系统剪贴板
  document.getElementById('btnCopyQR').addEventListener('click', () => {
    const canvas = document.getElementById('qrCanvas');
    if (!canvas) return;
    canvas.toBlob(async blob => {
      try {
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
        showToast('二维码已复制');
      } catch {
        showToast('复制失败', 'error');
      }
    });
  });

  // ----------------------------------------------------------------
  // 二维码解码核心逻辑
  // ----------------------------------------------------------------
  const decodeArea = document.getElementById('decodeArea');
  const decodeFileInput = document.getElementById('decodeFileInput');
  if (decodeArea && decodeFileInput) {
    decodeArea.addEventListener('click', () => decodeFileInput.click());
    decodeArea.addEventListener('dragover', e => {
      e.preventDefault();
      decodeArea.style.borderColor = 'var(--primary)';
    });
    decodeArea.addEventListener('dragleave', () => {
      decodeArea.style.borderColor = '';
    });
    decodeArea.addEventListener('drop', async e => {
      e.preventDefault();
      decodeArea.style.borderColor = '';
      const file = e.dataTransfer.files[0];
      if (file) await decodeQR(file);
    });
    decodeFileInput.addEventListener('change', async e => {
      if (e.target.files[0]) await decodeQR(e.target.files[0]);
    });
  }

  /**
   * 解码二维码图片并展示结果
   * @param {File} file 输入的二维码图片文件
   */
  async function decodeQR(file) {
    const resultEl = document.getElementById('decodeResult');
    if (!resultEl) return;
    resultEl.style.display = 'block';
    resultEl.textContent = '解码中...';
    if ('BarcodeDetector' in window) {
      try {
        const img = await createImageBitmap(file);
        const detector = new BarcodeDetector({ formats: ['qr_code'] });
        const barcodes = await detector.detect(img);
        resultEl.textContent = barcodes.length > 0 ? barcodes[0].rawValue : '未检测到有效二维码';
        if (barcodes.length > 0) showToast('解码成功');
      } catch (e) {
        resultEl.textContent = '解码失败: ' + e.message;
      }
    } else {
      resultEl.textContent = '当前浏览器不支持 BarcodeDetector API';
    }
  }

  // 载入内联 AI 助手面板
  createInlineAIPanel(
    'aiPanelMount',
    () => `二维码内容: ${document.getElementById('qrInput').value}`,
    'You are a QR code expert. Analyze the QR code content: identify the data type (URL, text, contact, WiFi), explain potential security risks, and provide best practices. Reply in Chinese.'
  );

  // ----------------------------------------------------------------
  // 初始化引导逻辑：若有初始内容，直接自动渲染一次
  // ----------------------------------------------------------------
  // 填充默认值到颜色输入文本框
  colorDarkText.value = colorDarkPicker.value.toUpperCase();
  colorLightText.value = colorLightPicker.value.toUpperCase();
  
  const initialText = document.getElementById('qrInput').value.trim();
  if (initialText) {
    doGenerate();
  }
})();
