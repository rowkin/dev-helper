/**
 * JWT 解析工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('JWT 解析');

  function b64d(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    try { return JSON.parse(atob(s)); } catch { return atob(s); }
  }

  function parseJWT() {
    const token = document.getElementById('jwtInput').value.trim();
    if (!token) { showToast('请输入 JWT Token', 'info'); return; }
    const parts = token.split('.');
    if (parts.length !== 3) { showToast('不是有效的 JWT 格式（需要3段）', 'error'); return; }

    const header = b64d(parts[0]);
    const payload = b64d(parts[1]);

    document.getElementById('partHeader').textContent = JSON.stringify(header, null, 2);
    document.getElementById('partPayload').textContent = JSON.stringify(payload, null, 2);
    document.getElementById('partSig').textContent = parts[2].slice(0, 40) + '...\n（签名需服务端验证）';

    // 有效期检测
    const now = Math.floor(Date.now() / 1000);
    const exp = payload.exp;
    const iat = payload.iat;
    const badgeEl = document.getElementById('validBadge');
    if (!exp) {
      badgeEl.innerHTML = '<span class="valid-badge valid-yes">⚠️ 无过期时间</span>';
    } else if (exp < now) {
      const ago = Math.floor((now - exp) / 60);
      badgeEl.innerHTML = `<span class="valid-badge valid-no">❌ 已过期（${ago} 分钟前）</span>`;
    } else {
      const left = Math.floor((exp - now) / 60);
      badgeEl.innerHTML = `<span class="valid-badge valid-yes">✅ 有效（剩余 ${left} 分钟）</span>`;
    }

    const infoItems = [
      { label: '算法', value: (typeof header === 'object' ? header.alg : '-') || '-' },
      { label: '类型', value: (typeof header === 'object' ? header.typ : '-') || '-' },
      { label: '签发者', value: payload.iss || '-' },
      { label: '受众', value: payload.aud || '-' },
      { label: '签发时间', value: iat ? new Date(iat * 1000).toLocaleString('zh-CN') : '-' },
      { label: '过期时间', value: exp ? new Date(exp * 1000).toLocaleString('zh-CN') : '无限制' },
    ];
    document.getElementById('jwtInfo').innerHTML = infoItems.map(i =>
      `<div class="info-card"><div class="info-label">${i.label}</div><div class="info-value">${i.value}</div></div>`
    ).join('');

    document.getElementById('resultPanel').style.display = '';
  }

  document.getElementById('btnParse').addEventListener('click', parseJWT);

  document.getElementById('btnSample').addEventListener('click', () => {
    document.getElementById('jwtInput').value = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkRldkhlbHBlciIsImlhdCI6MTUxNjIzOTAyMiwiZXhwIjo5OTk5OTk5OTk5fQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
    parseJWT();
  });

  // 自动解析（当 token 完整时）
  document.getElementById('jwtInput').addEventListener('input', () => {
    if (document.getElementById('jwtInput').value.split('.').length === 3) parseJWT();
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const payload = document.getElementById('partPayload').textContent;
      const header = document.getElementById('partHeader').textContent;
      return `JWT Header: ${header}\nJWT Payload: ${payload}`;
    },
    'You are a security expert. Analyze this JWT: explain the claims in the payload, identify security issues (weak algorithm, missing claims, sensitive data exposure), check expiration policy, and suggest best practices. Reply in Chinese.'
  );
})();
