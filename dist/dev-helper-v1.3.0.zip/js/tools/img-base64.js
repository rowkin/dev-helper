/**
 * 图片与 Base64 互转逻辑（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('图片转 BASE64');

  // 左侧转 Base64 变量
  const fileInput = document.getElementById('fileInput');
  const dropZone = document.getElementById('dropZone');
  const imagePreviewContainer = document.getElementById('imagePreviewContainer');
  const imagePreview = document.getElementById('imagePreview');
  const imageInfo = document.getElementById('imageInfo');
  const outputBase64 = document.getElementById('outputBase64');
  const btnCopy = document.getElementById('btnCopy');
  const btnClear = document.getElementById('btnClear');
  
  let currentDataUrl = ''; // 缓存当前图片的 Data URL
  let currentFile = null;

  // 右侧还原变量
  const inputBase64 = document.getElementById('inputBase64');
  const restorePreviewContainer = document.getElementById('restorePreviewContainer');
  const restorePreview = document.getElementById('restorePreview');
  const btnRestore = document.getElementById('btnRestore');
  const btnDownload = document.getElementById('btnDownload');
  const btnClearRestore = document.getElementById('btnClearRestore');

  // ---- 图片转 Base64 逻辑 ----
  
  // 触发选择文件
  dropZone.addEventListener('click', () => fileInput.click());

  // 拖拽文件进入
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleImageFile(files[0]);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleImageFile(e.target.files[0]);
    }
  });

  // 处理图片文件
  function handleImageFile(file) {
    if (!file.type.startsWith('image/')) {
      alert('请上传图片格式的文件！');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('图片大小不能超过 5MB！');
      return;
    }

    currentFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      currentDataUrl = e.target.result;
      
      // 更新预览
      imagePreview.src = currentDataUrl;
      imagePreviewContainer.style.display = 'flex';
      dropZone.style.display = 'none';

      // 获取图片像素尺寸
      const img = new Image();
      img.onload = () => {
        const sizeKb = (file.size / 1024).toFixed(1);
        imageInfo.textContent = `尺寸: ${img.width} × ${img.height} px | 大小: ${sizeKb} KB | 格式: ${file.type.split('/')[1].toUpperCase()}`;
      };
      img.src = currentDataUrl;

      // 生成 Base64
      updateBase64Output();
      
      // 启用按钮
      btnCopy.disabled = false;
      btnClear.disabled = false;
    };
    reader.readAsDataURL(file);
  }

  // 根据选中的格式格式化输出 Base64
  function updateBase64Output() {
    if (!currentDataUrl) return;

    const format = document.querySelector('input[name="outFormat"]:checked').value;
    let result = '';

    if (format === 'uri') {
      result = currentDataUrl;
    } else if (format === 'raw') {
      result = currentDataUrl.split(',')[1] || '';
    } else if (format === 'img') {
      result = `<img src="${currentDataUrl}" alt="DevHelper Base64 Image" />`;
    } else if (format === 'css') {
      result = `background-image: url("${currentDataUrl}");`;
    }

    outputBase64.value = result;
  }

  // 监听格式选项切换
  document.querySelectorAll('input[name="outFormat"]').forEach(radio => {
    radio.addEventListener('change', updateBase64Output);
  });

  // 复制结果
  btnCopy.addEventListener('click', () => {
    outputBase64.select();
    document.execCommand('copy');
    const oldText = btnCopy.textContent;
    btnCopy.textContent = '已复制！';
    btnCopy.classList.add('btn-success');
    setTimeout(() => {
      btnCopy.textContent = oldText;
      btnCopy.classList.remove('btn-success');
    }, 1500);
  });

  // 清空左侧
  btnClear.addEventListener('click', () => {
    fileInput.value = '';
    currentDataUrl = '';
    currentFile = null;
    outputBase64.value = '';
    imagePreview.src = '';
    imagePreviewContainer.style.display = 'none';
    dropZone.style.display = 'flex';
    btnCopy.disabled = true;
    btnClear.disabled = true;
  });

  // ---- Base64 还原图片 逻辑 ----
  
  let originalWidth = 0;
  let originalHeight = 0;
  let originalRatio = 1;
  let isRatioLocked = true;

  const downloadSizeConfig = document.getElementById('downloadSizeConfig');
  const downloadWidth = document.getElementById('downloadWidth');
  const downloadHeight = document.getElementById('downloadHeight');
  const btnResetSize = document.getElementById('btnResetSize');
  const btnLockRatio = document.getElementById('btnLockRatio');
  const lockIcon = document.getElementById('lockIcon');

  // 图片成功渲染预览后，读取原始物理尺寸及纵横比并启用面板
  restorePreview.addEventListener('load', () => {
    originalWidth = restorePreview.naturalWidth || 0;
    originalHeight = restorePreview.naturalHeight || 0;
    if (originalWidth && originalHeight) {
      originalRatio = originalWidth / originalHeight;
      downloadWidth.value = originalWidth;
      downloadHeight.value = originalHeight;
      downloadSizeConfig.style.display = 'flex';
    }
  });

  // 切换比例锁状态
  btnLockRatio.addEventListener('click', () => {
    isRatioLocked = !isRatioLocked;
    if (isRatioLocked) {
      btnLockRatio.style.color = 'var(--primary)';
      btnLockRatio.title = '锁定宽高比';
      lockIcon.innerHTML = '<path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd" />';
    } else {
      btnLockRatio.style.color = 'var(--text-tertiary)';
      btnLockRatio.title = '自由宽高比';
      lockIcon.innerHTML = '<path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5 5 0 0010 2z" />';
    }
  });

  // 宽度修改联动高度
  downloadWidth.addEventListener('input', () => {
    if (isRatioLocked && originalRatio) {
      const val = parseInt(downloadWidth.value);
      if (val > 0) {
        downloadHeight.value = Math.round(val / originalRatio);
      }
    }
  });

  // 高度修改联动宽度
  downloadHeight.addEventListener('input', () => {
    if (isRatioLocked && originalRatio) {
      const val = parseInt(downloadHeight.value);
      if (val > 0) {
        downloadWidth.value = Math.round(val * originalRatio);
      }
    }
  });

  // 一键重置物理原尺寸
  btnResetSize.addEventListener('click', () => {
    if (originalWidth && originalHeight) {
      downloadWidth.value = originalWidth;
      downloadHeight.value = originalHeight;
    }
  });
  
  btnRestore.addEventListener('click', () => {
    let rawInput = inputBase64.value.trim();
    if (!rawInput) {
      alert('请先输入 Base64 数据！');
      return;
    }

    // 剔除可能存在的 html 或 css 包装
    if (rawInput.startsWith('<img') && rawInput.includes('src=')) {
      const match = rawInput.match(/src="([^"]+)"/);
      if (match) rawInput = match[1];
    } else if (rawInput.startsWith('background-image:') || rawInput.includes('url(')) {
      const match = rawInput.match(/url\("?([^"\)]+)"?\)/);
      if (match) rawInput = match[1];
    }

    let finalDataUrl = rawInput;

    // 如果不带前缀，尝试根据首字母特征补齐
    if (!rawInput.startsWith('data:image/')) {
      let mime = 'image/png'; // 默认 png
      if (rawInput.startsWith('iVBORw')) mime = 'image/png';
      else if (rawInput.startsWith('/9j/')) mime = 'image/jpeg';
      else if (rawInput.startsWith('R0lGOD')) mime = 'image/gif';
      else if (rawInput.startsWith('UklGR')) mime = 'image/webp';
      else if (rawInput.startsWith('<svg') || rawInput.startsWith('PHN2Z')) mime = 'image/svg+xml';
      
      finalDataUrl = `data:${mime};base64,${rawInput}`;
    }

    // 渲染预览
    restorePreview.src = finalDataUrl;
    restorePreviewContainer.style.display = 'flex';
    btnDownload.disabled = false;
  });

  // 自定义缩放/原图高质量下载
  btnDownload.addEventListener('click', () => {
    const dataUrl = restorePreview.src;
    if (!dataUrl) return;

    const targetWidth = parseInt(downloadWidth.value) || originalWidth;
    const targetHeight = parseInt(downloadHeight.value) || originalHeight;

    // 识别拓展名及 MIME
    let ext = 'png';
    let mime = 'image/png';
    const mimeMatch = dataUrl.match(/data:(image\/[a-zA-Z+.-]+);/);
    if (mimeMatch) {
      mime = mimeMatch[1];
      const subExt = mime.split('/')[1];
      ext = subExt === 'svg+xml' ? 'svg' : subExt;
    }

    // 如果是原图比例尺寸，直接下载以保留原始图像的高保真质量
    if (targetWidth === originalWidth && targetHeight === originalHeight) {
      downloadFile(dataUrl, `devhelper_restore_${Date.now()}.${ext}`);
    } else {
      // 尺寸被自定义修改，使用离屏 canvas 进行重绘和大小比例变换
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(restorePreview, 0, 0, targetWidth, targetHeight);
      
      try {
        const scaledData = canvas.toDataURL(mime);
        downloadFile(scaledData, `devhelper_restore_${targetWidth}x${targetHeight}_${Date.now()}.${ext}`);
      } catch (e) {
        // canvas 导出失败则 fallback 至直接下载原图数据
        downloadFile(dataUrl, `devhelper_restore_${Date.now()}.${ext}`);
      }
    }
  });

  function downloadFile(href, name) {
    const link = document.createElement('a');
    link.href = href;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // 清空右侧
  btnClearRestore.addEventListener('click', () => {
    inputBase64.value = '';
    restorePreview.src = '';
    restorePreviewContainer.style.display = 'none';
    downloadSizeConfig.style.display = 'none';
    btnDownload.disabled = true;
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const base64Str = outputBase64.value || inputBase64.value;
      if (!base64Str) return '';
      const sizeKb = (base64Str.length * 0.75 / 1024).toFixed(1);
      return `Image Base64 Size: ${sizeKb} KB\nBase64 Character Length: ${base64Str.length}`;
    },
    'You are a frontend performance optimization expert. Analyze the Base64 image context: explain the pros and cons of using Base64 inline resource vs external URL resource based on the image size, and provide optimization recommendations (e.g. bundle size, page loading speed, HTTP requests). Reply in Chinese.'
  );
})();
