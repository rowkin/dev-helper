/**
 * 代码格式化工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('代码格式化');

  let currentLang = 'js';
  const samples = {
    js: 'function hello(name){if(name){return "Hello, "+name+"!"}else{return "Hello, World!"}}const result=hello("DevHelper");console.log(result);',
    css: 'body{margin:0;padding:0;font-family:sans-serif}.container{display:flex;flex-direction:column;align-items:center;min-height:100vh;background:#f4f5fb;color:#1e1f3b}',
    html: '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><title>DevHelper</title></head><body><div class="app"><h1>Hello DevHelper</h1><p>七九在线科技专属工具箱</p></div></body></html>',
    json: '{"name":"DevHelper","version":"1.0.0","tools":["json","encode","api","code"],"author":{"name":"七九在线科技","year":2026}}',
    sql: 'SELECT u.name,o.order_id,p.product_name FROM users u LEFT JOIN orders o ON u.id=o.user_id LEFT JOIN products p ON o.product_id=p.id WHERE u.status=\'active\' ORDER BY o.create_time DESC',
  };

  document.querySelectorAll('[data-lang]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-lang]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentLang = btn.dataset.lang;
      
      // 业务逻辑：切换 Tab 时，自动将输入框内容更新为对应语言的预置示例，并自动触发一次格式化展示
      document.getElementById('inputCode').value = samples[currentLang];
      formatCode();
      
      // 边界处理：自动收起可能处于开启状态的上一门语言的 AI 读代码面板
      document.getElementById('aiCodeResult').style.display = 'none';
      
      // 关键逻辑：手动分发原生 input 事件，以触发通用 js 绑定的“一键清空”按钮状态切换（has-value）
      document.getElementById('inputCode').dispatchEvent(new Event('input', { bubbles: true }));
    });
  });

  // 初始化：在页面加载完成时，默认载入当前语言（JS）的示例并自动进行格式化
  document.getElementById('inputCode').value = samples[currentLang];
  formatCode();
  document.getElementById('inputCode').dispatchEvent(new Event('input', { bubbles: true }));

  function formatJS(code) {
    let depth = 0, result = '', inString = false, strChar = '';
    const indent = () => '  '.repeat(depth);
    for (let i = 0; i < code.length; i++) {
      const c = code[i];
      if (inString) {
        result += c;
        if (c === strChar && code[i - 1] !== '\\') inString = false;
        continue;
      }
      if (c === '"' || c === "'" || c === '`') { inString = true; strChar = c; result += c; continue; }
      if (c === '{' || c === '[') { result += c + '\n'; depth++; result += indent(); }
      else if (c === '}' || c === ']') { depth = Math.max(0, depth - 1); result = result.trimEnd(); result += '\n' + indent() + c; }
      else if (c === ';') { result += c + '\n' + indent(); }
      else if (c === ',') { result += c + '\n' + indent(); }
      else { result += c; }
    }
    return result.trim();
  }

  function formatCSS(code) {
    return code.replace(/\s*\{\s*/g, ' {\n  ').replace(/;\s*/g, ';\n  ').replace(/\s*\}\s*/g, '\n}\n').replace(/,\s*(?=[^\s])/g, ',\n').trim();
  }

  function formatHTML(code) {
    let depth = 0;
    const selfClosing = /^<(br|hr|img|input|meta|link|area|base|col|embed|param|source|track|wbr)/i;
    return code.replace(/<\/?[^>]+>/g, tag => {
      const isClose = tag.startsWith('</');
      const isSelf = tag.endsWith('/>') || selfClosing.test(tag);
      if (isClose) depth = Math.max(0, depth - 1);
      const line = '\n' + '  '.repeat(depth) + tag;
      if (!isClose && !isSelf) depth++;
      return line;
    }).trim();
  }

  function formatSQL(sql) {
    const keywords = ['SELECT', 'FROM', 'WHERE', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN', 'JOIN', 'ON', 'AND', 'OR', 'ORDER BY', 'GROUP BY', 'HAVING', 'LIMIT', 'INSERT INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE FROM'];
    let result = sql;
    keywords.forEach(kw => {
      result = result.replace(new RegExp('\\b' + kw + '\\b', 'gi'), '\n' + kw);
    });
    return result.trim();
  }

  function formatCode() {
    const code = document.getElementById('inputCode').value.trim();
    if (!code) { showToast('请输入代码', 'info'); return; }
    const output = document.getElementById('outputCode');
    try {
      const formatters = { js: formatJS, css: formatCSS, html: formatHTML, json: c => JSON.stringify(JSON.parse(c), null, 2), sql: formatSQL };
      output.textContent = formatters[currentLang](code);
      showToast('格式化完成');
    } catch (e) {
      output.textContent = '格式化失败: ' + e.message;
      showToast('格式化失败', 'error');
    }
  }

  document.getElementById('btnFormat').addEventListener('click', formatCode);

  document.getElementById('btnClear').addEventListener('click', () => {
    document.getElementById('inputCode').value = '';
    document.getElementById('outputCode').textContent = '格式化结果将在这里显示...';
    document.getElementById('aiCodeResult').style.display = 'none';
  });

  document.getElementById('btnSample').addEventListener('click', () => {
    document.getElementById('inputCode').value = samples[currentLang];
    formatCode();
  });

  document.getElementById('btnPaste').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) { document.getElementById('inputCode').value = text; formatCode(); }
    } catch { showToast('无法读取剪贴板', 'error'); }
  });

  document.getElementById('btnCopy').addEventListener('click', e => {
    copyText(document.getElementById('outputCode').textContent, e.currentTarget);
  });

  document.getElementById('btnAiCode').addEventListener('click', async () => {
    const code = document.getElementById('inputCode').value || document.getElementById('outputCode').textContent;
    if (!code || code.includes('格式化结果将在')) { showToast('请先输入代码', 'info'); return; }
    const resultPanel = document.getElementById('aiCodeResult');
    const content = document.getElementById('aiCodeContent');
    resultPanel.style.display = '';
    content.innerHTML = '<div class="loading-spinner" style="margin:0 auto"></div>';
    const btn = document.getElementById('btnAiCode');
    btn.disabled = true;
    btn.textContent = 'AI 分析中...';
    try {
      await DevHelperAI.callAI(
        `你是一个资深的 ${currentLang.toUpperCase()} 开发专家。请分析以下代码：解释其功能、识别潜在的代码缺陷或运行风险、给出性能或重构改进建议、以及安全隐患检测。请务必使用简体中文分段落清晰回答，代码及专有名词部分支持以简体中文为主的双语对照展示。`,
        code.slice(0, 3000),
        chunk => { content.innerHTML = chunk.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>'); }
      );
    } catch (err) {
      content.innerHTML = `<span style="color:var(--danger)">AI 调用失败: ${err.message}</span>`;
    } finally {
      btn.disabled = false;
      btn.textContent = 'AI 读代码';
    }
  });

  document.getElementById('btnCloseAi').addEventListener('click', () => {
    document.getElementById('aiCodeResult').style.display = 'none';
  });
})();
