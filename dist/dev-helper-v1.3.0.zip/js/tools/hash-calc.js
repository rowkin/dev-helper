/**
 * 哈希计算工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('哈希计算');

  let lastResults = {};
  let currentMode = 'text';

  document.querySelectorAll('[data-mode]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-mode]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentMode = btn.dataset.mode;
      document.getElementById('textInput').style.display = currentMode === 'text' ? '' : 'none';
      document.getElementById('fileInput').style.display = currentMode === 'file' ? '' : 'none';
    });
  });

  const fileDropArea = document.getElementById('fileDropArea');
  const fileSelector = document.getElementById('fileSelector');
  if (fileDropArea && fileSelector) {
    fileDropArea.addEventListener('click', () => fileSelector.click());
    fileSelector.addEventListener('change', e => {
      const file = e.target.files[0];
      if (file) document.getElementById('fileName').textContent = `已选择: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
    });
  }

  async function calcHashFromBuffer(buf) {
    const algos = ['SHA-1', 'SHA-256', 'SHA-512'];
    const results = {};
    for (const algo of algos) {
      const hashBuf = await crypto.subtle.digest(algo, buf);
      results[algo] = Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    return results;
  }

  document.getElementById('btnCalc').addEventListener('click', async () => {
    let buf;
    if (currentMode === 'text') {
      const text = document.getElementById('textInput').value;
      if (!text) { showToast('请输入文本内容', 'info'); return; }
      buf = new TextEncoder().encode(text).buffer;
    } else {
      const file = fileSelector?.files[0];
      if (!file) { showToast('请先选择文件', 'info'); return; }
      buf = await file.arrayBuffer();
    }
    const panel = document.getElementById('resultPanel');
    panel.innerHTML = '<div class="loading-spinner" style="margin:20px auto"></div>';
    try {
      const results = await calcHashFromBuffer(buf);
      lastResults = results;
      panel.innerHTML = '';
      Object.entries(results).forEach(([algo, hash]) => {
        const item = document.createElement('div');
        item.className = 'hash-result-item';
        const label = document.createElement('span');
        label.className = 'hash-label';
        label.textContent = algo;
        const value = document.createElement('span');
        value.className = 'hash-value';
        value.textContent = hash;
        const copyBtn = document.createElement('button');
        copyBtn.className = 'btn btn-ghost btn-sm btn-icon';
        copyBtn.title = '复制';
        copyBtn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>';
        copyBtn.addEventListener('click', e => copyText(hash, e.currentTarget));
        item.appendChild(label);
        item.appendChild(value);
        item.appendChild(copyBtn);
        panel.appendChild(item);
      });
    } catch (e) {
      panel.innerHTML = `<span style="color:var(--danger)">${e.message}</span>`;
    }
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => `哈希结果:\n${Object.entries(lastResults).map(([k, v]) => `${k}: ${v}`).join('\n')}`,
    'You are a cryptography expert. Analyze these hash values: explain the differences between SHA-1/SHA-256/SHA-512, their security levels, recommended use cases (file integrity, passwords, digital signatures), and current best practices. Reply in Chinese.'
  );
})();
