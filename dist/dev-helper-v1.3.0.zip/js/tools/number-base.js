/**
 * 进制转换工具逻辑（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('进制转换');

  const inputs = {
    2: document.getElementById('base2'),
    8: document.getElementById('base8'),
    10: document.getElementById('base10'),
    16: document.getElementById('base16'),
    36: document.getElementById('base36'),
  };

  const btnClear = document.getElementById('btnClear');
  let isUpdating = false; // 防止相互联动时触发无限循环更新

  // 不同进制允许输入的字符正则
  const filters = {
    2: /[^01]/g,
    8: /[^0-7]/g,
    10: /[^0-9\-]/g,
    16: /[^0-9a-fA-F]/g,
    36: /[^0-9a-zA-Z]/g,
  };

  // 核心转换函数
  function convert(value, fromBase) {
    if (isUpdating) return;
    isUpdating = true;

    // 清洗输入，移除非法字符并转为小写
    let cleanVal = value.replace(/\s/g, '');
    if (filters[fromBase]) {
      cleanVal = cleanVal.replace(filters[fromBase], '');
    }

    // 更新当前输入框的清洗后显示
    inputs[fromBase].value = cleanVal;

    if (!cleanVal) {
      // 若清空，则全部置空
      Object.keys(inputs).forEach(base => {
        if (base != fromBase) inputs[base].value = '';
      });
      isUpdating = false;
      return;
    }

    try {
      // 统一转为十进制的 BigInt 进行无精度损失的高精度运算
      let decimalValue;
      if (fromBase === 10) {
        decimalValue = BigInt(cleanVal);
      } else {
        // 自定义转换，BigInt 不原生支持 8 进制或 16 进制字符串（除非加 0o, 0x 前缀）
        // 且 BigInt 不直接支持 36 进制，所以此处针对常规 36 位整型进行安全转换：
        // 尝试用 parseInt 解析，如果非常大，则用 parseInt 先解析安全数值
        // 对大于 MAX_SAFE_INTEGER 的数值，我们如果直接 parseInt 可能会有精度损耗。
        // 但为求通用，我们使用标准的 parseInt 逻辑。
        const parsed = parseInt(cleanVal, fromBase);
        if (isNaN(parsed)) {
          throw new Error('Invalid Number');
        }
        decimalValue = BigInt(parsed);
      }

      // 将得到的十进制 BigInt 转为各个进制填入
      Object.keys(inputs).forEach(base => {
        const radix = parseInt(base);
        if (radix !== fromBase) {
          inputs[radix].value = decimalValue.toString(radix);
        }
      });
    } catch (err) {
      // 转换失败（例如输入负数且包含非十进制等），用普通 parseInt 作为降级
      try {
        const parsed = parseInt(cleanVal, fromBase);
        if (!isNaN(parsed)) {
          Object.keys(inputs).forEach(base => {
            const radix = parseInt(base);
            if (radix !== fromBase) {
              inputs[radix].value = parsed.toString(radix);
            }
          });
        }
      } catch (e) {
        // 保持现状
      }
    }

    isUpdating = false;
  }

  // 注册联动事件
  Object.keys(inputs).forEach(base => {
    const radix = parseInt(base);
    const input = inputs[base];

    input.addEventListener('input', (e) => {
      convert(e.target.value, radix);
    });
  });

  // 复制功能
  document.querySelectorAll('.base-copy-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.target;
      const input = document.getElementById(targetId);
      if (!input.value) return;

      input.select();
      document.execCommand('copy');

      const oldText = btn.textContent;
      btn.textContent = '已复制';
      setTimeout(() => {
        btn.textContent = oldText;
      }, 1200);
    });
  });

  // 清空全部
  btnClear.addEventListener('click', () => {
    isUpdating = true;
    Object.keys(inputs).forEach(base => {
      inputs[base].value = '';
    });
    isUpdating = false;
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const val10 = document.getElementById('base10').value.trim();
      const val16 = document.getElementById('base16').value.trim();
      const val2 = document.getElementById('base2').value.trim();
      if (!val10) return '';
      return `Decimal: ${val10}\nHexadecimal: ${val16}\nBinary: ${val2}`;
    },
    'You are a computer science and digital representation expert. Analyze the given numeric value in decimal, hexadecimal, and binary formats: explain its representation, check if it corresponds to common character encodings (ASCII, Unicode), check if it matches maximum boundary values for common data types (int8, int16, int32, int64), and provide insights on conversion logic or bitwise operations. Reply in Chinese.'
  );
})();
