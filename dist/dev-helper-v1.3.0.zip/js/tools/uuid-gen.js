/**
 * UUID / ID 生成器 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('UUID 生成器');

  let currentType = 'uuid';

  document.querySelectorAll('[data-type]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-type]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentType = btn.dataset.type;
    });
  });

  function genUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = crypto.getRandomValues(new Uint8Array(1))[0] & 15;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }

  function genNanoID(size = 21) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    const arr = crypto.getRandomValues(new Uint8Array(size));
    return Array.from(arr, v => chars[v % 64]).join('');
  }

  function genSnowflake() {
    const ts = BigInt(Date.now() - 1609459200000) << 22n;
    const seq = BigInt(crypto.getRandomValues(new Uint16Array(1))[0] % 4096);
    return String(ts | seq);
  }

  const generators = { uuid: genUUID, nanoid: genNanoID, snowflake: genSnowflake };

  function generate() {
    const count = Math.min(50, Math.max(1, parseInt(document.getElementById('countInput').value) || 5));
    const list = document.getElementById('resultList');
    list.innerHTML = '';
    for (let i = 0; i < count; i++) {
      const id = generators[currentType]();
      const item = document.createElement('div');
      item.className = 'uuid-item';
      item.innerHTML = `<span class="uuid-text">${id}</span>`;
      const copyBtn = document.createElement('button');
      copyBtn.className = 'btn btn-ghost btn-sm btn-icon';
      copyBtn.title = '复制';
      copyBtn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>';
      copyBtn.addEventListener('click', (e) => copyText(id, e.currentTarget));
      item.appendChild(copyBtn);
      list.appendChild(item);
    }
  }

  document.getElementById('btnGenerate').addEventListener('click', generate);
  document.getElementById('btnCopyAll').addEventListener('click', () => {
    const all = [...document.querySelectorAll('.uuid-text')].map(el => el.textContent).join('\n');
    if (all) copyText(all);
    else showToast('请先生成 ID', 'info');
  });

  // 初始生成
  generate();

  createInlineAIPanel(
    'aiPanelMount',
    () => `类型: ${currentType}\n生成的 ID 示例:\n${[...document.querySelectorAll('.uuid-text')].slice(0, 3).map(e => e.textContent).join('\n')}`,
    'You are a distributed systems expert. Explain the characteristics of the given ID type (UUID/NanoID/Snowflake): format, uniqueness guarantees, sortability, performance, and recommended use cases. Reply in Chinese.'
  );
})();
