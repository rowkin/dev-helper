/**
 * 正则测试工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('正则测试');

  const FLAGS = { g: true, i: true, m: false, s: false };

  document.querySelectorAll('[data-flag]').forEach(el => {
    el.addEventListener('click', () => {
      FLAGS[el.dataset.flag] = !FLAGS[el.dataset.flag];
      el.classList.toggle('on', FLAGS[el.dataset.flag]);
      testRegex();
    });
  });

  function getFlags() {
    return Object.entries(FLAGS).filter(([, v]) => v).map(([k]) => k).join('');
  }

  function escHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function testRegex() {
    const pattern = document.getElementById('regexInput').value;
    const text = document.getElementById('testText').value;
    if (!pattern || !text) return;

    const matchCount = document.getElementById('matchCount');
    try {
      const gFlags = 'g' + getFlags().replace('g', '');
      const matches = [...text.matchAll(new RegExp(pattern, gFlags))];
      matchCount.style.display = 'inline-flex';
      matchCount.style.cssText = 'display:inline-flex;align-items:center;gap:6px;padding:3px 10px;background:rgba(5,150,105,.12);color:var(--success);border-radius:20px;font-size:12px;font-weight:600';
      matchCount.textContent = `${matches.length} 个匹配`;

      if (matches.length > 0) {
        document.getElementById('matchPanel').style.display = '';
        document.getElementById('matchResult').innerHTML = matches.slice(0, 30).map((m, i) => {
          const groups = m.groups ? `<br><span style="color:var(--text-tertiary)">分组: ${JSON.stringify(m.groups)}</span>` : '';
          return `<div style="margin-bottom:6px;padding:8px 12px;background:var(--bg-elevated);border-radius:var(--radius-sm);border-left:3px solid var(--primary)">
            <span style="color:var(--primary);font-weight:600">#${i + 1}</span>
            &nbsp;<span style="color:var(--success);font-family:var(--mono-font)">${escHtml(m[0])}</span>
            <span style="color:var(--text-tertiary)">  @ ${m.index}</span>${groups}
          </div>`;
        }).join('');
      } else {
        document.getElementById('matchPanel').style.display = 'none';
      }
    } catch (e) {
      matchCount.style.cssText = 'display:inline-flex;align-items:center;padding:3px 10px;background:rgba(220,38,38,.12);color:var(--danger);border-radius:20px;font-size:12px';
      matchCount.textContent = '正则错误: ' + e.message;
    }
  }

  document.getElementById('btnTest').addEventListener('click', testRegex);
  document.getElementById('regexInput').addEventListener('input', testRegex);
  document.getElementById('testText').addEventListener('input', testRegex);
  document.getElementById('btnClear').addEventListener('click', () => {
    document.getElementById('testText').value = '';
    document.getElementById('matchPanel').style.display = 'none';
    document.getElementById('matchCount').style.display = 'none';
  });

  // 常用正则速查
  const QUICK_REGEXES = [
    { name: '手机号', pattern: '1[3-9]\\d{9}', desc: '中国大陆手机号' },
    { name: '邮箱', pattern: '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}', desc: '电子邮件地址' },
    { name: 'URL', pattern: 'https?://[^\\s]+', desc: 'HTTP/HTTPS 链接' },
    { name: 'IP 地址', pattern: '\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b', desc: 'IPv4 地址' },
    { name: '身份证', pattern: '\\d{17}[\\dX]', desc: '中国身份证号' },
    { name: '日期', pattern: '\\d{4}[-/]\\d{2}[-/]\\d{2}', desc: 'YYYY-MM-DD 格式' },
    { name: 'HTML 标签', pattern: '<[^>]+>', desc: 'HTML 标签' },
    { name: '中文字符', pattern: '[\\u4e00-\\u9fa5]+', desc: '连续中文字符' },
    { name: 'HEX 颜色', pattern: '#[0-9A-Fa-f]{3,6}', desc: 'CSS 十六进制颜色' },
  ];

  const qrGrid = document.getElementById('quickRegex');
  QUICK_REGEXES.forEach(r => {
    const el = document.createElement('div');
    el.className = 'qr-btn';
    el.innerHTML = `<div class="qr-name">${r.name}</div><div class="qr-pattern">/${r.pattern}/</div>`;
    el.title = r.desc;
    el.addEventListener('click', () => {
      document.getElementById('regexInput').value = r.pattern;
      testRegex();
    });
    qrGrid.appendChild(el);
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => `正则: /${document.getElementById('regexInput').value}/${getFlags()}\n测试文本: ${document.getElementById('testText').value.slice(0, 500)}`,
    'You are a regex expert. Analyze this regex: explain what it matches step by step, identify potential performance issues (catastrophic backtracking), suggest edge cases to test, and provide an improved version if needed. Reply in Chinese.'
  );
})();
