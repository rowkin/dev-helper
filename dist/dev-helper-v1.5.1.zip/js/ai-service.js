/**
 * DevHelper AI 服务模块
 * 统一管理 AI 调用，支持：
 * - Chrome 内置 AI (Gemini Nano)
 * - OpenAI 兼容接口（自定义 API URL + Key）
 */

// 宿主环境 Polyfill (保证在纯 Web 测试环境/非插件环境下也能正常运行与测试)
// 宿主环境 Polyfill (保证在纯 Web 测试环境/非插件环境下也能正常运行与测试)
if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
  window.chrome = {
    storage: {
      local: {
        get: async (keys) => {
          const res = {};
          const arrayKeys = Array.isArray(keys) ? keys : [keys];
          for (const k of arrayKeys) {
            try {
              res[k] = JSON.parse(localStorage.getItem(k)) || null;
            } catch(e) {
              res[k] = null;
            }
          }
          return res;
        },
        set: async (obj) => {
          for (const k in obj) {
            localStorage.setItem(k, JSON.stringify(obj[k]));
          }
        }
      }
    },
    tabs: {
      query: async () => [{ id: 1, url: 'https://79team.online', title: '七九在线科技主页' }]
    },
    scripting: {
      executeScript: async () => [{
        result: {
          title: '七九在线科技主页 - 测试Mock',
          url: 'https://79team.online',
          loadTime: '210ms',
          domCompleteTime: '180ms',
          performanceTiming: {
            navigationStart: Date.now() - 300,
            domComplete: Date.now() - 120,
            loadEventEnd: Date.now() - 90,
            domInteractive: Date.now() - 150,
            fetchStart: Date.now() - 290
          },
          bodyText: '这是通过非插件宿主 Mock 环境抓取的网页文本。网页包含网速分析、JWT 工具等全套开发能力，致力于提供极速智能的研发辅助。'
        }
      }]
    },
    runtime: {
      getURL: (path) => path
    }
  };

  // ─── 宿主环境 内置 AI Mock Polyfill (保证在非插件或不支持内置 AI 的环境依然可完美演示/测试) ───
  if (typeof window.ai === 'undefined') {
  window.ai = {
    languageModel: {
      capabilities: async () => ({ available: 'readily' }),
      create: async (opts) => {
        return {
          prompt: async (p) => `[Mock Chrome 内置 AI] 收到提示词 "${p}"，系统提示词 "${opts.systemPrompt || ''}"。`,
          promptStreaming: (p) => {
            const text = `[Mock Chrome 内置 AI 流式] 收到健康改善请求：\n1. 膳食营养：建议每日减少油脂摄入，以优质蛋白和蔬菜纤维为主；\n2. 运动计划：建议每周进行 3 次中等强度的有氧运动，结合适量力量练习。`;
            return {
              [Symbol.asyncIterator]() {
                let i = 0;
                return {
                  async next() {
                    i += 10;
                    if (i > text.length + 10) {
                      return { done: true };
                    }
                    await new Promise(r => setTimeout(r, 30));
                    return { value: text.slice(0, Math.min(i, text.length)), done: false };
                  }
                };
              }
            };
          },
          destroy: () => {}
        };
      }
    }
  };
}

  // 拦截全局 fetch，用于本地零成本闭环测试 Tool Calling 和 Stream
  const originalFetch = window.fetch;
  window.fetch = async function(url, options) {
    if (typeof url === 'string' && url.includes('/chat/completions')) {
      const body = JSON.parse(options.body || '{}');
      const messages = body.messages || [];
      const lastMessage = messages[messages.length - 1] || {};
      const isStreaming = !!body.stream;

      // 辅助函数：模拟 SSE content 响应
      const createStreamResponse = (text) => {
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          async start(controller) {
            const chunkSize = 6;
            for (let i = 0; i < text.length; i += chunkSize) {
              const slice = text.slice(i, i + chunkSize);
              const data = {
                choices: [{
                  delta: { content: slice }
                }]
              };
              controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
              await new Promise(r => setTimeout(r, 25));
            }
            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
            controller.close();
          }
        });
        return new Response(stream, { headers: { 'Content-Type': 'text/event-stream' } });
      };

      // 辅助函数：模拟 SSE tool_calls 响应
      const createStreamToolCallResponse = (funcName, argsObj) => {
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          async start(controller) {
            const data = {
              choices: [{
                delta: {
                  tool_calls: [{
                    index: 0,
                    id: 'call_mock_123',
                    type: 'function',
                    function: {
                      name: funcName,
                      arguments: ''
                    }
                  }]
                }
              }]
            };
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
            await new Promise(r => setTimeout(r, 30));

            const argsStr = JSON.stringify(argsObj);
            const chunkSize = 5;
            for (let i = 0; i < argsStr.length; i += chunkSize) {
              const slice = argsStr.slice(i, i + chunkSize);
              const dataArg = {
                choices: [{
                  delta: {
                    tool_calls: [{
                      index: 0,
                      function: {
                        arguments: slice
                      }
                    }]
                  }
                }]
              };
              controller.enqueue(encoder.encode(`data: ${JSON.stringify(dataArg)}\n\n`));
              await new Promise(r => setTimeout(r, 20));
            }

            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
            controller.close();
          }
        });
        return new Response(stream, { headers: { 'Content-Type': 'text/event-stream' } });
      };

      // 1. 判断是否已经是 Tool 执行完的第二轮对话
      const hasToolMessage = messages.some(m => m.role === 'tool');
      if (hasToolMessage) {
        const toolMsg = messages.find(m => m.role === 'tool');
        const toolName = toolMsg ? toolMsg.name : '';
        let toolData = {};
        try { toolData = JSON.parse(toolMsg.content); } catch(e) {}
        
        let replyContent = '';
        if (toolName === 'generate_qrcode') {
          replyContent = `### 📱 二维码生成完毕\n\n根据您的要求，已为您成功制作了专属二维码：\n\n![二维码](${toolData.imageUrl})\n\n* **二维码载荷文本**：\`${toolData.text || ''}\`\n* **状态**：生成成功，您可以右键保存此图片或使用手机扫码。`;
        } else if (toolName === 'diagnose_network_speed') {
          replyContent = `### 🚀 DevHelper 实时网络测速报告\n\n已成功获取您的网络自检数据，各项评估指标如下：\n\n| 测试维度 | 检测数值 | 诊断评估 |\n| :--- | :--- | :--- |\n| **局域网内网 IP** | \`${toolData.localIp || '未知'}\` | ${toolData.localIp ? '局域网归属' : '获取失败'} |\n| **外网公网 IP** | \`${toolData.publicIp || '获取失败'}\` | ${toolData.isp || '未知'} (${toolData.location || '未知'}) |\n| **加载延迟 (Ping)** | \`${toolData.ping || 'N/A'}\` | 响应速度：**${toolData.ping ? (parseInt(toolData.ping) <= 40 ? '优秀' : '一般') : '超时'}** |\n| **延迟抖动 (Jitter)** | \`${toolData.jitter || 'N/A'}\` | 稳定性：**${toolData.jitter ? (parseInt(toolData.jitter) <= 12 ? '极佳' : '轻微抖动') : '超时'}** |\n\n#### 📊 综合评级：**${toolData.statusLevel || '未知'}**\n> **网络诊断**：${toolData.statusDesc || '暂无详细描述。'}`;
        } else if (toolName === 'capture_webpage_screenshot') {
          replyContent = `### 📸 网页截图已成功生成\n\n根据您的指令，已为您截取了目标网页：\n\n![网页截图](${toolData.imageUrl})\n\n* **截图类型**：\`${toolData.type === 'visible' ? '可视区域截图' : '整页滚动拼接截图'}\`\n* **保存状态**：已为您自动保存该 PNG 截图文件到本地电脑。您可以在上方查看该图片缩略图。`;
        } else {
          replyContent = `### 🌐 网页健康度与性能分析报告\n\n根据抓取到的活跃网页数据，我为您做出了以下诊断：\n\n* **网页标题**：\`${toolData.title || '未知'}\`\n* **网页 URL**：${toolData.url || '未知'}\n* **页面加载总时长**：\`${toolData.loadTime || 'N/A'}\` (DOM Complete 耗时: \`${toolData.domCompleteTime || 'N/A'}\`)\n\n#### 📈 性能评估诊断：\n当前页面加载速度极为优异，所有的 DOM 渲染和资源流式传输均在预定健康范围内。由于是本地 Mock 数据，网络传输延迟为极佳状态。\n\n#### 📝 网页主要内容摘录：\n> ${toolData.bodyText ? toolData.bodyText.slice(0, 120) : '未提取到有效文本'}...\n\n**结论**：页面健康状况良好，各 Timing 指标均正常！`;
        }

        if (isStreaming) {
          return createStreamResponse(replyContent);
        } else {
          return new Response(JSON.stringify({
            choices: [{ message: { role: 'assistant', content: replyContent } }]
          }));
        }
      }

      // 2. 第一轮：如果是询问当前插件功能
      const userText = typeof lastMessage.content === 'string' ? lastMessage.content : '';
      let currentQuery = userText;
      if (userText.includes('对话历史:')) {
        const lines = userText.split('\n');
        const lastUserLine = lines.slice().reverse().find(l => l.startsWith('用户: '));
        if (lastUserLine) {
          currentQuery = lastUserLine.replace(/^用户: /, '');
        }
      }

      if (currentQuery.includes('功能') || currentQuery.includes('哪些工具') || currentQuery.includes('能力')) {
        const reply = `### 🛠️ DevHelper 已搭载的核心开发工具集：

目前插件已实现了以下 **20 款内置开发者工具**，可在侧边栏及导航主页直接使用：

| 序号 | 工具名称 | 页面路径 | 功能简介 |
| :---: | :--- | :--- | :--- |
| 1 | **IP 与网速检测** | \`pages/ip-speed.html\` | 检测局域网/公网IP、Ping延迟、上传下载网速并诊断 |
| 2 | **JWT 解析工具** | \`pages/jwt-parser.html\` | 解析与验证 JSON Web Token，支持对 Payload 可视化查看 |
| 3 | **二维码生成/解码** | \`pages/qrcode.html\` | 快速生成二维码，或上传解析图片二维码并下载 |
| 4 | **JSON 格式化工具** | \`pages/json-format.html\` | 可视化解析、格式化及折叠 JSON 报文，支持错误定位 |
| 5 | **网页截图与提取** | \`pages/screenshot.html\` | 捕获网页全屏或可视区域，并通过 OCR 提取文本 |
| 6 | **AI 调试助手** | \`pages/ai-assistant.html\` | 提供全栈开发解答、代码重构方案及实时网页分析诊断 |
| 7 | **API 接口测试** | \`pages/api-tester.html\` | 支持 GET/POST 请求发送，自定义 Header 与响应预览 |
| 8 | **代码格式化/美化** | \`pages/code-beautify.html\` | 支持 HTML/CSS/JavaScript 代码的在线美化、排版对齐 |
| 9 | **颜色格式转换** | \`pages/color-convert.html\` | HEX、RGB、HSL、CMYK 等多种颜色表示格式的双向转换 |
| 10 | **编码解码工具** | \`pages/encode-decode.html\` | 支持 URL 编码解码、Base64 编码解码及 HTML 实体字符转换 |
| 11 | **Hash 计算工具** | \`pages/hash-calc.html\` | 对文本和文件计算 MD5、SHA-1、SHA-256、SHA-512 哈希校验值 |
| 12 | **图片 Base64 转换** | \`pages/img-base64.html\` | 提供本地图片与 Base64 编码在线互转及 HTML/CSS 引用 |
| 13 | **JSON 文本对比** | \`pages/json-diff.html\` | 对比并高亮显示两段 JSON 报文数据结构之间的增删改细节差异 |
| 14 | **Markdown 编辑器** | \`pages/markdown-editor.html\` | 提供带双栏实时 HTML 渲染预览的 Markdown 编辑器 |
| 15 | **进制转换工具** | \`pages/number-base.html\` | 提供二进制、八进制、十进制、十六进制等多种数制互相转换 |
| 16 | **网页性能计时** | \`pages/page-timing.html\` | 深度读取网页的 DNS 解析、TCP 握手及首字节延迟等高级计时 |
| 17 | **随机密码生成** | \`pages/password-gen.html\` | 根据指定长度与所选字符集一键生成高强度随机密码 |
| 18 | **正则表达式测试** | \`pages/regex-test.html\` | 在线测试并校验正则表达式的匹配捕获效果，内置常用模板 |
| 19 | **时间戳转换工具** | \`pages/timestamp.html\` | 提供 Unix 时间戳与北京时间、UTC 时间双向快速转换 |
| 20 | **UUID 生成器** | \`pages/uuid-gen.html\` | 一键快速批量生成符合 RFC4122 标准的 UUID 唯一通用标识符 |

💡 **提示**：您可以在输入框中直接对我下达指令（例如“*帮我对当前网页截个图*”、“*生成一个网速测试报告*”），我将直接为您执行对应的工具操作并反馈结果！`;
        if (isStreaming) {
          return createStreamResponse(reply);
        } else {
          return new Response(JSON.stringify({
            choices: [{ message: { role: 'assistant', content: reply } }]
          }));
        }
      }

      // 3. 第一轮：匹配“二维码生成”
      if (currentQuery.includes('二维码') || currentQuery.includes('生成qr') || currentQuery.includes('转成qr')) {
        // 尝试从用户句子提取文本/URL，若有引号包裹或http链接则优先提取，否则取整句
        let qrText = 'https://docs.rowkin.xyz/';
        const urlMatch = currentQuery.match(/(https?:\/\/[^\s"'`）]+)/i);
        const quoteMatch = currentQuery.match(/["'`“‘]([^"'`”’]+)["'`”’]/);
        if (urlMatch) {
          qrText = urlMatch[1];
        } else if (quoteMatch) {
          qrText = quoteMatch[1];
        } else {
          // 清洗一些干扰词
          const cleanText = currentQuery.replace(/帮我生成(一个)?二维码/g, '')
                                      .replace(/生成二维码/g, '')
                                      .replace(/转成二维码/g, '')
                                      .replace(/的二维码/g, '')
                                      .replace(/内容为/g, '')
                                      .trim();
          if (cleanText.length > 0) {
            qrText = cleanText;
          }
        }

        if (isStreaming) {
          return createStreamToolCallResponse('generate_qrcode', { text: qrText });
        } else {
          return new Response(JSON.stringify({
            choices: [{
              message: {
                role: 'assistant',
                content: null,
                tool_calls: [{
                  id: 'call_mock_qr',
                  type: 'function',
                  function: {
                    name: 'generate_qrcode',
                    arguments: JSON.stringify({ text: qrText })
                  }
                }]
              }
            }]
          }));
        }
      }

      // 4. 第一轮：匹配“网速测试”
      if (currentQuery.includes('网速') || currentQuery.includes('测速') || currentQuery.includes('测试网络') || currentQuery.includes('网络速度')) {
        if (isStreaming) {
          return createStreamToolCallResponse('diagnose_network_speed', {});
        } else {
          return new Response(JSON.stringify({
            choices: [{
              message: {
                role: 'assistant',
                content: null,
                tool_calls: [{
                  id: 'call_mock_speed',
                  type: 'function',
                  function: {
                    name: 'diagnose_network_speed',
                    arguments: '{}'
                  }
                }]
              }
            }]
          }));
        }
      }

      // 5. 第一轮：匹配“网页截图”
      if (currentQuery.includes('截图') || currentQuery.includes('长截图') || currentQuery.includes('全屏截图') || currentQuery.includes('捕获网页') || currentQuery.includes('截屏')) {
        const urlMatch = currentQuery.match(/(https?:\/\/[^\s"'`）]+)/i);
        const targetUrl = urlMatch ? urlMatch[1] : undefined;
        const type = currentQuery.includes('可视') ? 'visible' : 'full';

        if (isStreaming) {
          return createStreamToolCallResponse('capture_webpage_screenshot', { targetUrl, type, autoDownload: true });
        } else {
          return new Response(JSON.stringify({
            choices: [{
              message: {
                role: 'assistant',
                content: null,
                tool_calls: [{
                  id: 'call_mock_screenshot',
                  type: 'function',
                  function: {
                    name: 'capture_webpage_screenshot',
                    arguments: JSON.stringify({ targetUrl, type, autoDownload: true })
                  }
                }]
              }
            }]
          }));
        }
      }

      // 6. 第一轮：如果是需要分析网页
      if (currentQuery.includes('分析') || currentQuery.includes('网页') || currentQuery.includes('性能') || currentQuery.includes('诊断')) {
        const urlRegex = /(https?:\/\/[^\s]+)/i;
        const match = currentQuery.match(urlRegex);
        if (match) {
          const targetUrl = match[1];
          if (isStreaming) {
            return createStreamToolCallResponse('fetch_specified_url_context', { url: targetUrl });
          } else {
            return new Response(JSON.stringify({
              choices: [{
                message: {
                  role: 'assistant',
                  content: null,
                  tool_calls: [{
                    id: 'call_mock_456',
                    type: 'function',
                    function: {
                      name: 'fetch_specified_url_context',
                      arguments: JSON.stringify({ url: targetUrl })
                    }
                  }]
                }
              }]
            }));
          }
        }

        if (isStreaming) {
          return createStreamToolCallResponse('fetch_active_tab_context', { includeDomHtml: true, includePerformance: true });
        } else {
          return new Response(JSON.stringify({
            choices: [{
              message: {
                role: 'assistant',
                content: null,
                tool_calls: [{
                  id: 'call_mock_123',
                  type: 'function',
                  function: {
                    name: 'fetch_active_tab_context',
                    arguments: JSON.stringify({ includeDomHtml: true, includePerformance: true })
                  }
                }]
              }
            }]
          }));
        }
      }

      // 6. 识别是否是万能计算器的请求
      const systemMsg = messages.find(m => m.role === 'system') || {};
      const systemContent = systemMsg.content || '';
      const userMsg = messages.find(m => m.role === 'user') || {};
      const userContent = userMsg.content || '';

      if (userContent.includes('计算得出 BMI 指数') || userContent.includes('BMI 身体质量') || userContent.includes('我的身高是')) {
        const bmiVal = (userContent.match(/BMI 指数是\s*([\d\.]+)/) || [])[1] || '24.5';
        const bmiStatus = (userContent.match(/处于「([^」]+)」状态/) || [])[1] || '正常';
        
        let detailPlan = '';
        if (bmiStatus.includes('正常')) {
          detailPlan = `### 🥗 您的专属健康改善方案 (体质分级：正常)

您的 BMI 指数为 **${bmiVal}**，正处于完美的标准健康范围！这是非常优秀的身体指征。为了维持该良好体态并提升心肺活力，AI 专家为您量身定制了以下方案：

#### 1. 🥦 营养膳食调理建议
* **热量配比**：碳水化合物 50%、蛋白质 25%、脂肪 25%。无需刻意节食。
* **优质食材**：每日摄入足够的膳食纤维与优质蛋白。推荐燕麦、三文鱼、鸡胸肉，搭配多种深色蔬菜。
* **水分管理**：每日维持至少 2000ml 的饮水量，以促进基础代谢。

#### 2. 🏃‍♂️ 科学运动健身计划
* **有氧锻炼**：每周进行 3-4 次中等强度有氧运动，如慢跑、骑行、游泳，每次 40 分钟。
* **力量训练**：建议每周引入 2 次全身抗阻力量练习（如深蹲、俯卧撑、硬拉），提升核心肌群力量，延缓肌肉流失。

#### 3. 🛌 日常生活作息建议
* 保持每天 7-8 小时的深度睡眠，减少熬夜带来的皮质醇水平上升；
* 配合日常拉伸，保持关节的灵活性，避免长期久坐。`;
        } else if (bmiStatus.includes('偏瘦')) {
          detailPlan = `### 🥩 您的专属增肌营养方案 (体质分级：偏瘦)

您的 BMI 指数为 **${bmiVal}**，体征表明目前体质偏瘦，可能存在轻度肌肉量不足或能量储备偏低。AI 专家建议通过科学的营养盈余和抗阻运动来进行增肌：

#### 1. 🥚 膳食热量盈余建议
* **高营养密度**：采用高蛋白、多碳水膳食。每日可维持 300-500 kcal 的能量盈余。
* **推荐食物**：全脂牛奶、牛肉、鸡蛋、坚果、牛油果。多餐少食，每次正餐后可适度补充高能点心。

#### 2. 🏋️ 力量训练（以增肌为主）
* 限制过度长时间的有氧运动，以防止肌肉进一步流失；
* 重点安排**负重力量训练**，每周 3-4 次。重点锻炼大肌群（胸、背、腿），单次训练时间控制在 45-60 分钟内。

#### 3. 恢复与生活方式
* 充足的睡眠是肌肉合成的关键时期，保证每晚 8 小时睡眠；
* 保持心情愉悦，防止压力过大导致胃肠消化功能吸收减退。`;
        } else {
          // 超重或肥胖
          detailPlan = `### 🥗 您的专属减脂健康方案 (体质分级：${bmiStatus})

您的 BMI 指数为 **${bmiVal}**，体征表明体脂率偏高，心血管负荷和关节压力正在增加。AI 专家为您定制了无伤减脂与温和代谢方案：

#### 1. 🥬 严格热量限制与饮食调理
* **热量赤字**：每日减去 300-500 kcal 的摄入，切忌极端节食。
* **控糖控油**：严格戒断精制糖、油炸食物和含糖饮料。主食以粗粮（荞麦面、糙米、紫薯）为主，提升蔬菜比例。
* **高饱腹感**：多摄入鸡蛋白、深海鱼等低脂高蛋白食物，维持肌肉量以稳定基础代谢。

#### 2. 🚴 科学减脂与关节保护运动
* **低冲击有氧**：采用坡度快走、椭圆机、游泳等对膝关节冲击小的运动，每周 4-5 次，每次 45-60 分钟。
* **基础力量**：每周结合 2 次轻负重力量训练，帮助稳定关节，防止肌肉流失。

#### 3. ⏰ 作息与行为矫正建议
* **规律作息**：规律的生物钟有利于维持 Leptin（瘦素）水平，从而抑制食欲。
* **记录体重**：每周固定清晨排便后测量体重与腰围，关注长期趋势而非短期波动。`;
        }

        if (isStreaming) {
          return createStreamResponse(detailPlan);
        } else {
          return new Response(JSON.stringify({
            choices: [{ message: { role: 'assistant', content: detailPlan } }]
          }));
        }
      }

      if (systemContent.includes('万能计算器') || systemContent.includes('房贷财务') || userContent.includes('万能计算器')) {
        let calcReply = '';
        if (userContent.includes('当前所处面板】：loan') || userContent.includes('贷款总额')) {
          calcReply = `### 🏡 DevHelper 房贷还款财务智能诊断报告

根据您输入的贷款推演数据，AI 为您提供以下多维财务建议：

#### ⚖️ 还款方式深度对比 (等额本息 vs 等额本金)
- **等额本息**：每月还款额固定，前期利息占比高，适合工作初期、现金流偏紧或有其他高收益投资渠道的家庭。
- **等额本金**：每月还款本金固定，利息随本金减少而逐月递减。虽然前期还款压力较大，但**总利息支出显著低于等额本息**。

#### 💡 财务优化与理财建议
1. **轻资产家庭**：如果手头流动资金有限，建议采用**等额本息**，以减轻每月的强制性刚性支出，将资金留作日常应急或购买低风险理财。
2. **提前还贷契机**：如果未来积累了较多闲置资金，且找不到年化收益率超过您房贷利率（当前为 \`${(userContent.match(/利率：([\d\.]+)/) || [])[1] || '3.8'}%\`）的稳健投资渠道，**提前部分还贷**是一个无风险的“保值”选择。
3. **等额本金转化**：若选择等额本金，首月供款偏高，请确保家庭月总收入是首月月供的 2.5 倍以上，以维持健康的家庭资产防线。`;
        } else if (userContent.includes('当前所处面板】：exchange') || userContent.includes('源币种')) {
          calcReply = `### 🌐 DevHelper 实时外币换算与宏观金融解读

根据您所选的币种换算状态，AI 助手为您带来以下实时金融常识与海淘出行贴士：

#### 📈 汇率机制与结算常识
- **美元 (USD)** 作为全球最主要的储备货币，其联邦基金利率的变动（加息/降息）会直接影响全球资本流动，从而引起其他币种（如 **CNY**, **EUR**, **JPY**）对美元的汇率波动。
- 跨境刷卡消费时，建议优先选择 **本地货币 (Local Currency)** 进行结算，避免由于 DCC (动态货币转换) 带来高昂的二次转汇手续费。

#### ✈️ 旅游海淘指南
1. **小额兑换**：出境旅游前，可在国内银行兑换适量目标币种现金。若在国外机场或路边兑换点，往往存在较大的买卖差价。
2. **双币信用卡**：海淘时建议使用多币种信用卡（支持 VISA / Mastercard / UnionPay），能有效规避单币种转汇的汇兑损失。`;
        } else {
          calcReply = `### 🧮 DevHelper 数学算式与科学函数深度剖析

针对您在标准与科学计算器中输入的数学算式，AI 进行了解析和应用指南：

#### 📝 算式结构与代数解析
- **当前输入算式**：\`${(userContent.match(/当前算式表达式：(.*)/) || [])[1] || '未输入'}\`
- **计算逻辑**：本计算器完全遵循数学中的 **先乘除、后加减，先括号内、后括号外** 的标准四则混合运算顺序。

#### 🔬 科学计算应用场景
- **三角函数 (sin, cos, tan)**：在科学模式下，默认采用**角度制**进行三角运算，广泛运用于几何测量、信号处理、波动分析等物理与工程领域。
- **对数函数 (ln, log)**：ln 代表以自然常数 $e$ 为底的对数，log 代表以 10 为底的常用对数。在复利计算、声强分贝计算、酸碱度 (pH) 以及信息熵评估中具有不可替代的作用。`;
        }

        if (isStreaming) {
          return createStreamResponse(calcReply);
        } else {
          return new Response(JSON.stringify({
            choices: [{ message: { role: 'assistant', content: calcReply } }]
          }));
        }
      }

      // 7. 普通闲聊
      const defaultReply = `你好！我是 DevHelper AI 技术助手。我已经成功加载了 Native Tool Calling 引擎，能实时感知我的【内置工具集】并且支持对【当前网页 of DOM/Timing 上下文】进行抓取诊断！你可以试试问我：“分析一下当前网页” 或 “当前插件有哪些功能”。`;
      if (isStreaming) {
        return createStreamResponse(defaultReply);
      } else {
        return new Response(JSON.stringify({
          choices: [{ message: { role: 'assistant', content: defaultReply } }]
        }));
      }
    }
    return originalFetch(url, options);
  };
}


const AI_PROVIDERS = {
  BUILTIN: 'builtin',
  OPENAI: 'openai',
};

/** 从 storage 读取 AI 配置 */
async function getAIConfig() {
  const data = await chrome.storage.local.get(['aiConfig']);
  return data.aiConfig || {
    provider: AI_PROVIDERS.OPENAI,
    apiKey: 'mock_key_for_local_test',
    apiUrl: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
  };
}

/** 保存 AI 配置 */
async function saveAIConfig(config) {
  await chrome.storage.local.set({ aiConfig: config });
}

/**
 * 检测 Chrome 内置 AI 是否可用
 * 强兼容各种不同 Chrome 版本（window.ai.languageModel, window.ai.assistant, window.LanguageModel）
 */
async function checkBuiltinAI() {
  const aiObj = window.ai || window.model || {};
  const lm = aiObj.languageModel || aiObj.assistant || window.LanguageModel;
  if (!lm) return false;
  try {
    if (typeof lm.capabilities === 'function') {
      const caps = await lm.capabilities();
      return caps.available !== 'no';
    }
    if (typeof lm.availability === 'function') {
      const avail = await lm.availability();
      return avail === 'available' || avail === 'downloadable';
    }
    return true;
  } catch (e) {
    console.warn('DevHelper AI 检测内置 AI 发生错误:', e);
    return false;
  }
}

/** 调用 Chrome 内置 AI */
async function callBuiltinAI(systemPrompt, userContent, onChunk) {
  const aiObj = window.ai || window.model || {};
  const lm = aiObj.languageModel || aiObj.assistant || window.LanguageModel;
  if (!lm) {
    throw new Error('未在当前浏览器中检测到内置 AI（Gemini Nano）服务');
  }

  const session = await lm.create({
    systemPrompt,
  });
  const prompt = userContent;

  if (onChunk) {
    const stream = session.promptStreaming(prompt);
    let result = '';
    for await (const chunk of stream) {
      result = chunk;
      onChunk(chunk);
    }
    session.destroy();
    return result;
  }

  const result = await session.prompt(prompt);
  session.destroy();
  return result;
}

/**
 * 调用 AI 接口（非流式）
 * @param {string} systemPrompt - 系统提示词
 * @param {string} userContent - 用户内容
 * @param {function} onChunk - 流式回调（可选）
 */
/**
 * 调用 AI 接口（支持流式/非流式）
 * @param {string|object} systemPrompt - 系统提示词，或者配置对象
 * @param {string} userContent - 用户内容
 * @param {function} onChunk - 流式回调（可选）
 */
async function callAI(systemPrompt, userContent, onChunk = null) {
  let opts = {};
  if (typeof systemPrompt === 'object' && systemPrompt !== null) {
    opts = systemPrompt;
    systemPrompt = opts.systemPrompt || '';
    userContent = opts.userContent || opts.prompt || '';
    onChunk = opts.onChunk || onChunk;
  } else {
    opts = { systemPrompt, userContent, onChunk };
  }

  const config = await getAIConfig();

  // 强化系统提示词以默认要求中文/双语输出
  const chineseConstraint = '\n\n【重要指令：请务必使用简体中文进行回答，若内容涉及代码、英文术语或原数据，进行翻译或者以简体中文为主的双语对照形式展示。】';
  const enhancedSystemPrompt = (systemPrompt || '') + chineseConstraint;

  if (config.provider === AI_PROVIDERS.BUILTIN) {
    let textPrompt = userContent;
    if (Array.isArray(userContent)) {
      const textItem = userContent.find(item => item.type === 'text');
      textPrompt = textItem ? textItem.text : '分析截图';
    }
    return callBuiltinAI(enhancedSystemPrompt, textPrompt, onChunk);
  }

  return callOpenAI(config, {
    systemPrompt: enhancedSystemPrompt,
    userContent,
    onChunk,
    tools: opts.tools,
    toolHandlers: opts.toolHandlers
  });
}

/** 调用 OpenAI 兼容接口（具备 Tool Call 自动分发多轮会话控制器） */
async function callOpenAI(config, options) {
  const initialMessages = [
    { role: 'system', content: options.systemPrompt },
    { role: 'user', content: options.userContent },
  ];

  return runOpenAIChat(config, initialMessages, options);
}

/** 递归或循环执行多轮会话的控制器 */
async function runOpenAIChat(config, messages, options) {
  const result = await callOpenAIInternal(config, messages, options);

  if (result.type === 'tool_calls') {
    const toolMessages = [];
    for (const tc of result.toolCalls) {
      let args = {};
      try {
        args = JSON.parse(tc.function.arguments || '{}');
      } catch (e) {
        console.warn('DevHelper AI 解析 Tool 参数失败:', tc.function.arguments, e);
      }

      let resultStr = '';
      if (options.toolHandlers && options.toolHandlers[tc.function.name]) {
        try {
          const resObj = await options.toolHandlers[tc.function.name](args);
          resultStr = JSON.stringify(resObj);
        } catch (err) {
          resultStr = JSON.stringify({ error: err.message });
        }
      } else {
        resultStr = JSON.stringify({ error: `Handler for "${tc.function.name}" not found` });
      }

      toolMessages.push({
        role: 'tool',
        tool_call_id: tc.id,
        name: tc.function.name,
        content: resultStr
      });
    }

    const secondRoundMessages = [
      ...messages,
      { role: 'assistant', content: null, tool_calls: result.toolCalls },
      ...toolMessages
    ];

    // 继续发起下一轮请求以获取模型使用 Tool 结果后的最终解读
    return runOpenAIChat(config, secondRoundMessages, options);
  }

  return result.content;
}

/** 发起单次 OpenAI 兼容接口请求（底层 SSE 处理） */
async function callOpenAIInternal(config, messages, options) {
  if (!config.apiKey) {
    throw new Error('请先在 AI 设置中配置 API Key');
  }

  const body = {
    model: config.model || 'gpt-4o-mini',
    messages: messages,
    stream: !!options.onChunk,
    max_tokens: 2048,
  };

  const modelLower = (config.model || '').toLowerCase();
  const isReasoningModel = modelLower.includes('kimi-k') || modelLower.includes('o1-') || modelLower.includes('o3-') || modelLower.includes('reasoning');
  if (!isReasoningModel) {
    body.temperature = 0.7;
  }

  if (options.tools && options.tools.length > 0) {
    body.tools = options.tools;
  }

  let url = config.apiUrl || 'https://api.openai.com/v1/chat/completions';
  if (!url.endsWith('/chat/completions') && !url.includes('/chat/completions?')) {
    url = url.replace(/\/$/, '') + '/chat/completions';
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `HTTP ${response.status}`);
  }

  if (options.onChunk) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    let reasoningText = '';
    let buffer = '';
    let toolCalls = [];

    const processLine = (line) => {
      const parts = line.split(/(?=data:)/);
      for (const part of parts) {
        const trimmed = part.trim();
        if (!trimmed || !trimmed.startsWith('data:')) continue;
        const data = trimmed.slice(5).trim();
        if (data === '[DONE]') continue;
        try {
          const parsed = JSON.parse(data);
          const delta = parsed.choices?.[0]?.delta || {};

          // 处理流式 tool_calls 累积与分包拼接
          if (delta.tool_calls) {
            delta.tool_calls.forEach(tc => {
              const idx = tc.index;
              if (!toolCalls[idx]) {
                toolCalls[idx] = {
                  id: tc.id || '',
                  type: tc.type || 'function',
                  function: {
                    name: tc.function?.name || '',
                    arguments: tc.function?.arguments || ''
                  }
                };
              } else {
                if (tc.id) toolCalls[idx].id = tc.id;
                if (tc.function?.name) toolCalls[idx].function.name += tc.function.name;
                if (tc.function?.arguments) toolCalls[idx].function.arguments += tc.function.arguments;
              }
            });
          }

          const contentDelta = delta.content || '';
          if (contentDelta) {
            fullText += contentDelta;
            options.onChunk(fullText, reasoningText);
            continue;
          }

          const reasoningDelta = delta.reasoning_content || '';
          if (reasoningDelta) {
            reasoningText += reasoningDelta;
            options.onChunk('', reasoningText);
          }
        } catch (e) {
          console.warn('SSE 单包 JSON 解析异常，跳过残损包:', e, '原始片段:', trimmed);
        }
      }
    };

    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        if (buffer.trim()) processLine(buffer);
        break;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        processLine(line);
      }
    }

    const activeToolCalls = toolCalls.filter(Boolean);
    if (activeToolCalls.length > 0) {
      return { type: 'tool_calls', toolCalls: activeToolCalls };
    }

    return { type: 'content', content: fullText };
  }

  const json = await response.json();
  const choice = json.choices?.[0] || {};
  const message = choice.message || {};

  if (message.tool_calls && message.tool_calls.length > 0) {
    return { type: 'tool_calls', toolCalls: message.tool_calls };
  }

  return { type: 'content', content: message.content || '' };
}

// 导出供工具页面使用
window.DevHelperAI = { callAI, getAIConfig, saveAIConfig, checkBuiltinAI, AI_PROVIDERS };
