(function() {
  if (window.DevHelperScreenshotHelperInitialized) {
    return;
  }
  window.DevHelperScreenshotHelperInitialized = true;

  let overlay = null;
  let canvas = null;
  let ctx = null;
  let isDrawing = false;
  let startX = 0;
  let startY = 0;
  let currentX = 0;
  let currentY = 0;

  // 原始滚动条和位置（长截图用）
  let originalOverflow = '';
  let originalHtmlOverflow = '';
  let originalScrollX = 0;
  let originalScrollY = 0;

  // 监听来自扩展程序的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startAreaSelect') {
      startAreaSelection(sendResponse);
      return true; // 保持通道开放，用于异步响应选区
    }

    if (request.action === 'prepareScroll') {
      // 记录状态，准备整页滚动截图
      originalOverflow = document.body.style.overflow;
      originalHtmlOverflow = document.documentElement.style.overflow;
      originalScrollX = window.scrollX;
      originalScrollY = window.scrollY;

      // 隐藏滚动条以避免出现在长截图中
      document.body.style.overflow = 'hidden';
      document.documentElement.style.overflow = 'hidden';

      // 隐藏某些固定定位的浮动球或导航条（可选，这里只隐藏滚动条以保证稳定）
      
      const totalWidth = Math.max(
        document.documentElement.scrollWidth,
        document.body.scrollWidth,
        document.documentElement.clientWidth
      );
      const totalHeight = Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight,
        document.documentElement.clientHeight
      );

      sendResponse({
        totalWidth,
        totalHeight,
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight,
        dpr: window.devicePixelRatio || 1
      });
    }

    if (request.action === 'scrollTo') {
      window.scrollTo(0, request.y);
      // 延迟给网页渲染和动画留出时间
      setTimeout(() => {
        sendResponse({ success: true });
      }, 150);
      return true;
    }

    if (request.action === 'restoreScroll') {
      // 恢复滚动条与滚动位置
      document.body.style.overflow = originalOverflow;
      document.documentElement.style.overflow = originalHtmlOverflow;
      window.scrollTo(originalScrollX, originalScrollY);
      sendResponse({ success: true });
    }
  });

  // 开始区域选择模式
  function startAreaSelection(onCompleteCallback) {
    if (overlay) return;

    // 创建全屏蒙版
    overlay = document.createElement('div');
    overlay.id = 'devhelper-screenshot-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 999999999;
      background: rgba(0, 0, 0, 0.4);
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
    `;

    canvas = document.createElement('canvas');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.style.cssText = 'position: absolute; top: 0; left: 0; pointer-events: none;';
    ctx = canvas.getContext('2d');
    overlay.appendChild(canvas);
    document.body.appendChild(overlay);

    // 绘制全黑透明层
    drawOverlay();

    // 绑定鼠标事件
    overlay.addEventListener('mousedown', onMouseDown);
    overlay.addEventListener('mousemove', onMouseMove);
    overlay.addEventListener('mouseup', onMouseUp);
    
    // 监听 ESC 取消
    window.addEventListener('keydown', onKeyDown);

    function onMouseDown(e) {
      if (e.button !== 0) return; // 只响应左键
      isDrawing = true;
      startX = e.clientX;
      startY = e.clientY;
      currentX = startX;
      currentY = startY;
    }

    function onMouseMove(e) {
      if (!isDrawing) return;
      currentX = e.clientX;
      currentY = e.clientY;
      drawSelection();
    }

    function onMouseUp(e) {
      if (!isDrawing) return;
      isDrawing = false;
      
      const x = Math.min(startX, currentX);
      const y = Math.min(startY, currentY);
      const width = Math.abs(startX - currentX);
      const height = Math.abs(startY - currentY);

      cleanup();

      // 仅当截取区域面积大于 10 像素时才进行截图，否则忽略（当做误触）
      if (width > 3 && height > 3) {
        onCompleteCallback({
          status: 'success',
          rect: {
            x,
            y,
            width,
            height,
            dpr: window.devicePixelRatio || 1
          }
        });
      } else {
        onCompleteCallback({ status: 'cancel' });
      }
    }

    function onKeyDown(e) {
      if (e.key === 'Escape') {
        cleanup();
        onCompleteCallback({ status: 'cancel' });
      }
    }

    function cleanup() {
      window.removeEventListener('keydown', onKeyDown);
      if (overlay) {
        overlay.removeEventListener('mousedown', onMouseDown);
        overlay.removeEventListener('mousemove', onMouseMove);
        overlay.removeEventListener('mouseup', onMouseUp);
        overlay.remove();
        overlay = null;
        canvas = null;
        ctx = null;
      }
    }
  }

  // 绘制蒙版及指示说明
  function drawOverlay() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 绘制使用说明
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('拖拽鼠标选择区域，按 ESC 退出', canvas.width / 2, 40);
  }

  // 绘制选区高亮框
  function drawSelection() {
    if (!ctx) return;
    drawOverlay();

    const x = Math.min(startX, currentX);
    const y = Math.min(startY, currentY);
    const w = Math.abs(startX - currentX);
    const h = Math.abs(startY - currentY);

    // 挖空选区
    ctx.clearRect(x, y, w, h);

    // 绘制选区边框
    ctx.strokeStyle = '#6366f1'; // primary theme color
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);

    // 绘制选区尺寸信息
    if (w > 20 && h > 20) {
      ctx.fillStyle = '#6366f1';
      const label = `${w} x ${h}`;
      ctx.font = '12px var(--mono-font, monospace)';
      ctx.textAlign = 'left';
      ctx.fillRect(x, y - 22, ctx.measureText(label).width + 12, 20);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(label, x + 6, y - 7);
    }
  }
})();
