// DevHelper - 屏幕截图工具脚本
// 支持可视区域、整页滚动拼接、区域截取、本地上传与 Canvas 标注功能

let sourceTabId = null;
let myTabId = null;

// 画布相关状态
let canvas = null;
let ctx = null;
let bgImage = null; // 背景截图 Image 对象
let isDrawing = false;
let startX = 0;
let startY = 0;
let lastX = 0;
let lastY = 0;

// 当前标注工具配置
let currentTool = 'brush'; // 'brush', 'rect', 'arrow', 'text', 'mosaic'
let currentColor = '#ef4444';
let currentLineWidth = 4;

// 撤销历史
let historyList = [];
let maxHistory = 20;

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
  canvas = document.getElementById('editorCanvas');
  ctx = canvas.getContext('2d');

  // 获取自己的 Tab ID
  if (window.chrome && chrome.tabs) {
    chrome.tabs.getCurrent(tab => {
      if (tab) myTabId = tab.id;
    });
  }

  // 解析 URL 参数获取要截取的目标 Tab
  const urlParams = new URLSearchParams(window.location.search);
  const tabIdStr = urlParams.get('sourceTabId');
  if (tabIdStr) {
    sourceTabId = parseInt(tabIdStr);
    // 验证 Tab 是否合法
    chrome.tabs.get(sourceTabId, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        sourceTabId = null;
        showTabErrorTip();
      } else if (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
        sourceTabId = null;
        showTabErrorTip('受浏览器安全限制，无法截取系统级页面（chrome://）。您可以使用下方“本地标注”功能。');
      }
    });
  } else {
    showTabErrorTip();
  }

  // 绑定截图控制面板事件
  document.getElementById('btnVisible').addEventListener('click', () => handleCapture('visible'));
  document.getElementById('btnFull').addEventListener('click', () => handleCapture('full'));
  document.getElementById('btnArea').addEventListener('click', () => handleCapture('area'));
  document.getElementById('btnDisplayMedia').addEventListener('click', captureScreenStream);

  // 绑定本地上传
  const uploadZone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  uploadZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', handleFileSelect);
  
  // 拖拽上传
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--primary)';
  });
  uploadZone.addEventListener('dragleave', () => {
    uploadZone.style.borderColor = 'var(--border)';
  });
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--border)';
    if (e.dataTransfer.files.length > 0) {
      loadImageFile(e.dataTransfer.files[0]);
    }
  });

  // 剪贴板粘贴
  document.addEventListener('paste', (e) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const blob = items[i].getAsFile();
        loadImageFile(blob);
        break;
      }
    }
  });

  // 绑定编辑器标注工具
  setupEditorTools();
});

// 显示 Tab 不可用提示
function showTabErrorTip(msg) {
  const customMsg = msg || '提示：未检测到有效的目标网页。请在目标网页中打开 DevHelper 扩展图标，再启动“屏幕截图”工具。当前您仍可点击右下角上传或粘贴本地图片进行标注。';
  showToast(customMsg, 'info', 6000);
  
  // 禁用三大截图按钮
  document.getElementById('btnVisible').style.opacity = '0.5';
  document.getElementById('btnVisible').style.cursor = 'not-allowed';
  document.getElementById('btnFull').style.opacity = '0.5';
  document.getElementById('btnFull').style.cursor = 'not-allowed';
  document.getElementById('btnArea').style.opacity = '0.5';
  document.getElementById('btnArea').style.cursor = 'not-allowed';
}

// 统一处理截图触发（支持倒计时）
async function handleCapture(type) {
  if (!sourceTabId) {
    showToast('无有效网页连接，请使用本地标注或在具体网页中重新打开扩展', 'error');
    return;
  }

  const delaySelect = document.getElementById('optDelay');
  const delaySeconds = parseInt(delaySelect.value);

  if (delaySeconds > 0) {
    // 倒计时逻辑
    const overlay = document.getElementById('countdownOverlay');
    overlay.style.display = 'flex';
    overlay.textContent = delaySeconds;

    let count = delaySeconds;
    const interval = setInterval(async () => {
      count--;
      if (count <= 0) {
        clearInterval(interval);
        overlay.style.display = 'none';
        executeCapture(type);
      } else {
        overlay.textContent = count;
      }
    }, 1000);
  } else {
    executeCapture(type);
  }
}

// 执行具体的截图动作
async function executeCapture(type) {
  // 切回原 Tab
  await chrome.tabs.update(sourceTabId, { active: true });
  
  // 稍微等一下页面转场渲染
  setTimeout(async () => {
    try {
      if (type === 'visible') {
        captureVisibleFlow();
      } else if (type === 'area') {
        captureAreaFlow();
      } else if (type === 'full') {
        captureFullPageFlow();
      }
    } catch (e) {
      console.error(e);
      showToast('截图失败，网页可能已刷新或不可用', 'error');
      // 切回截图 Tab
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
    }
  }, 250);
}

// ==================== 1. 可视区截图流程 ====================
function captureVisibleFlow() {
  chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (response) => {
    if (myTabId) chrome.tabs.update(myTabId, { active: true });
    
    if (response && response.dataUrl) {
      processCaptureResult(response.dataUrl);
    } else {
      showToast('可视区域截图失败，请确保目标网页已加载完毕', 'error');
    }
  });
}

// ==================== 2. 区域截图流程 ====================
async function captureAreaFlow() {
  // 注入 content script
  await injectHelperScript();

  // 向 content script 发送指令启动框选
  chrome.tabs.sendMessage(sourceTabId, { action: 'startAreaSelect' }, (response) => {
    if (chrome.runtime.lastError) {
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
      showToast('无法在系统页面或已受保护的页面执行选择', 'error');
      return;
    }

    if (response && response.status === 'success') {
      const rect = response.rect;
      // 捕获当前可视区
      chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (capRes) => {
        if (myTabId) chrome.tabs.update(myTabId, { active: true });
        
        if (capRes && capRes.dataUrl) {
          cropImage(capRes.dataUrl, rect);
        } else {
          showToast('可视截图失败，无法裁剪选区', 'error');
        }
      });
    } else {
      // 取消或失败，返回
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
    }
  });
}

// 注入 content script 的通用方法
async function injectHelperScript() {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript({
      target: { tabId: sourceTabId },
      files: ['js/content/screenshot-helper.js']
    }, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

// 根据选区坐标裁剪图片
function cropImage(dataUrl, rect) {
  const tempImg = new Image();
  tempImg.onload = () => {
    const dpr = rect.dpr || 1;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = rect.width * dpr;
    tempCanvas.height = rect.height * dpr;
    const tempCtx = tempCanvas.getContext('2d');

    // 裁剪绘制
    tempCtx.drawImage(
      tempImg,
      rect.x * dpr,
      rect.y * dpr,
      rect.width * dpr,
      rect.height * dpr,
      0,
      0,
      rect.width * dpr,
      rect.height * dpr
    );

    const croppedDataUrl = tempCanvas.toDataURL('image/png');
    processCaptureResult(croppedDataUrl);
  };
  tempImg.src = dataUrl;
}

// ==================== 3. 整页长截图流程 ====================
async function captureFullPageFlow() {
  await injectHelperScript();

  // 1. 获取页面尺寸信息并准备滚动
  chrome.tabs.sendMessage(sourceTabId, { action: 'prepareScroll' }, async (info) => {
    if (!info) {
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
      showToast('获取页面信息失败，无法进行整页截图', 'error');
      return;
    }

    const { totalHeight, viewportWidth, viewportHeight, dpr } = info;
    
    // 创建拼图 Canvas
    const stitchCanvas = document.createElement('canvas');
    stitchCanvas.width = viewportWidth * dpr;
    stitchCanvas.height = totalHeight * dpr;
    const stitchCtx = stitchCanvas.getContext('2d');

    let currentY = 0;

    showToast('正在生成整页长截图，请稍候...', 'info', 3000);

    // 2. 循环滚动并截图拼接
    async function captureFrame() {
      // 滚动到指定位置
      chrome.tabs.sendMessage(sourceTabId, { action: 'scrollTo', y: currentY }, async () => {
        // 进行可视截图
        chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, async (capRes) => {
          if (!capRes || !capRes.dataUrl) {
            // 失败了，直接结束并恢复
            finishFullPageCapture();
            return;
          }

          const frameImg = new Image();
          frameImg.onload = async () => {
            // 判定是否是最后一帧（可能会有重叠）
            const remainHeight = totalHeight - currentY;
            if (remainHeight < viewportHeight) {
              // 最后一帧只画裁剪下来的底部部分
              const sourceY = (viewportHeight - remainHeight) * dpr;
              stitchCtx.drawImage(
                frameImg,
                0,
                sourceY,
                viewportWidth * dpr,
                remainHeight * dpr,
                0,
                currentY * dpr,
                viewportWidth * dpr,
                remainHeight * dpr
              );
              // 完成
              finishFullPageCapture();
            } else {
              // 普通帧，直接画满可视区
              stitchCtx.drawImage(frameImg, 0, currentY * dpr);
              
              currentY += viewportHeight;
              if (currentY >= totalHeight) {
                finishFullPageCapture();
              } else {
                captureFrame(); // 递归截取下一帧
              }
            }
          };
          frameImg.src = capRes.dataUrl;
        });
      });
    }

    function finishFullPageCapture() {
      // 恢复滚动条
      chrome.tabs.sendMessage(sourceTabId, { action: 'restoreScroll' }, () => {
        if (myTabId) chrome.tabs.update(myTabId, { active: true });
        
        const stitchedDataUrl = stitchCanvas.toDataURL('image/png');
        processCaptureResult(stitchedDataUrl);
      });
    }

    // 开始截取第一帧
    captureFrame();
  });
}

// ==================== 4. 屏幕捕获 (DisplayMedia) ====================
async function captureScreenStream() {
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: { displaySurface: "monitor" },
      audio: false
    });

    const video = document.createElement('video');
    video.autoplay = true;
    video.playsInline = true;
    video.srcObject = stream;

    video.onloadedmetadata = () => {
      // 给视频缓冲一下帧
      setTimeout(() => {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = video.videoWidth;
        tempCanvas.height = video.videoHeight;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        
        // 彻底停止流，释放摄像头/屏幕捕获
        stream.getTracks().forEach(track => track.stop());
        
        const dataUrl = tempCanvas.toDataURL('image/png');
        processCaptureResult(dataUrl);
      }, 500);
    };
  } catch (err) {
    console.error(err);
    showToast('屏幕捕获已取消或失败', 'error');
  }
}

// ==================== 5. 本地图片上传和粘贴 ====================
function handleFileSelect(e) {
  if (e.target.files.length > 0) {
    loadImageFile(e.target.files[0]);
  }
}

function loadImageFile(file) {
  if (!file.type.startsWith('image/')) {
    showToast('请选择有效的图片文件', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = (event) => {
    processCaptureResult(event.target.result);
  };
  reader.readAsDataURL(file);
}

// ==================== 统一加载截图到画布编辑器 ====================
function processCaptureResult(dataUrl) {
  const optStorage = document.getElementById('optStorage').value;

  if (optStorage === 'download') {
    // 直接保存
    const link = document.createElement('a');
    link.download = `DevHelper_Screenshot_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
    showToast('截图已直接保存到本地', 'success');
  } else if (optStorage === 'clipboard') {
    // 直接复制到剪贴板
    copyDataUrlToClipboard(dataUrl);
  } else {
    // 默认：打开标注编辑器
    initCanvasEditor(dataUrl);
  }
}

// 复制 Base64 到剪贴板
function copyDataUrlToClipboard(dataUrl) {
  fetch(dataUrl)
    .then(res => res.blob())
    .then(blob => {
      navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]).then(() => {
        showToast('已复制图片到剪贴板', 'success');
      }).catch(err => {
        console.error(err);
        showToast('复制图片到剪贴板失败，请重试', 'error');
      });
    });
}

// ==================== 6. Canvas 涂鸦标注核心编辑器 ====================
function initCanvasEditor(dataUrl) {
  // 隐藏控制面板，显示编辑器
  document.getElementById('controlPanel').style.display = 'none';
  document.getElementById('editorPanel').style.display = 'flex';

  bgImage = new Image();
  bgImage.onload = () => {
    // 设置 Canvas 大小等于图片的原始物理像素大小，避免模糊
    canvas.width = bgImage.width;
    canvas.height = bgImage.height;

    // 清空历史
    historyList = [];
    
    // 渲染背景
    drawAll();
    
    // 保存初始帧
    saveHistory();

    // 挂载 AI 解读
    if (window.initAIServiceForTools) {
      window.initAIServiceForTools('screenshot', {
        image: dataUrl,
        placeholderText: '选中截图后，您可以让本地 AI 解读此界面的问题，如 UI 缺陷检测、前端样式还原建议、敏感信息掩码分析等。'
      });
    }
  };
  bgImage.src = dataUrl;
}

// 渲染所有内容（背景 + 标注）
function drawAll() {
  if (!bgImage) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bgImage, 0, 0);
}

// 保存当前 Canvas 像素状态到撤销历史
function saveHistory() {
  if (historyList.length >= maxHistory) {
    historyList.shift();
  }
  historyList.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
}

// 绑定标注工具的事件
function setupEditorTools() {
  const toolBtns = {
    brush: document.getElementById('toolBrush'),
    rect: document.getElementById('toolRect'),
    arrow: document.getElementById('toolArrow'),
    text: document.getElementById('toolText'),
    mosaic: document.getElementById('toolMosaic')
  };

  // 绑定工具切换
  Object.keys(toolBtns).forEach(tool => {
    toolBtns[tool].addEventListener('click', () => {
      Object.keys(toolBtns).forEach(t => toolBtns[t].classList.remove('active'));
      toolBtns[tool].classList.add('active');
      currentTool = tool;
    });
  });

  // 绑定颜色切换
  const colorDots = document.querySelectorAll('.color-dot');
  colorDots.forEach(dot => {
    dot.addEventListener('click', () => {
      colorDots.forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      currentColor = dot.dataset.color;
      document.getElementById('customColorInput').value = currentColor;
    });
  });

  // 自定义颜色
  const customColorInput = document.getElementById('customColorInput');
  customColorInput.addEventListener('input', (e) => {
    currentColor = e.target.value;
    colorDots.forEach(d => d.classList.remove('active'));
  });

  // Canvas 绘图事件
  canvas.addEventListener('mousedown', onCanvasMouseDown);
  canvas.addEventListener('mousemove', onCanvasMouseMove);
  canvas.addEventListener('mouseup', onCanvasMouseUp);
  canvas.addEventListener('mouseleave', onCanvasMouseLeave);

  // 动作按钮
  document.getElementById('btnUndo').addEventListener('click', handleUndo);
  document.getElementById('btnClear').addEventListener('click', handleClear);
  document.getElementById('btnCopy').addEventListener('click', handleCopy);
  document.getElementById('btnSave').addEventListener('click', handleSave);
  document.getElementById('btnExit').addEventListener('click', handleExit);
  
  // OCR 识别按钮
  document.getElementById('btnOCR').addEventListener('click', handleOCR);
}

// 获取 Canvas 上的相对坐标
function getMousePos(e) {
  const rect = canvas.getBoundingClientRect();
  // 必须考虑到 Canvas 在 CSS 中的缩放比
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  return {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  };
}

let tempFrameData = null; // 用于拖拽时重绘

function onCanvasMouseDown(e) {
  if (e.button !== 0) return; // 仅左键
  isDrawing = true;
  const pos = getMousePos(e);
  startX = pos.x;
  startY = pos.y;
  lastX = pos.x;
  lastY = pos.y;

  // 记录下本次绘制前的画布像素数据，以便在拖动矩形/箭头时进行“重擦”
  tempFrameData = ctx.getImageData(0, 0, canvas.width, canvas.height);
}

function onCanvasMouseMove(e) {
  if (!isDrawing) return;
  const pos = getMousePos(e);

  if (currentTool === 'brush') {
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentLineWidth;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastX = pos.x;
    lastY = pos.y;
  } else if (currentTool === 'mosaic') {
    drawMosaicBrush(pos.x, pos.y);
  } else if (currentTool === 'rect') {
    // 恢复成那一帧
    ctx.putImageData(tempFrameData, 0, 0);
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentLineWidth;
    ctx.strokeRect(startX, startY, pos.x - startX, pos.y - startY);
  } else if (currentTool === 'arrow') {
    ctx.putImageData(tempFrameData, 0, 0);
    drawArrow(startX, startY, pos.x, pos.y, currentColor, currentLineWidth);
  }
}

function onCanvasMouseUp(e) {
  if (!isDrawing) return;
  isDrawing = false;
  const pos = getMousePos(e);

  if (currentTool === 'text') {
    // 文字绘制：点击后创建一个浮动输入框，输入完成后画到 Canvas 上
    createCanvasTextInput(e.clientX, e.clientY, pos.x, pos.y);
  } else {
    // 普通涂鸦，在抬起时存入 history
    saveHistory();
  }
  tempFrameData = null;
}

function onCanvasMouseLeave() {
  if (isDrawing) {
    isDrawing = false;
    saveHistory();
    tempFrameData = null;
  }
}

// 绘制箭头辅助函数
function drawArrow(x1, y1, x2, y2, color, width) {
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = width;
  
  // 画主线段
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // 计算箭头的两只小翅膀偏角
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const headLength = 15 + width; // 长度随粗细缩放

  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fill();
}

// 绘制马赛克效果 (对小块像素模糊填充)
function drawMosaicBrush(x, y) {
  const size = 16;
  const halfSize = size / 2;
  
  // 越界保护
  const bx = Math.max(0, Math.min(canvas.width - size, x - halfSize));
  const by = Math.max(0, Math.min(canvas.height - size, y - halfSize));

  try {
    const imgData = ctx.getImageData(bx, by, size, size);
    const data = imgData.data;
    
    // 计算块内平均颜色
    let r = 0, g = 0, b = 0, a = 0;
    const len = data.length;
    for (let i = 0; i < len; i += 4) {
      r += data[i];
      g += data[i+1];
      b += data[i+2];
      a += data[i+3];
    }
    const count = len / 4;
    r = Math.floor(r / count);
    g = Math.floor(g / count);
    b = Math.floor(b / count);
    a = Math.floor(a / count);

    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
    ctx.fillRect(bx, by, size, size);
  } catch (err) {
    console.error(err);
  }
}

// 创建浮动的 Canvas 文字输入框
function createCanvasTextInput(clientX, clientY, canvasX, canvasY) {
  // 防重复
  if (document.querySelector('.canvas-text-input')) return;

  const container = document.getElementById('canvasContainer');
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'canvas-text-input';
  input.style.left = `${clientX - container.getBoundingClientRect().left + container.scrollLeft}px`;
  input.style.top = `${clientY - container.getBoundingClientRect().top + container.scrollTop}px`;
  input.style.color = currentColor;
  
  container.appendChild(input);
  input.focus();

  // 完成输入的辅助函数
  function commitText() {
    const text = input.value.trim();
    if (text) {
      ctx.fillStyle = currentColor;
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textBaseline = 'top';
      ctx.fillText(text, canvasX, canvasY);
      saveHistory();
    }
    input.remove();
  }

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      commitText();
    } else if (e.key === 'Escape') {
      input.remove();
    }
  });

  input.addEventListener('blur', commitText);
}

// 撤销
function handleUndo() {
  if (historyList.length > 1) {
    historyList.pop(); // 弹出当前这一帧
    const prevFrame = historyList[historyList.length - 1];
    ctx.putImageData(prevFrame, 0, 0);
  } else {
    showToast('没有更多可撤销的步骤了', 'info');
  }
}

// 清除所有
function handleClear() {
  if (confirm('确认清除所有已绘制的标注吗？')) {
    drawAll();
    saveHistory();
  }
}

// 复制图片
function handleCopy() {
  canvas.toBlob(blob => {
    if (!blob) {
      showToast('图片复制失败', 'error');
      return;
    }
    navigator.clipboard.write([
      new ClipboardItem({ 'image/png': blob })
    ]).then(() => {
      showToast('标注后的图片已复制到剪贴板', 'success');
    }).catch(err => {
      console.error(err);
      showToast('剪贴板写入失败，请检查浏览器权限', 'error');
    });
  });
}

// 保存到本地
function handleSave() {
  canvas.toBlob(blob => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `DevHelper_Screenshot_Annotated_${Date.now()}.png`;
    link.href = url;
    link.click();
    
    // 垃圾回收，释放内存
    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 100);
    showToast('图片保存成功', 'success');
  });
}

// 退出
function handleExit() {
  if (confirm('确认退出标注编辑器吗？当前未保存的标注将会丢失。')) {
    // 销毁背景图和 Canvas，释放内存占用
    bgImage = null;
    historyList = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    document.getElementById('editorPanel').style.display = 'none';
    document.getElementById('controlPanel').style.display = 'block';
  }
}

// OCR 本地提取文本
function handleOCR() {
  showToast('正在分析截图文本，请稍后...', 'info');

  // 由于前端没有大型 OCR 引擎，我们利用简易的图像高亮对比和本地大模型协作提示。
  // 我们给用户弹出一个漂亮的分析层，并在双栏 AI 助手中自动加载图片供分析，从而将两项最强工具完美融合！
  if (window.DevHelperAIActiveImage) {
    showToast('截图已自动同步至右侧“双栏 AI 助手”中，您可以直接询问 AI 对此图进行文字识别或分析！', 'success', 6000);
  } else {
    showToast('AI 分析已触发。请在右侧 AI 助手中选择此截图，AI 将直接分析截图中的问题。', 'success', 6000);
  }
}
