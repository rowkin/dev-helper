/**
 * DevHelper - 万能计算器工具脚本
 * 功能包括：标准与科学计算器（安全数学表达式解析）、实时汇率换算（含 API 刷新与本地备份降级）、房贷还款计划推演
 */

document.addEventListener('DOMContentLoaded', () => {
  // ─── 统一初始化 ───
  initTabs();
  initCalculator();
  initExchange();
  initLoan();
  initAIPanel();
});

// ─── 选项卡切换逻辑 ───
let currentTabId = 'calculator';
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.calc-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      currentTabId = tab;
      
      tabBtns.forEach(b => b.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(`panel-${tab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

// ─── 模块一：安全数学表达式解析与计算器 ───
let isScientificMode = false;
let currentFormula = '';
let isLastCharOperator = false;

// 预设按键列表
const STANDARD_KEYS = [
  { label: 'C', class: 'clear' },
  { label: '(', class: 'op' },
  { label: ')', class: 'op' },
  { label: '⌫', class: 'clear', action: 'backspace' },
  { label: '7', class: 'num' },
  { label: '8', class: 'num' },
  { label: '9', class: 'num' },
  { label: '÷', class: 'op' },
  { label: '4', class: 'num' },
  { label: '5', class: 'num' },
  { label: '6', class: 'num' },
  { label: '×', class: 'op' },
  { label: '1', class: 'num' },
  { label: '2', class: 'num' },
  { label: '3', class: 'num' },
  { label: '-', class: 'op' },
  { label: '0', class: 'num' },
  { label: '.', class: 'num' },
  { label: '=', class: 'eq' },
  { label: '+', class: 'op' }
];

const SCIENTIFIC_KEYS = [
  { label: 'sin', class: 'sci' },
  { label: 'cos', class: 'sci' },
  { label: 'tan', class: 'sci' },
  { label: 'C', class: 'clear' },
  { label: '⌫', class: 'clear', action: 'backspace' },
  
  { label: 'ln', class: 'sci' },
  { label: 'log', class: 'sci' },
  { label: '^', class: 'op' },
  { label: '(', class: 'op' },
  { label: ')', class: 'op' },
  
  { label: '√', class: 'sci', value: 'sqrt(' },
  { label: '7', class: 'num' },
  { label: '8', class: 'num' },
  { label: '9', class: 'num' },
  { label: '÷', class: 'op' },
  
  { label: 'π', class: 'sci' },
  { label: '4', class: 'num' },
  { label: '5', class: 'num' },
  { label: '6', class: 'num' },
  { label: '×', class: 'op' },
  
  { label: 'e', class: 'sci' },
  { label: '1', class: 'num' },
  { label: '2', class: 'num' },
  { label: '3', class: 'num' },
  { label: '-', class: 'op' },
  
  { label: '%', class: 'op' },
  { label: '0', class: 'num' },
  { label: '.', class: 'num' },
  { label: '=', class: 'eq' },
  { label: '+', class: 'op' }
];

function initCalculator() {
  const grid = document.getElementById('calcGrid');
  const btnToggle = document.getElementById('btnToggleScience');
  
  // 切换科学模式
  btnToggle.addEventListener('click', () => {
    isScientificMode = !isScientificMode;
    btnToggle.textContent = isScientificMode ? '返回标准计算' : '切换科学计算';
    renderCalcGrid();
  });

  renderCalcGrid();
  bindKeyboardEvents();
}

function renderCalcGrid() {
  const grid = document.getElementById('calcGrid');
  grid.innerHTML = '';
  
  if (isScientificMode) {
    grid.className = 'calc-grid scientific';
    SCIENTIFIC_KEYS.forEach(key => grid.appendChild(createCalcButton(key)));
  } else {
    grid.className = 'calc-grid';
    STANDARD_KEYS.forEach(key => grid.appendChild(createCalcButton(key)));
  }
}

function createCalcButton(key) {
  const btn = document.createElement('button');
  btn.className = `calc-btn ${key.class}`;
  btn.textContent = key.label;
  
  btn.addEventListener('click', () => {
    handleCalcInput(key.value || key.label, key.action);
  });
  
  return btn;
}

function handleCalcInput(value, action) {
  const formulaEl = document.getElementById('calcFormula');
  const resultEl = document.getElementById('calcResult');
  
  if (action === 'backspace') {
    // 退格
    if (currentFormula.length > 0) {
      // 如果删除的是诸如 sin(, cos(, sqrt( 等函数，我们尝试一次性删掉它们
      const functions = ['sin(', 'cos(', 'tan(', 'sqrt(', 'log(', 'ln('];
      let deleted = false;
      for (const fn of functions) {
        if (currentFormula.endsWith(fn)) {
          currentFormula = currentFormula.substring(0, currentFormula.length - fn.length);
          deleted = true;
          break;
        }
      }
      if (!deleted) {
        currentFormula = currentFormula.slice(0, -1);
      }
    }
  } else if (value === 'C') {
    // 清空
    currentFormula = '';
    resultEl.textContent = '0';
  } else if (value === '=') {
    // 执行计算
    if (!currentFormula.trim()) return;
    try {
      const res = safeEvaluate(currentFormula);
      // 格式化输出，处理浮点数精度问题，如 0.1 + 0.2
      if (typeof res === 'number') {
        if (Number.isNaN(res)) {
          resultEl.textContent = 'NaN';
        } else if (!Number.isFinite(res)) {
          resultEl.textContent = 'Infinity';
        } else {
          // 限制最多 10 位小数以防溢出
          resultEl.textContent = parseFloat(res.toFixed(10)).toString();
        }
      } else {
        resultEl.textContent = res;
      }
    } catch (err) {
      resultEl.textContent = 'Error';
      console.error('计算错误：', err);
    }
    return;
  } else {
    // 追加算式
    // 防止连续输入两个运算符
    const ops = ['+', '-', '×', '÷', '%', '^'];
    const valIsOp = ops.includes(value);
    
    if (valIsOp && currentFormula.length === 0 && value !== '-') {
      // 初始不能输入除负号外的运算符
      return;
    }
    
    const lastChar = currentFormula[currentFormula.length - 1];
    const lastCharIsOp = ops.includes(lastChar);
    
    if (valIsOp && lastCharIsOp) {
      // 连续操作符，则替换最后一个
      currentFormula = currentFormula.slice(0, -1) + value;
    } else {
      // 函数类追加
      if (['sin', 'cos', 'tan', 'ln', 'log'].includes(value)) {
        currentFormula += value + '(';
      } else {
        currentFormula += value;
      }
    }
  }
  
  formulaEl.textContent = currentFormula;
}

// 绑定物理键盘按键
function bindKeyboardEvents() {
  document.addEventListener('keydown', (e) => {
    if (currentTabId !== 'calculator') return;
    
    // 如果焦点在输入框（比如 AI 侧边栏的搜索），则不接管键盘
    if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
      return;
    }

    const key = e.key;
    if (/[0-9.]/.test(key)) {
      handleCalcInput(key);
    } else if (key === '+') {
      handleCalcInput('+');
    } else if (key === '-') {
      handleCalcInput('-');
    } else if (key === '*') {
      handleCalcInput('×');
    } else if (key === '/') {
      e.preventDefault();
      handleCalcInput('÷');
    } else if (key === '%') {
      handleCalcInput('%');
    } else if (key === '^') {
      handleCalcInput('^');
    } else if (key === '(' || key === ')') {
      handleCalcInput(key);
    } else if (key === 'Enter' || key === '=') {
      e.preventDefault();
      handleCalcInput('=');
    } else if (key === 'Backspace') {
      handleCalcInput(null, 'backspace');
    } else if (key === 'Escape') {
      handleCalcInput('C');
    }
  });
}

// ─── 纯 JS 安全数学解析器实现 (Shunting-yard + RPN) ───
function safeEvaluate(expression) {
  let expr = expression
    .replace(/×/g, '*')
    .replace(/÷/g, '/');

  // 补全括号，防止少输入括号报错
  let openBrackets = 0;
  for (let i = 0; i < expr.length; i++) {
    if (expr[i] === '(') openBrackets++;
    if (expr[i] === ')') openBrackets--;
  }
  while (openBrackets > 0) {
    expr += ')';
    openBrackets--;
  }

  // 隐式乘法自动补全
  // 1) 数字 后面紧跟 字母(函数/e)、π、左括号
  expr = expr.replace(/(\d)(?=[a-zA-Z\(π])/g, '$1*');
  // 2) π 后面紧跟 数字、字母、左括号
  expr = expr.replace(/(π)(?=[0-9a-zA-Z\(])/g, '$1*');
  // 3) e 后面紧跟 数字、字母、左括号
  expr = expr.replace(/(e)(?=[0-9a-zA-Z\(])/g, '$1*');
  // 4) 右括号 后面紧跟 数字、字母、π、左括号
  expr = expr.replace(/(\))(?=[0-9a-zA-Z\(π])/g, '$1*');

  // Tokenize
  const tokens = [];
  let i = 0;
  while (i < expr.length) {
    const c = expr[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    
    if (['(', ')', '+', '-', '*', '/', '%', '^'].includes(c)) {
      // 区分减号与负号：如果 - 处于最前，或者前一个 token 是操作符/左括号，则判定为单目负号
      if (c === '-') {
        const lastToken = tokens[tokens.length - 1];
        if (tokens.length === 0 || ['+', '-', '*', '/', '%', '^', '('].includes(lastToken)) {
          tokens.push('neg');
          i++;
          continue;
        }
      }
      tokens.push(c);
      i++;
    } else if (/[0-9.]/.test(c)) {
      let numStr = '';
      while (i < expr.length && /[0-9.]/.test(expr[i])) {
        numStr += expr[i];
        i++;
      }
      tokens.push(parseFloat(numStr));
    } else if (/[a-zA-Z]/.test(c)) {
      let funcStr = '';
      while (i < expr.length && /[a-zA-Z]/.test(expr[i])) {
        funcStr += expr[i];
        i++;
      }
      tokens.push(funcStr);
    } else if (c === 'π') {
      tokens.push(Math.PI);
      i++;
    } else {
      i++; // 忽略其他不支持的字符
    }
  }

  // Shunting-yard 转换逆波兰表达式
  const outputQueue = [];
  const operatorStack = [];
  const operators = {
    '+': { precedence: 2, associativity: 'Left' },
    '-': { precedence: 2, associativity: 'Left' },
    '*': { precedence: 3, associativity: 'Left' },
    '/': { precedence: 3, associativity: 'Left' },
    '%': { precedence: 3, associativity: 'Left' },
    '^': { precedence: 4, associativity: 'Right' },
    'neg': { precedence: 5, associativity: 'Right' }
  };
  const functions = ['sin', 'cos', 'tan', 'sqrt', 'log', 'ln'];

  for (const token of tokens) {
    if (typeof token === 'number') {
      outputQueue.push(token);
    } else if (functions.includes(token)) {
      operatorStack.push(token);
    } else if (token in operators) {
      const o1 = token;
      let o2 = operatorStack[operatorStack.length - 1];
      while (
        o2 &&
        (o2 in operators || functions.includes(o2)) &&
        (functions.includes(o2) ||
          (operators[o1].associativity === 'Left' && operators[o1].precedence <= operators[o2].precedence) ||
          (operators[o1].associativity === 'Right' && operators[o1].precedence < operators[o2].precedence))
      ) {
        outputQueue.push(operatorStack.pop());
        o2 = operatorStack[operatorStack.length - 1];
      }
      operatorStack.push(o1);
    } else if (token === '(') {
      operatorStack.push(token);
    } else if (token === ')') {
      let top = operatorStack[operatorStack.length - 1];
      while (top && top !== '(') {
        outputQueue.push(operatorStack.pop());
        top = operatorStack[operatorStack.length - 1];
      }
      if (!top) throw new Error('括号不匹配');
      operatorStack.pop(); // 弹出 '('
      if (functions.includes(operatorStack[operatorStack.length - 1])) {
        outputQueue.push(operatorStack.pop());
      }
    }
  }

  while (operatorStack.length > 0) {
    const top = operatorStack.pop();
    if (top === '(' || top === ')') throw new Error('括号不匹配');
    outputQueue.push(top);
  }

  // RPN 求值
  const stack = [];
  const mathFuncs = {
    'sin': (x) => Math.sin(x * Math.PI / 180),
    'cos': (x) => Math.cos(x * Math.PI / 180),
    'tan': (x) => Math.tan(x * Math.PI / 180),
    'sqrt': (x) => {
      if (x < 0) throw new Error('负数不能求平方根');
      return Math.sqrt(x);
    },
    'log': (x) => {
      if (x <= 0) throw new Error('对数自变量必须大于0');
      return Math.log10(x);
    },
    'ln': (x) => {
      if (x <= 0) throw new Error('对数自变量必须大于0');
      return Math.log(x);
    }
  };

  for (const token of outputQueue) {
    if (typeof token === 'number') {
      stack.push(token);
    } else if (token === 'neg') {
      const x = stack.pop();
      if (x === undefined) throw new Error('表达式不完整');
      stack.push(-x);
    } else if (token in mathFuncs) {
      const x = stack.pop();
      if (x === undefined) throw new Error('表达式不完整');
      stack.push(mathFuncs[token](x));
    } else {
      const b = stack.pop();
      const a = stack.pop();
      if (a === undefined || b === undefined) throw new Error('表达式不完整');
      switch (token) {
        case '+': stack.push(a + b); break;
        case '-': stack.push(a - b); break;
        case '*': stack.push(a * b); break;
        case '/':
          if (b === 0) throw new Error('除数不能为零');
          stack.push(a / b);
          break;
        case '%': stack.push(a % b); break;
        case '^': stack.push(Math.pow(a, b)); break;
      }
    }
  }

  if (stack.length !== 1) throw new Error('语法错误');
  return stack[0];
}

// ─── 模块二：汇率换算逻辑 ───
// 降级本地硬编码汇率，以 USD 为基准
const DEFAULT_RATES = {
  "USD": 1.0,
  "CNY": 7.258,
  "EUR": 0.918,
  "JPY": 156.24,
  "GBP": 0.785,
  "HKD": 7.812,
  "AUD": 1.505,
  "CAD": 1.368,
  "SGD": 1.348,
  "KRW": 1378.5
};

const CURRENCY_NAMES = {
  "CNY": "人民币 (CNY)",
  "USD": "美元 (USD)",
  "EUR": "欧元 (EUR)",
  "JPY": "日元 (JPY)",
  "GBP": "英镑 (GBP)",
  "HKD": "港币 (HKD)",
  "AUD": "澳元 (AUD)",
  "CAD": "加拿大元 (CAD)",
  "SGD": "新加坡元 (SGD)",
  "KRW": "韩元 (KRW)"
};

let activeRates = { ...DEFAULT_RATES };
let ratesLastUpdate = "2026-07-16 00:00:00 (本地预设)";
let isOfflineMode = false;

async function initExchange() {
  const fromSelect = document.getElementById('exchangeFromCurrency');
  const toSelect = document.getElementById('exchangeToCurrency');
  
  // 初始化下拉框选项
  Object.keys(CURRENCY_NAMES).forEach(code => {
    const optFrom = document.createElement('option');
    optFrom.value = code;
    optFrom.textContent = CURRENCY_NAMES[code];
    if (code === 'USD') optFrom.selected = true;
    fromSelect.appendChild(optFrom);

    const optTo = document.createElement('option');
    optTo.value = code;
    optTo.textContent = CURRENCY_NAMES[code];
    if (code === 'CNY') optTo.selected = true;
    toSelect.appendChild(optTo);
  });

  // 绑定事件
  document.getElementById('exchangeFromAmount').addEventListener('input', () => {
    convertCurrency('from');
  });
  document.getElementById('exchangeToAmount').addEventListener('input', () => {
    convertCurrency('to');
  });
  fromSelect.addEventListener('change', () => convertCurrency('from'));
  toSelect.addEventListener('change', () => convertCurrency('from'));
  
  // 交换货币
  document.getElementById('btnSwapCurrency').addEventListener('click', () => {
    const tmp = fromSelect.value;
    fromSelect.value = toSelect.value;
    toSelect.value = tmp;
    
    const fromVal = parseFloat(document.getElementById('exchangeFromAmount').value) || 0;
    const toVal = parseFloat(document.getElementById('exchangeToAmount').value) || 0;
    
    document.getElementById('exchangeFromAmount').value = toVal;
    document.getElementById('exchangeToAmount').value = fromVal;
    
    convertCurrency('from');
  });

  document.getElementById('btnRefreshExchange').addEventListener('click', () => {
    fetchRates(true);
  });

  // 首次获取汇率
  await fetchRates(false);
}

// 核心转换逻辑
function convertCurrency(direction = 'from') {
  const fromSelect = document.getElementById('exchangeFromCurrency');
  const toSelect = document.getElementById('exchangeToCurrency');
  const fromInput = document.getElementById('exchangeFromAmount');
  const toInput = document.getElementById('exchangeToAmount');

  const fromCode = fromSelect.value;
  const toCode = toSelect.value;
  
  const rateFromUsd = activeRates[fromCode];
  const rateToUsd = activeRates[toCode];
  
  if (!rateFromUsd || !rateToUsd) return;

  // 汇率转换计算： 1 unit of A = (rateToUsd / rateFromUsd) unit of B
  if (direction === 'from') {
    const val = parseFloat(fromInput.value);
    if (Number.isNaN(val) || val < 0) {
      toInput.value = '';
      return;
    }
    const result = val * (rateToUsd / rateFromUsd);
    toInput.value = parseFloat(result.toFixed(4));
  } else {
    const val = parseFloat(toInput.value);
    if (Number.isNaN(val) || val < 0) {
      fromInput.value = '';
      return;
    }
    const result = val * (rateFromUsd / rateToUsd);
    fromInput.value = parseFloat(result.toFixed(4));
  }
}

// 获取汇率数据并做完备降级处理
async function fetchRates(isManual = false) {
  const statusEl = document.getElementById('exchangeStatus');
  statusEl.className = 'exchange-status';
  statusEl.textContent = '正在获取实时汇率数据...';

  try {
    const res = await fetch('https://open.er-api.com/v6/latest/USD');
    if (!res.ok) throw new Error('网络请求异常');
    
    const data = await res.json();
    if (data.result === 'success' && data.rates) {
      // 成功获取
      activeRates = {};
      Object.keys(DEFAULT_RATES).forEach(code => {
        if (data.rates[code]) {
          activeRates[code] = data.rates[code];
        } else {
          activeRates[code] = DEFAULT_RATES[code]; // API 漏掉的，用本地预设补充
        }
      });
      
      ratesLastUpdate = data.time_last_update_utc || new Date().toUTCString();
      isOfflineMode = false;
      
      // 保存至 chrome.storage 做缓存
      if (typeof chrome !== 'undefined' && chrome.storage) {
        try {
          await chrome.storage.local.set({
            'exchange_rates_cache': activeRates,
            'exchange_rates_update_time': ratesLastUpdate,
            'exchange_rates_fetch_time': Date.now()
          });
        } catch (e) {
          console.warn('保存汇率缓存失败：', e);
        }
      }
      
      statusEl.textContent = `实时汇率由 Open Exchange Rates API 提供，更新于：${ratesLastUpdate}`;
      if (isManual && typeof showToast !== 'undefined') {
        showToast('汇率数据已刷新');
      }
    } else {
      throw new Error('API 返回数据格式错误');
    }
  } catch (err) {
    console.warn('获取汇率接口失败，启用降级方案：', err);
    isOfflineMode = true;
    
    // 尝试读取本地 chrome.storage 缓存
    let loadedFromCache = false;
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        const cached = await chrome.storage.local.get(['exchange_rates_cache', 'exchange_rates_update_time']);
        if (cached.exchange_rates_cache) {
          activeRates = cached.exchange_rates_cache;
          ratesLastUpdate = cached.exchange_rates_update_time;
          statusEl.className = 'exchange-status offline';
          statusEl.textContent = `⚠️ 网络连接失败，已加载本地缓存汇率（更新于：${ratesLastUpdate}）`;
          loadedFromCache = true;
        }
      } catch (e) {
        console.warn('读取汇率缓存失败：', e);
      }
    }
    
    if (!loadedFromCache) {
      // 若缓存无，则使用出厂预设
      activeRates = { ...DEFAULT_RATES };
      ratesLastUpdate = "2026-07-16 00:00:00 (出厂硬编码备份)";
      statusEl.className = 'exchange-status offline';
      statusEl.textContent = `⚠️ 无法连接实时汇率服务，已自动启用离线备份汇率（更新于：${ratesLastUpdate}）`;
    }
  }

  // 渲染常用汇率表格与更新计算
  renderRatesTable();
  convertCurrency('from');
}

// 渲染常用汇率表格
function renderRatesTable() {
  const grid = document.getElementById('exchangeRatesGrid');
  grid.innerHTML = '';
  
  const table = document.createElement('table');
  table.className = 'loan-result-table';
  table.innerHTML = `
    <thead>
      <tr>
        <th>货币代码</th>
        <th>货币名称</th>
        <th>当前汇率 (以 1 USD 为基底)</th>
        <th>100 人民币 (CNY) 可兑换</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  
  const tbody = table.querySelector('tbody');
  const cnyRate = activeRates['CNY'];
  
  Object.keys(CURRENCY_NAMES).forEach(code => {
    if (code === 'CNY') return; // 不对比 CNY 自己
    
    const rateVal = activeRates[code];
    // 100 CNY 可以换多少： 100 * (rateVal / cnyRate)
    const converted = 100 * (rateVal / cnyRate);
    
    const row = document.createElement('tr');
    row.innerHTML = `
      <td style="font-weight:700">${code}</td>
      <td>${CURRENCY_NAMES[code].split(' ')[0]}</td>
      <td>${parseFloat(rateVal.toFixed(4))}</td>
      <td style="color:var(--primary);font-weight:700">${parseFloat(converted.toFixed(2))} ${code}</td>
    `;
    tbody.appendChild(row);
  });
  
  grid.appendChild(table);
}

// ─── 模块三：房贷还款计划推演 ───
function initLoan() {
  const yearsSelect = document.getElementById('loanYearsSelect');
  const customMonthsInput = document.getElementById('loanMonthsCustom');
  
  yearsSelect.addEventListener('change', () => {
    if (yearsSelect.value === 'custom') {
      customMonthsInput.style.display = 'block';
      customMonthsInput.focus();
    } else {
      customMonthsInput.style.display = 'none';
    }
  });

  document.getElementById('btnCalculateLoan').addEventListener('click', calculateLoanPlan);
}

function calculateLoanPlan() {
  const amountVal = parseFloat(document.getElementById('loanAmount').value);
  const yearsSelect = document.getElementById('loanYearsSelect');
  const customMonthsInput = document.getElementById('loanMonthsCustom');
  const rateVal = parseFloat(document.getElementById('loanRate').value);
  const method = document.getElementById('loanMethod').value;
  
  let months = 0;
  if (yearsSelect.value === 'custom') {
    months = parseInt(customMonthsInput.value, 10);
  } else {
    months = parseInt(yearsSelect.value, 10) * 12;
  }
  
  // 参数安全校验
  if (Number.isNaN(amountVal) || amountVal <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入有效的贷款本金', 'error');
    return;
  }
  if (Number.isNaN(months) || months <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入正确的还款期数（月数）', 'error');
    return;
  }
  if (Number.isNaN(rateVal) || rateVal <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入正确的年化利率', 'error');
    return;
  }

  const principal = amountVal * 10000; // 万元转元
  const annualRate = rateVal / 100;
  const monthlyRate = annualRate / 12; // 月利率
  
  const tbody = document.getElementById('loanResultBody');
  tbody.innerHTML = '';

  const firstMonthLabel = document.getElementById('firstMonthLabel');
  const decreaseLabel = document.getElementById('decreaseLabel');
  
  let totalInterest = 0;
  let totalRepay = 0;
  let firstMonthPay = 0;
  let monthlyDecrease = 0;
  
  const listData = [];
  
  if (method === 'acpi') {
    // 1. 等额本息
    firstMonthLabel.textContent = '每月月供';
    decreaseLabel.textContent = '月供性质';
    
    // 每月月供公式: [P * R * (1 + R)^N] / [(1 + R)^N - 1]
    const monthlyPay = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    firstMonthPay = monthlyPay;
    monthlyDecrease = 0; // 等额本息每月无递减
    
    document.getElementById('summaryDecrease').textContent = '固定额度';
    
    let remainingPrincipal = principal;
    let accumulatedPrincipal = 0;
    let accumulatedInterest = 0;
    
    // 计算利息总和
    totalRepay = monthlyPay * months;
    totalInterest = totalRepay - principal;

    for (let m = 1; m <= months; m++) {
      const interest = remainingPrincipal * monthlyRate; // 当期利息
      const principalPaid = monthlyPay - interest; // 当期本金
      
      accumulatedPrincipal += principalPaid;
      accumulatedInterest += interest;
      remainingPrincipal -= principalPaid;
      
      // 避免剩余本金由于浮点数产生细微负数
      const displayRemainingPrincipal = Math.max(0, remainingPrincipal);
      // 剩余总利息
      const displayRemainingInterest = Math.max(0, totalInterest - accumulatedInterest);

      listData.push({
        num: m,
        monthlyPay: monthlyPay,
        principalPaid: principalPaid,
        interestPaid: interest,
        accumulatedPrincipal: accumulatedPrincipal,
        accumulatedInterest: accumulatedInterest,
        remainingPrincipal: displayRemainingPrincipal,
        remainingInterest: displayRemainingInterest
      });
    }
  } else {
    // 2. 等额本金
    firstMonthLabel.textContent = '首月月供';
    decreaseLabel.textContent = '每月递减';
    
    // 每月本金固定
    const principalPerMonth = principal / months;
    let remainingPrincipal = principal;
    let accumulatedPrincipal = 0;
    let accumulatedInterest = 0;
    
    // 每月递减额: 每月应还本金 * 月利率
    monthlyDecrease = principalPerMonth * monthlyRate;
    document.getElementById('summaryDecrease').textContent = `${monthlyDecrease.toFixed(2)} 元`;
    
    // 先跑出全期的数据用以求得利息总和
    const tempPayments = [];
    for (let m = 1; m <= months; m++) {
      const interest = remainingPrincipal * monthlyRate; // 当期利息
      const monthlyPay = principalPerMonth + interest; // 当期月供
      
      accumulatedPrincipal += principalPerMonth;
      accumulatedInterest += interest;
      remainingPrincipal -= principalPerMonth;
      
      tempPayments.push({
        num: m,
        monthlyPay: monthlyPay,
        principalPaid: principalPerMonth,
        interestPaid: interest,
        accumulatedPrincipal: accumulatedPrincipal,
        accumulatedInterest: accumulatedInterest,
        remainingPrincipal: Math.max(0, remainingPrincipal)
      });
    }
    
    totalInterest = accumulatedInterest;
    totalRepay = principal + totalInterest;
    firstMonthPay = tempPayments[0].monthlyPay;
    
    tempPayments.forEach(p => {
      listData.push({
        ...p,
        remainingInterest: Math.max(0, totalInterest - p.accumulatedInterest)
      });
    });
  }
  
  // 更新四个汇总大字卡
  document.getElementById('summaryFirstMonth').textContent = `${firstMonthPay.toFixed(2)} 元`;
  document.getElementById('summaryTotalInterest').textContent = `${(totalInterest / 10000).toFixed(2)} 万元`;
  document.getElementById('summaryTotalRepay').textContent = `${(totalRepay / 10000).toFixed(2)} 万元`;
  
  // 渲染汇总表头及合计行
  const totalRow = document.createElement('tr');
  totalRow.className = 'total-row';
  totalRow.innerHTML = `
    <td>合计</td>
    <td>${(totalRepay / 10000).toFixed(2)} 万元</td>
    <td>${(principal / 10000).toFixed(2)} 万元</td>
    <td>${(totalInterest / 10000).toFixed(2)} 万元</td>
    <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">以汇总值为准 · 详细推演如下</td>
  `;
  tbody.appendChild(totalRow);
  
  // 循环插入每期还款行
  listData.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>第 ${item.num} 期</td>
      <td style="font-weight:600;color:var(--text-primary)">${item.monthlyPay.toFixed(2)} 元</td>
      <td>${item.principalPaid.toFixed(2)} 元</td>
      <td>${item.interestPaid.toFixed(2)} 元</td>
      <td>${item.accumulatedPrincipal.toFixed(2)} 元</td>
      <td>${item.accumulatedInterest.toFixed(2)} 元</td>
      <td>${item.remainingPrincipal.toFixed(2)} 元</td>
      <td>${item.remainingInterest.toFixed(2)} 元</td>
    `;
    tbody.appendChild(row);
  });
  
  if (typeof showToast !== 'undefined') {
    showToast('房贷计划多维推演成功');
  }
}

// ─── 模块四：AI 智能诊断面板 ───
function initAIPanel() {
  const getContext = () => {
    let contextStr = `【万能计算器 - 当前所处面板】：${currentTabId === 'calculator' ? '标准/科学计算器' : currentTabId === 'exchange' ? '实时汇率换算' : '房贷还款多维推演'}\n`;
    
    if (currentTabId === 'calculator') {
      const formula = document.getElementById('calcFormula').textContent;
      const result = document.getElementById('calcResult').textContent;
      contextStr += `当前算式表达式：${formula || '未输入'}\n`;
      contextStr += `实时计算结果：${result}\n`;
    } else if (currentTabId === 'exchange') {
      const fromSelect = document.getElementById('exchangeFromCurrency');
      const toSelect = document.getElementById('exchangeToCurrency');
      const fromInput = document.getElementById('exchangeFromAmount');
      const toInput = document.getElementById('exchangeToAmount');
      
      contextStr += `源币种：${fromSelect.value}，数量：${fromInput.value}\n`;
      contextStr += `目标币种：${toSelect.value}，转换额：${toInput.value}\n`;
      contextStr += `数据状态信息：${document.getElementById('exchangeStatus').textContent}\n`;
      contextStr += `所有币种最新汇率表一览（以美元USD为基准）：\n`;
      Object.keys(activeRates).forEach(k => {
        contextStr += `- ${k}: ${activeRates[k]}\n`;
      });
    } else if (currentTabId === 'loan') {
      const amountVal = document.getElementById('loanAmount').value;
      const yearsSelect = document.getElementById('loanYearsSelect');
      const rateVal = document.getElementById('loanRate').value;
      const method = document.getElementById('loanMethod').value;
      
      contextStr += `贷款总额：${amountVal} 万元\n`;
      contextStr += `贷款年限选择：${yearsSelect.value}年（或自定义月数）\n`;
      contextStr += `执行年化利率：${rateVal} %\n`;
      contextStr += `采用的还款方式：${method === 'acpi' ? '等额本息 (每月固定)' : '等额本金 (逐月递减)'}\n`;
      
      const firstMonth = document.getElementById('summaryFirstMonth').textContent;
      const decrease = document.getElementById('summaryDecrease').textContent;
      const totalInt = document.getElementById('summaryTotalInterest').textContent;
      const totalRepay = document.getElementById('summaryTotalRepay').textContent;
      
      contextStr += `推演概览结果：\n`;
      contextStr += `- 首月/月供金额：${firstMonth}\n`;
      contextStr += `- 每月递减金额：${decrease}\n`;
      contextStr += `- 累计支付利息：${totalInt}\n`;
      contextStr += `- 累计本息还款额：${totalRepay}\n`;
    }
    
    return contextStr;
  };

  const systemPrompt = `你是一个资深的数学解析、国际汇率结算与房贷财务多维推演专家顾问。
请根据用户在当前 DevHelper 「万能计算器」中操作生成的各项指标上下文数据（例如当前的算式输入、最新国际汇率折算比例、或房贷本息偿还计划汇总），为您提供专业的 AI 智能分析：
1. 如果是计算器模块，请对用户输入的公式的数学意义、应用场景进行智能剖析，或者在算式过于复杂时提供化简思路或相关常识说明。
2. 如果是汇率换算模块，请提供关于所选币种（如 CNY、USD、EUR 等）当前的宏观经济兑换背景、汇率机制常识、旅游/海淘/跨境支付的小贴士。
3. 如果是房贷月供推演模块，请基于等额本息和等额本金两种还款路径的利息落差，为用户提供直观的理财分析。分析杠杆效应、利率走势对家庭财务支出的影响，以及什么情况下建议选择提前还贷或理财平衡。
请使用清晰的 Markdown 排版，使用直观的列表或对比表格呈现，使分析报告兼备科学性、商业智慧和极佳的可读性。`;

  // 调用公共 common.js 中封装好的 inline AIPanel 机制
  if (typeof createInlineAIPanel !== 'undefined') {
    createInlineAIPanel('aiPanelMount', getContext, systemPrompt);
  }
}
