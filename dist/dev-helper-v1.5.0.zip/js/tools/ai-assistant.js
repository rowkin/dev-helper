/**
 * AI 助手页面逻辑
 * 提取自 pages/ai-assistant.html，符合 Chrome MV3 CSP 要求
 * 功能：多会话管理、流式输出、Markdown 渲染、快捷提示、历史记录
 */

// 等待 DOM 和所有依赖脚本加载完毕再执行
document.addEventListener('DOMContentLoaded', () => {
  let lastGeneratedQR = ''; // 用于缓存由 generate_qrcode 生成的最新的二维码 Base64 数据
  let lastGeneratedScreenshot = ''; // 用于缓存由 capture_webpage_screenshot 生成的最新的截图 Base64 数据

  // 初始化主题（由 common.js 提供）
  if (typeof initTheme === 'function') initTheme();

  const SYSTEM_PROMPT = `你是 DevHelper AI，七九在线科技的专属技术助手。
你擅长：前端开发（Vue/React/JavaScript/CSS）、后端开发、API 调试、代码审查、性能优化、数据库查询等。
回答要求：
1. 优先给出可直接使用的代码示例
2. 代码块使用 Markdown 代码格式（\`\`\`language ... \`\`\`）
3. 回答简洁准确，重点突出
4. 如果遇到模糊问题，先理解再给出最优答案
5. 请务必使用简体中文进行回答，若有英文术语或原代码，进行翻译或提供双语对照形式展示。`;

  const DEV_HELPER_TOOLS_MANIFEST = [
    { id: 'ip-speed', name: 'IP 与网速检测', path: 'pages/ip-speed.html', desc: '检测局域网/公网IP、Ping延迟、抖动及上传下载网速，并提供诊断分析' },
    { id: 'jwt', name: 'JWT 解析工具', path: 'pages/jwt-parser.html', desc: '解析与验证 JSON Web Token，支持对 Payload 及 Header 信息进行可视化查看' },
    { id: 'qrcode', name: '二维码生成/解码', path: 'pages/qrcode.html', desc: '快速生成二维码，或上传解析图片二维码，支持下载二维码图片' },
    { id: 'json-format', name: 'JSON 格式化工具', path: 'pages/json-format.html', desc: '可视化解析、格式化及折叠 JSON 报文，支持错误定位' },
    { id: 'screenshot', name: '网页截图与提取', path: 'pages/screenshot.html', desc: '捕获网页全屏或可视区域，并通过内置 OCR 引擎快速提取网页上的文本' },
    { id: 'ai-assistant', name: 'AI 调试助手', path: 'pages/ai-assistant.html', desc: '提供全栈开发解答、代码重构方案、以及实时网页/网络分析诊断' },
    { id: 'api-tester', name: 'API 接口测试', path: 'pages/api-tester.html', desc: '支持 GET/POST 接口请求发送，自定义 Header 请求头与响应结果实时预览' },
    { id: 'code-beautify', name: '代码格式化/美化', path: 'pages/code-beautify.html', desc: '支持 HTML/CSS/JavaScript 代码的在线美化、缩进与排版对齐' },
    { id: 'color-convert', name: '颜色格式转换', path: 'pages/color-convert.html', desc: '支持 HEX、RGB、HSL、CMYK 等多种颜色表示格式的无损双向转换与取色' },
    { id: 'encode-decode', name: '编码解码工具', path: 'pages/encode-decode.html', desc: '支持 URL 编码解码、Base64 编码解码及 HTML 实体字符转换' },
    { id: 'hash-calc', name: 'Hash 计算工具', path: 'pages/hash-calc.html', desc: '支持对文本和文件计算 MD5、SHA-1、SHA-256、SHA-512 哈希校验值' },
    { id: 'img-base64', name: '图片 Base64 转换', path: 'pages/img-base64.html', desc: '提供本地图片与 Base64 编码的在线互转功能，支持一键复制 HTML/CSS 引用代码' },
    { id: 'json-diff', name: 'JSON 文本对比', path: 'pages/json-diff.html', desc: '对比并高亮显示两段 JSON 报文数据结构之间的增删改细节差异' },
    { id: 'markdown-editor', name: 'Markdown 编辑器', path: 'pages/markdown-editor.html', desc: '提供带双栏实时 HTML 渲染预览的 Markdown 编辑器，支持常用排版快捷标记' },
    { id: 'number-base', name: '进制转换工具', path: 'pages/number-base.html', desc: '提供二进制、八进制、十进制、十六进制等多种数制互相转换功能' },
    { id: 'page-timing', name: '网页性能计时', path: 'pages/page-timing.html', desc: '深度读取并展示当前活跃网页的 DNS 解析、TCP 握手及首字节延迟等高级加载计时数据' },
    { id: 'password-gen', name: '随机密码生成', path: 'pages/password-gen.html', desc: '根据指定长度与所选字符集一键生成高强度安全的随机防破译密码' },
    { id: 'regex-test', name: '正则表达式测试', path: 'pages/regex-test.html', desc: '在线测试并校验正则表达式的匹配捕获效果，内置数十种常用正则模板' },
    { id: 'timestamp', name: '时间戳转换工具', path: 'pages/timestamp.html', desc: '提供 Unix 时间戳与北京时间、UTC 时间双向快速转换与实时计时器' },
    { id: 'uuid-gen', name: 'UUID 生成器', path: 'pages/uuid-gen.html', desc: '支持一键快速批量生成符合 RFC4122 标准的 UUID 唯一通用标识符' }
  ];

  const toolsOverview = DEV_HELPER_TOOLS_MANIFEST.map(t => `- 【${t.name}】(标识ID: ${t.id}, 页面路径: ${t.path}): ${t.desc}`).join('\n');
  const SYSTEM_PROMPT_WITH_TOOLS = `${SYSTEM_PROMPT}\n\n【DevHelper 插件已实现的内置工具集列表】：\n${toolsOverview}\n若用户询问当前插件有什么功能，可根据上面的工具集列表如实介绍。若用户需要使用该工具，可以提及它的“页面路径”以供用户在插件内跳转使用。`;

  const tools = [
    {
      type: "function",
      function: {
        name: "fetch_active_tab_context",
        description: "获取用户当前浏览器中活跃标签页的文本内容、URL、标题以及网络性能 timing 数据，用于分析或诊断网页排障。",
        parameters: {
          type: "object",
          properties: {
            includeDomHtml: { type: "boolean", description: "是否包含当前页面的主要 HTML 文本" },
            includePerformance: { type: "boolean", description: "是否需要获取当前网页的性能指标（如 Timing）" }
          }
        }
      }
    },
    {
      type: "function",
      function: {
        name: "fetch_specified_url_context",
        description: "当用户在对话或指令中明确指定了某一个外部网页 URL 网址时，调用此工具去异步抓取该指定目标网页的文本内容与网络加载性能 timing 数据。",
        parameters: {
          type: "object",
          properties: {
            url: { type: "string", description: "用户指定的完整网页 URL，例如 https://example.com" }
          },
          required: ["url"]
        }
      }
    },
    {
      type: "function",
      function: {
        name: "generate_qrcode",
        description: "当用户提出需要生成二维码、将文本或网址转化为二维码时调用。返回该二维码的 Base64 图像，以便直接在对话中渲染展示给用户。",
        parameters: {
          type: "object",
          properties: {
            text: { type: "string", description: "要转化为二维码的内容或 URL，例如 Hello World 或 https://example.com" },
            colorDark: { type: "string", description: "可选，二维码前景色 Hex，默认 #000000" },
            colorLight: { type: "string", description: "可选，二维码背景色 Hex，默认 #ffffff" }
          },
          required: ["text"]
        }
      }
    },
    {
      type: "function",
      function: {
        name: "diagnose_network_speed",
        description: "当用户需要测试自己的网速、获取内外网 IP 物理归属及网络加载延迟与抖动时调用此工具。",
        parameters: {
          type: "object",
          properties: {}
        }
      }
    },
    {
      type: "function",
      function: {
        name: "capture_webpage_screenshot",
        description: "当用户要求对当前页面、活跃网页或者用户指定的 URL 网址进行截图（可视区或整页滚动拼接截图）时调用。截图成功后会自动保存到本地并显示在聊天流中。",
        parameters: {
          type: "object",
          properties: {
            targetUrl: { type: "string", description: "可选，用户指定的外部网页完整 URL。若不传，则默认对当前用户所在的活跃网页标签页进行截图。" },
            type: { type: "string", enum: ["full", "visible"], description: "截图类型：full 表示整页滚动拼接截图（默认），visible 表示仅截取当前可视区域。" },
            autoDownload: { type: "boolean", description: "是否在截图完成后自动以 PNG 格式保存/下载到用户本地，默认为 true。" }
          }
        }
      }
    }
  ];

  const toolHandlers = {
    fetch_active_tab_context: async (args) => {
      try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs[0];
        if (!tab) return { error: '未找到活跃的标签页' };
        if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://')) {
          return { error: '当前为 Chrome 系统内置页面，无法抓取外部上下文。请切换到一般的外部网页上再重试。', url: tab.url, title: tab.title };
        }

        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const timing = performance.timing || {};
            const perfData = {
              navigationStart: timing.navigationStart,
              domComplete: timing.domComplete,
              loadEventEnd: timing.loadEventEnd,
              domInteractive: timing.domInteractive,
              fetchStart: timing.fetchStart
            };
            const loadDuration = timing.loadEventEnd > 0 ? (timing.loadEventEnd - timing.navigationStart) + 'ms' : '仍在加载中';
            const domCompleteDuration = timing.domComplete > 0 ? (timing.domComplete - timing.navigationStart) + 'ms' : '仍在解析中';

            return {
              title: document.title,
              url: window.location.href,
              loadTime: loadDuration,
              domCompleteTime: domCompleteDuration,
              performanceTiming: perfData,
              bodyText: document.body.innerText ? document.body.innerText.slice(0, 1500) : '空页面'
            };
          }
        });
        return results[0]?.result || { error: '注入页面脚本未返回有效结果' };
      } catch (err) {
        console.error('AI 助手执行 fetch_active_tab_context 发生错误:', err);
        return { error: `无法获取当前网页数据: ${err.message}` };
      }
    },

    fetch_specified_url_context: async (args) => {
      const url = args.url;
      if (!url) return { error: '未提供目标网址 URL' };

      // 验证并规范化 URL
      let targetUrl = url.trim();
      if (!/^https?:\/\//i.test(targetUrl)) {
        targetUrl = 'http://' + targetUrl;
      }

      // 如果当前是 Mock Polyfill 环境（即非 Extension 宿主），直接从模拟数据返回
      if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.create) {
        return {
          title: '已抓取的目标网页 - ' + targetUrl,
          url: targetUrl,
          loadTime: '240ms',
          domCompleteTime: '190ms',
          performanceTiming: {
            navigationStart: Date.now() - 300,
            domComplete: Date.now() - 110,
            loadEventEnd: Date.now() - 60,
            domInteractive: Date.now() - 150,
            fetchStart: Date.now() - 290
          },
          bodyText: `这是您指定的网页 (${targetUrl}) 的模拟正文。在非插件预览环境下，我们已经为您自动模拟了该网址的内容提取。该网页搭载了完备的前端模块，性能表现极其优异。`
        };
      }

      // 宿主环境下：使用 chrome.tabs.create 静默新建非活跃 tab，读取 Timing 和 DOM
      return new Promise((resolve) => {
        let hasResolved = false;
        
        chrome.tabs.create({ url: targetUrl, active: false }, (tab) => {
          const tabId = tab.id;
          if (!tabId) {
            resolve({ error: '创建后台标签页失败' });
            return;
          }

          // 设置一个 15 秒的最大超时保护，防止页面一直加载无法 resolution
          const timeoutId = setTimeout(() => {
            if (!hasResolved) {
              hasResolved = true;
              chrome.tabs.remove(tabId);
              resolve({ error: '网页加载超时，只获取到部分信息或连接失败' });
            }
          }, 15000);

          const listener = (updatedTabId, changeInfo) => {
            if (updatedTabId === tabId && changeInfo.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              
              if (hasResolved) return;
              
              // 注入脚本以提取 timing 数据和内容
              chrome.scripting.executeScript({
                target: { tabId },
                func: () => {
                  const timing = performance.timing || {};
                  const perfData = {
                    navigationStart: timing.navigationStart,
                    domComplete: timing.domComplete,
                    loadEventEnd: timing.loadEventEnd,
                    domInteractive: timing.domInteractive,
                    fetchStart: timing.fetchStart
                  };
                  const loadDuration = timing.loadEventEnd > 0 ? (timing.loadEventEnd - timing.navigationStart) + 'ms' : '加载延迟';
                  const domCompleteDuration = timing.domComplete > 0 ? (timing.domComplete - timing.navigationStart) + 'ms' : '解析延迟';

                  return {
                    title: document.title,
                    url: window.location.href,
                    loadTime: loadDuration,
                    domCompleteTime: domCompleteDuration,
                    performanceTiming: perfData,
                    bodyText: document.body.innerText ? document.body.innerText.slice(0, 1500) : '空页面'
                  };
                }
              }, (results) => {
                clearTimeout(timeoutId);
                hasResolved = true;
                chrome.tabs.remove(tabId);
                
                if (results && results[0]) {
                  resolve(results[0].result);
                } else {
                  resolve({ error: '无法读取目标页面渲染内容' });
                }
              });
            }
          };

          chrome.tabs.onUpdated.addListener(listener);
        });
      });
    },

    generate_qrcode: async (args) => {
      const { text, colorDark = '#000000', colorLight = '#ffffff' } = args;
      if (!text) return { error: '未提供生成二维码的内容' };
      try {
        const dataUrl = await generateQRCodeBase64(text, 240, colorDark, colorLight);
        lastGeneratedQR = dataUrl; // 兼容老机制
        
        const assetId = 'PLACEHOLDER_QR_CODE_' + Date.now();
        const conv = conversations.find(c => c.id === currentConvId);
        if (conv) {
          if (!conv.mediaAssets) conv.mediaAssets = {};
          conv.mediaAssets[assetId] = dataUrl;
          await saveConversations();
        }

        return {
          success: true,
          text,
          imageUrl: assetId, // 返回带时间戳的唯一占位符以持久化关联
          message: '二维码生成成功，大模型请通过格式 ![alt](' + assetId + ') 告知用户。'
        };
      } catch (err) {
        console.error('generate_qrcode 发生错误:', err);
        return { error: `二维码生成失败: ${err.message}` };
      }
    },

    diagnose_network_speed: async () => {
      try {
        const localIp = await getLocalIP();
        const publicIpInfo = await getPublicIP();
        const pingResult = await testPingAndJitter('https://api.live.bilibili.com/client/v1/Ip/getIpInfo');
        
        let statusLevel = '良好';
        let statusDesc = '网络延迟正常，适合进行日常开发与网络浏览。';
        if (pingResult.ping > 0) {
          if (pingResult.ping <= 30 && pingResult.jitter <= 8) {
            statusLevel = '极佳';
            statusDesc = '网络加载顺滑，延迟极低，非常适合实时通讯与远程联调！';
          } else if (pingResult.ping > 120 || pingResult.jitter > 30) {
            statusLevel = '较差';
            statusDesc = '延迟偏高或网速出现明显抖动，可能会影响联调测试。';
          }
        }

        return {
          success: true,
          localIp,
          publicIp: publicIpInfo.ip,
          location: publicIpInfo.city,
          country: publicIpInfo.country,
          isp: publicIpInfo.isp,
          ping: pingResult.ping > 0 ? `${pingResult.ping}ms` : '测试超时',
          jitter: pingResult.jitter > 0 ? `${pingResult.jitter}ms` : '测试超时',
          statusLevel,
          statusDesc
        };
      } catch (err) {
        console.error('diagnose_network_speed 发生错误:', err);
        return { error: `网速诊断执行失败: ${err.message}` };
      }
    },

    capture_webpage_screenshot: async (args) => {
      const { targetUrl, type = 'full', autoDownload = true } = args;
      try {
        let targetTabId = null;
        let originalTab = null;

        // 1. 获取当前活跃 Tab
        const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
        originalTab = activeTabs[0];

        // 获取当前 AI 助手自身的 tab ID 以便截图后切回
        let myTabId = null;
        if (window.chrome && chrome.tabs) {
          const curTab = await new Promise(r => chrome.tabs.getCurrent(r));
          if (curTab) myTabId = curTab.id;
        }

        // 2. 确定要截图的目标 Tab ID
        if (targetUrl) {
          const tab = await new Promise((resolve, reject) => {
            chrome.tabs.create({ url: targetUrl, active: false }, (t) => {
              if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
              else resolve(t);
            });
          });
          targetTabId = tab.id;
          
          // 等待标签页加载 complete
          await new Promise((resolve) => {
            const timeout = setTimeout(() => resolve(), 15000);
            const listener = (updatedTabId, changeInfo) => {
              if (updatedTabId === targetTabId && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                clearTimeout(timeout);
                resolve();
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          });
        } else {
          const targetTab = await getTargetTab();
          if (!targetTab) {
            return { error: '未找到可供截图的网页标签页' };
          }
          targetTabId = targetTab.id;
        }

        // 3. 将目标 Tab 临时设置为活跃状态
        await chrome.tabs.update(targetTabId, { active: true });
        await new Promise(r => setTimeout(r, 400)); // 留出足够时间让 Chrome 将画面切换和重绘到前台

        // 4. 执行截图拼接
        const dataUrl = await doPageScreenshot(targetTabId, type, autoDownload);
        lastGeneratedScreenshot = dataUrl;

        const assetId = 'PLACEHOLDER_SCREENSHOT_' + Date.now();
        const conv = conversations.find(c => c.id === currentConvId);
        if (conv) {
          if (!conv.mediaAssets) conv.mediaAssets = {};
          conv.mediaAssets[assetId] = dataUrl;
          await saveConversations();
        }

        // 5. 还原活跃 Tab
        if (myTabId) {
          await chrome.tabs.update(myTabId, { active: true });
        } else if (originalTab && originalTab.id !== targetTabId) {
          await chrome.tabs.update(originalTab.id, { active: true });
        }

        // 6. 如果是临时静默创建的 Tab，用完立即销毁
        if (targetUrl) {
          chrome.tabs.remove(targetTabId);
        }

        return {
          success: true,
          imageUrl: assetId,
          type,
          autoDownload,
          message: '网页截图已生成并成功保存到本地。请在 Markdown 中以 ![网页截图](' + assetId + ') 显示该图像缩略图。'
        };
      } catch (err) {
        // 发生异常时，尝试切回当前助手页面
        if (window.chrome && chrome.tabs) {
          chrome.tabs.getCurrent(curTab => {
            if (curTab) chrome.tabs.update(curTab.id, { active: true });
          });
        }
        console.error('截图失败:', err);
        return { error: `截图执行失败: ${err.message}` };
      }
    }
  };

  async function getTargetTab() {
    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTab = activeTabs[0];
    if (activeTab && activeTab.url && !activeTab.url.includes('ai-assistant.html') && !activeTab.url.startsWith('chrome') && !activeTab.url.startsWith('edge') && !activeTab.url.startsWith('about')) {
      return activeTab;
    }
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const normalTabs = tabs.filter(t => t.url && !t.url.includes('ai-assistant.html') && !t.url.startsWith('chrome') && !t.url.startsWith('edge') && !t.url.startsWith('about'));
    return normalTabs[0] || null;
  }

  async function doPageScreenshot(targetTabId, type = 'full', autoDownload = true) {
    await new Promise((resolve, reject) => {
      chrome.scripting.executeScript({
        target: { tabId: targetTabId },
        files: ['js/content/screenshot-helper.js']
      }, () => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });

    if (type === 'visible') {
      const capRes = await new Promise((resolve) => {
        chrome.sendMessageForScreenshot = true;
        chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (res) => {
          resolve(chrome.runtime.lastError ? null : res);
        });
      });
      if (!capRes || !capRes.dataUrl) throw new Error('可视区截图捕获失败');
      if (autoDownload) triggerDownload(capRes.dataUrl);
      return capRes.dataUrl;
    }

    // 长截图拼接
    const info = await new Promise((resolve) => {
      chrome.tabs.sendMessage(targetTabId, { action: 'prepareScroll' }, (res) => {
        resolve(chrome.runtime.lastError ? null : res);
      });
    });

    if (!info) {
      throw new Error('无法与目标网页通信，可能页面受到了权限保护');
    }

    let { totalHeight, viewportWidth, viewportHeight, dpr, containerRect } = info;
    const captureWidth = containerRect ? containerRect.width : viewportWidth;
    const MAX_CANVAS_HEIGHT = 16000;
    let canvasHeight = Math.min(totalHeight * dpr, MAX_CANVAS_HEIGHT);

    const stitchCanvas = document.createElement('canvas');
    stitchCanvas.width = captureWidth * dpr;
    stitchCanvas.height = canvasHeight;
    const stitchCtx = stitchCanvas.getContext('2d');
    if (!stitchCtx) throw new Error('Canvas 尺寸溢出系统上限');

    let currentScrollY = 0;
    let drawnHeight = 0;

    while (true) {
      const scrollRes = await new Promise((resolve) => {
        const timer = setTimeout(() => resolve(null), 6000);
        chrome.tabs.sendMessage(targetTabId, { action: 'scrollTo', y: currentScrollY }, (res) => {
          clearTimeout(timer);
          resolve(chrome.runtime.lastError ? null : res);
        });
      });

      if (!scrollRes) break;

      const actualY = scrollRes.actualY;
      const currentTotalHeight = scrollRes.currentTotalHeight || totalHeight;
      const isBottom = scrollRes.isBottom;

      const neededHeight = currentTotalHeight * dpr + 200 * dpr;
      if (neededHeight > stitchCanvas.height && stitchCanvas.height < MAX_CANVAS_HEIGHT) {
        const expandTo = Math.min(neededHeight, MAX_CANVAS_HEIGHT);
        try {
          const newCanvas = document.createElement('canvas');
          newCanvas.width = stitchCanvas.width;
          newCanvas.height = expandTo;
          const newCtx = newCanvas.getContext('2d');
          if (newCtx) {
            newCtx.drawImage(stitchCanvas, 0, 0);
            stitchCanvas.width = newCanvas.width;
            stitchCanvas.height = newCanvas.height;
            stitchCtx.drawImage(newCanvas, 0, 0);
          }
        } catch (e) {
          console.warn('[AI Assistant] Canvas 扩容失败:', e);
        }
      }

      const capRes = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (res) => {
          resolve(chrome.runtime.lastError ? null : res);
        });
      });

      if (!capRes || !capRes.dataUrl) break;

      await new Promise((resolve) => {
        const img = new Image();
        img.onload = () => {
          try {
            if (isBottom) {
              const remainContent = Math.max(0, currentTotalHeight - drawnHeight);
              if (remainContent > 0) {
                const sourceY = Math.max(0, drawnHeight - actualY);
                const availableH = Math.min(remainContent, viewportHeight - sourceY);
                if (availableH > 0) {
                  if (containerRect) {
                    stitchCtx.drawImage(
                      img,
                      containerRect.left * dpr,
                      (containerRect.top + sourceY) * dpr,
                      containerRect.width * dpr,
                      availableH * dpr,
                      0,
                      drawnHeight * dpr,
                      containerRect.width * dpr,
                      availableH * dpr
                    );
                  } else {
                    stitchCtx.drawImage(
                      img,
                      0,
                      sourceY * dpr,
                      viewportWidth * dpr,
                      availableH * dpr,
                      0,
                      drawnHeight * dpr,
                      viewportWidth * dpr,
                      availableH * dpr
                    );
                  }
                  drawnHeight += availableH;
                }
              }
            } else {
              if (containerRect) {
                stitchCtx.drawImage(
                  img,
                  containerRect.left * dpr,
                  containerRect.top * dpr,
                  containerRect.width * dpr,
                  containerRect.height * dpr,
                  0,
                  drawnHeight * dpr,
                  containerRect.width * dpr,
                  containerRect.height * dpr
                );
              } else {
                stitchCtx.drawImage(
                  img,
                  0, 0,
                  viewportWidth * dpr,
                  viewportHeight * dpr,
                  0,
                  drawnHeight * dpr,
                  viewportWidth * dpr,
                  viewportHeight * dpr
                );
              }
              drawnHeight += viewportHeight;
            }
          } catch (e) {
            console.error(e);
          }
          resolve();
        };
        img.onerror = resolve;
        img.src = capRes.dataUrl;
      });

      if (isBottom) break;
      currentScrollY = drawnHeight;
    }

    await new Promise((resolve) => {
      chrome.tabs.sendMessage(targetTabId, { action: 'restoreScroll' }, () => resolve());
    });

    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = captureWidth * dpr;
    finalCanvas.height = drawnHeight * dpr;
    const finalCtx = finalCanvas.getContext('2d');
    if (!finalCtx) throw new Error('裁切最终 Canvas 失败');
    finalCtx.drawImage(stitchCanvas, 0, 0);
    const dataUrl = finalCanvas.toDataURL('image/png');

    if (autoDownload) triggerDownload(dataUrl);
    return dataUrl;
  }

  function triggerDownload(dataUrl) {
    const link = document.createElement('a');
    link.download = `DevHelper_AI_Screenshot_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
  }

  // ─── 二维码与测速辅助函数 ─────────────────────────────────────────────

  function generateQRCodeBase64(text, size = 240, colorDark = '#000000', colorLight = '#ffffff') {
    return new Promise((resolve, reject) => {
      if (typeof QRCode === 'undefined') {
        reject(new Error('未加载二维码生成库 QRCode'));
        return;
      }
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.width = size + 'px';
      tempDiv.style.height = size + 'px';
      document.body.appendChild(tempDiv);

      try {
        new QRCode(tempDiv, {
          text: text,
          width: size,
          height: size,
          colorDark: colorDark,
          colorLight: colorLight,
          correctLevel: QRCode.CorrectLevel.M
        });

        setTimeout(() => {
          try {
            const canvas = tempDiv.querySelector('canvas');
            const img = tempDiv.querySelector('img');
            if (canvas) {
              const dataUrl = canvas.toDataURL('image/png');
              document.body.removeChild(tempDiv);
              resolve(dataUrl);
            } else if (img) {
              const dataUrl = img.src;
              document.body.removeChild(tempDiv);
              resolve(dataUrl);
            } else {
              document.body.removeChild(tempDiv);
              reject(new Error('未找到生成的二维码元素'));
            }
          } catch (e) {
            if (tempDiv.parentNode) document.body.removeChild(tempDiv);
            reject(e);
          }
        }, 50);
      } catch (e) {
        if (tempDiv.parentNode) document.body.removeChild(tempDiv);
        reject(e);
      }
    });
  }

  async function getLocalIP() {
    return new Promise((resolve) => {
      try {
        const pc = new RTCPeerConnection({ iceServers: [] });
        pc.createDataChannel('');
        pc.createOffer().then(offer => pc.setLocalDescription(offer)).catch(() => resolve('未知'));
        pc.onicecandidate = (ice) => {
          if (!ice || !ice.candidate || !ice.candidate.candidate) {
            resolve('未知 (局域网隔离)');
            return;
          }
          const candidate = ice.candidate.candidate;
          const ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3})/;
          const match = ipRegex.exec(candidate);
          if (match) {
            resolve(match[1]);
            pc.close();
          }
        };
        setTimeout(() => {
          resolve('未知 (探测超时)');
          try { pc.close(); } catch {}
        }, 1200);
      } catch (e) {
        resolve('无法检测 (浏览器安全限制)');
      }
    });
  }

  async function getPublicIP() {
    const apis = [
      {
        url: 'https://api.live.bilibili.com/client/v1/Ip/getIpInfo',
        parser: (res) => {
          if (res && res.code === 0 && res.data) {
            return {
              ip: res.data.ip || '-',
              country: res.data.country || '-',
              city: `${res.data.province || ''} ${res.data.city || ''}`.trim() || '-',
              isp: res.data.isp || '-'
            };
          }
          throw new Error('格式错误');
        }
      },
      { 
        url: 'https://freeipapi.com/api/json/', 
        parser: (res) => ({ 
          ip: res.ipAddress || '-', 
          country: res.countryName || '-', 
          city: `${res.regionName || ''} ${res.cityName || ''}`.trim() || '-', 
          isp: '-' 
        }) 
      },
      {
        url: 'https://opendata.baidu.com/api.php?query=self&co=&resource_id=6006&oe=utf8&format=json',
        parser: (res) => {
          if (res && res.data && res.data[0]) {
            const item = res.data[0];
            let city = '-';
            if (item.location) {
              const parts = item.location.trim().split(/\s+/);
              city = parts[0] || '-';
            }
            return {
              ip: item.clientIP || '-',
              country: '中国',
              city: city,
              isp: '-'
            };
          }
          throw new Error('格式错误');
        }
      }
    ];
    
    for (const api of apis) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000);
        const response = await fetch(api.url, { 
          method: 'GET',
          signal: controller.signal,
          cache: 'no-store' 
        });
        clearTimeout(timeoutId);
        if (response.ok) {
          const json = await response.json();
          return api.parser(json);
        }
      } catch (e) {
        console.log(`AI测速 IP 解析切换备用源:`, e.message);
      }
    }
    return { ip: '检测失败', country: '未知', city: '未知', isp: '未知' };
  }

  async function testPingAndJitter(testUrl) {
    const pings = [];
    for (let i = 0; i < 4; i++) {
      const start = performance.now();
      try {
        await fetch(`${testUrl}?t=${Math.random()}`, { 
          method: 'HEAD', 
          cache: 'no-store',
          mode: 'no-cors'
        });
        pings.push(performance.now() - start);
      } catch (e) {
        try {
          await fetch(`${testUrl}?t=${Math.random()}`, { 
            method: 'GET', 
            cache: 'no-store', 
            mode: 'no-cors'
          });
          pings.push(performance.now() - start);
        } catch (err) {}
      }
      await new Promise(r => setTimeout(r, 60));
    }
    if (pings.length === 0) return { ping: 0, jitter: 0 };
    const avgPing = pings.reduce((a, b) => a + b, 0) / pings.length;
    let jitterSum = 0;
    for (let i = 1; i < pings.length; i++) {
      jitterSum += Math.abs(pings[i] - pings[i - 1]);
    }
    const jitter = pings.length > 1 ? jitterSum / (pings.length - 1) : 0;
    return { ping: Math.round(avgPing), jitter: Math.round(jitter) };
  }

  let messages = [];      // 当前会话消息历史
  let conversations = []; // 所有会话列表
  let currentConvId = null;
  let isGenerating = false;

  // ─── 历史记录管理 ─────────────────────────────────────────────

  async function loadHistory() {
    const data = await chrome.storage.local.get(['aiConversations']);
    conversations = data.aiConversations || [];
    renderHistory();
    // 如果没有历史会话则开启新对话
    if (!conversations.length) {
      startNewChat();
    } else {
      // 加载最近一条会话
      loadConversation(conversations[conversations.length - 1].id);
    }
  }

  function renderHistory() {
    const list = document.getElementById('historyList');
    list.innerHTML = '';
    conversations.slice().reverse().forEach(conv => {
      const item = document.createElement('div');
      item.className = 'history-item' + (conv.id === currentConvId ? ' active' : '');
      
      const titleSpan = document.createElement('span');
      titleSpan.className = 'history-item-title';
      titleSpan.textContent = conv.title || '新对话';
      item.appendChild(titleSpan);

      const delBtn = document.createElement('span');
      delBtn.className = 'history-item-del';
      delBtn.innerHTML = '&times;'; // 优雅的删除小叉号
      delBtn.title = '删除此对话';
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation(); // 阻止加载事件冒泡
        deleteConversation(conv.id);
      });
      item.appendChild(delBtn);

      item.addEventListener('click', () => loadConversation(conv.id));
      list.appendChild(item);
    });
  }

  async function deleteConversation(id) {
    if (!confirm('确定要删除这个对话吗？')) return;
    
    conversations = conversations.filter(c => c.id !== id);
    try {
      await chrome.storage.local.set({ aiConversations: conversations });
    } catch (e) {
      console.warn('[AI Assistant] 删除对话后保存会话历史失败:', e);
    }
    
    if (currentConvId === id) {
      if (conversations.length > 0) {
        loadConversation(conversations[conversations.length - 1].id);
      } else {
        startNewChat();
      }
    } else {
      renderHistory();
    }
  }

  function startNewChat() {
    const id = Date.now().toString();
    const conv = { id, title: '新对话', messages: [], createdAt: Date.now() };
    conversations.push(conv);
    currentConvId = id;
    messages = [];

    const container = document.getElementById('chatMessages');
    container.innerHTML = '';

    // 恢复欢迎屏
    const welcome = createWelcomeScreen();
    container.appendChild(welcome);

    renderHistory();
    saveConversations();
  }

  function loadConversation(id) {
    const conv = conversations.find(c => c.id === id);
    if (!conv) return;
    currentConvId = id;
    messages = conv.messages || [];

    const container = document.getElementById('chatMessages');
    container.innerHTML = '';

    if (messages.length === 0) {
      container.appendChild(createWelcomeScreen());
    } else {
      messages.forEach((m, idx) => appendMessage(m.role, m.content, false, idx));
    }
    renderHistory();
  }

  async function saveConversations() {
    try {
      const conv = conversations.find(c => c.id === currentConvId);
      if (conv) {
        conv.messages = messages;
        // 用第一条用户消息前 30 字作为会话标题
        if (messages.length > 0 && conv.title === '新对话') {
          const firstUserMsg = messages.find(m => m.role === 'user');
          if (firstUserMsg) conv.title = firstUserMsg.content.slice(0, 30) + (firstUserMsg.content.length > 30 ? '...' : '');
        }
      }
      await chrome.storage.local.set({ aiConversations: conversations.slice(-20) });
    } catch (e) {
      console.warn('[AI Assistant] 保存会话历史失败:', e);
    }
  }

  // ─── 欢迎屏 ───────────────────────────────────────────────────

  function createWelcomeScreen() {
    const div = document.createElement('div');
    div.className = 'welcome-screen';
    div.id = 'welcomeScreen';
    div.innerHTML = `
      <svg class="welcome-logo" viewBox="0 0 56 56" fill="none">
        <rect width="56" height="56" rx="16" fill="url(#wg2)"/>
        <path d="M14 22L22 30L14 38M26 38H42" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
        <defs><linearGradient id="wg2" x1="0" y1="0" x2="56" y2="56" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs>
      </svg>
      <div class="welcome-title">DevHelper AI 助手</div>
      <div class="welcome-desc">你好！我是你的专属 AI 助手，不管是查 BUG、写代码，还是咨询技术问题，都可以问我。</div>
      <div class="welcome-cards">
        <div class="welcome-card" data-q="用 JS 写一个防抖函数的 Demo"><div class="welcome-card-icon">⚡</div><div class="welcome-card-title">写一个防抖 Demo</div><div class="welcome-card-desc">JavaScript 代码示例</div></div>
        <div class="welcome-card" data-q="JS 里的 Fetch API 怎么用"><div class="welcome-card-icon">🌐</div><div class="welcome-card-title">Fetch API 使用</div><div class="welcome-card-desc">网络请求最佳实践</div></div>
        <div class="welcome-card" data-q="帮我写一个单网页版的俄罗斯方块游戏（HTML+CSS+JS）"><div class="welcome-card-icon">🎮</div><div class="welcome-card-title">写一个小游戏</div><div class="welcome-card-desc">HTML + CSS + JS 实现</div></div>
        <div class="welcome-card" data-q="解释 Vue 3 的响应式原理 Proxy vs Object.defineProperty"><div class="welcome-card-icon">🔍</div><div class="welcome-card-title">Vue 3 响应式原理</div><div class="welcome-card-desc">Proxy vs defineProperty</div></div>
      </div>`;

    // 绑定欢迎卡片的点击事件（避免内联 onclick）
    div.querySelectorAll('[data-q]').forEach(card => {
      card.addEventListener('click', () => {
        document.getElementById('msgInput').value = card.dataset.q;
        sendMessage();
      });
    });
    return div;
  }

  // ─── 发送消息 ──────────────────────────────────────────────────

  async function sendMessage() {
    const msgInput = document.getElementById('msgInput');
    const text = msgInput.value.trim();
    if (!text || isGenerating) return;

    // 隐藏欢迎屏
    document.getElementById('welcomeScreen')?.remove();

    msgInput.value = '';
    msgInput.style.height = '24px';

    appendMessage('user', text);
    messages.push({ role: 'user', content: text });

    isGenerating = true;
    document.getElementById('btnSend').disabled = true;

    const thinkEl = appendThinking();

    let aiBubble = null;
    try {
      // 构建带历史上下文的提示，最多取最近 10 条
      const historyCtx = messages.slice(-10).map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`).join('\n');
      const prompt = messages.length > 1
        ? `对话历史:\n${historyCtx}\n\n请回答最后一条用户问题`
        : text;

      let fullReply = '';
      aiBubble = document.createElement('div');
      aiBubble.className = 'msg assistant';
      aiBubble.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble"></div>`;
      const bubbleContent = aiBubble.querySelector('.msg-bubble');

      const result = await DevHelperAI.callAI({
        systemPrompt: SYSTEM_PROMPT_WITH_TOOLS,
        prompt: prompt,
        onChunk: (chunk, reasoningText) => {
          // 首字防抖阻断：只有当真正有流式内容（推理思维链或最终回复字符）时才启动状态切换
          if (!chunk?.trim() && !reasoningText?.trim()) {
            return;
          }

          if (thinkEl && thinkEl.parentNode) {
            thinkEl.remove();
          }
          if (!aiBubble.parentNode) {
            document.getElementById('chatMessages').appendChild(aiBubble);
          }
     
          // chunk 为空说明当前处于推理模型的思维链阶段（reasoning_content）
          // 显示一个"正在深度思考"的占位状态，等待最终答案（content）到来
          if (!chunk && reasoningText) {
            bubbleContent.innerHTML = `<div class="thinking-dots"><span></span><span></span><span></span></div><span style="font-size:12px;color:var(--text-tertiary);margin-left:6px">正在深度思考中...</span>`;
          } else if (chunk) {
            fullReply = chunk;
            if (bubbleContent) {
              bubbleContent.innerHTML = renderMarkdown(chunk);
            }
          }
          scrollToBottom();
        },
        tools: tools,
        toolHandlers: toolHandlers
      });

      // callAI 完成后统一处理：确保 thinkEl 和 aiBubble 状态正确
      // 若 onChunk 从未被调用（非流式响应/SSE 解析失败），需手动 append 气泡并渲染内容
      if (thinkEl && thinkEl.parentNode) {
        thinkEl.remove();
      }
      if (!aiBubble.parentNode) {
        document.getElementById('chatMessages').appendChild(aiBubble);
      }
      // 终极渲染覆盖：确保流式解析因网关粘连分包报错等偶然因素丢失的末尾 Token 能够被最终 result 完美弥补
      if (result && result.length >= fullReply.length) {
        fullReply = result;
        bubbleContent.innerHTML = renderMarkdown(fullReply);
        scrollToBottom();
      }

      messages.push({ role: 'assistant', content: fullReply });
      await saveConversations();
      renderHistory();
    } catch (err) {
      if (thinkEl && thinkEl.parentNode) {
        thinkEl.remove();
      }
      // 如果气泡已添加到页面，直接在里面显示错误
      if (aiBubble && aiBubble.parentNode) {
        const bContent = aiBubble.querySelector('.msg-bubble');
        if (bContent) {
          bContent.innerHTML = `<span style="color:var(--error);font-weight:600">❌ AI 调用失败：${err.message}</span>\n\n请点击右上角「AI 设置」配置 API Key。`;
        }
      } else {
        appendMessage('assistant', `❌ AI 调用失败：${err.message}\n\n请点击右上角「AI 设置」配置 API Key。`);
      }
    } finally {
      isGenerating = false;
      document.getElementById('btnSend').disabled = false;
    }
  }

  // ─── DOM 工具函数 ──────────────────────────────────────────────

  function appendMessage(role, content, scroll = true, msgIndex = null) {
    const container = document.getElementById('chatMessages');
    const el = document.createElement('div');
    el.className = `msg ${role}`;
    const avatar = role === 'user' ? '👤' : '🤖';
    
    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'msg-avatar';
    avatarDiv.textContent = avatar;
    el.appendChild(avatarDiv);
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'msg-bubble';
    bubbleDiv.innerHTML = renderMarkdown(content);
    el.appendChild(bubbleDiv);

    // 悬浮删除具体本条消息的按钮
    const delBtn = document.createElement('div');
    delBtn.className = 'msg-del-btn';
    delBtn.innerHTML = '&times;';
    delBtn.title = '删除此条消息';
    delBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm('确定要删除这条消息吗？')) return;
      
      el.remove();
      if (msgIndex !== null) {
        messages.splice(msgIndex, 1);
      } else {
        const index = messages.findIndex(m => m.role === role && m.content === content);
        if (index !== -1) {
          messages.splice(index, 1);
        }
      }
      await saveConversations();
      // 重新加载以确保气泡的 index dataset 完全同步
      loadConversation(currentConvId);
    });
    el.appendChild(delBtn);

    container.appendChild(el);
    if (scroll) scrollToBottom();
    return el;
  }

  function appendThinking() {
    const container = document.getElementById('chatMessages');
    const el = document.createElement('div');
    el.className = 'msg assistant';
    el.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble"><div class="thinking-dots"><span></span><span></span><span></span></div></div>`;
    container.appendChild(el);
    scrollToBottom();
    return el;
  }

  function scrollToBottom() {
    const c = document.getElementById('chatMessages');
    c.scrollTop = c.scrollHeight;
  }

  // ─── Markdown 渲染 ─────────────────────────────────────────────
  // 轻量级渲染器，支持：代码块、内联代码、粗/斜体、标题、有序列表、无序列表、表格、分隔线

  function renderMarkdown(text) {
    if (!text) return '';

    // 转义 HTML（避免 XSS）
    function escHtml(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // 1. 代码块（优先处理，防止其内容被后续规则污染）
    let result = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
      `<pre class="md-pre"><code class="lang-${lang}">${escHtml(code.trim())}</code></pre>`);

    // 1.5 图片与链接
    // 抢救可能被截断或缺失闭合右括号的 Base64 图片
    result = result.replace(/!\[([^\]]*)\]\s*\((data:image\/[a-zA-Z]+;base64,[A-Za-z0-9+/=\s]+)/g, (match, alt, src) => {
      const cleanSrc = src.replace(/[)\s]+/g, '');
      return `<img class="md-img" src="${cleanSrc}" alt="${alt}">`;
    });
    // 正常渲染其他图片（包括占位符形式）
    result = result.replace(/!\[([^\]]*)\]\s*\(([^)]*)\)/g, (match, alt, src) => {
      let cleanSrc = src.replace(/\s+/g, '');
      if (cleanSrc.startsWith('PLACEHOLDER_QR_CODE')) {
        const conv = conversations.find(c => c.id === currentConvId);
        if (conv && conv.mediaAssets && conv.mediaAssets[cleanSrc]) {
          cleanSrc = conv.mediaAssets[cleanSrc];
        } else {
          cleanSrc = lastGeneratedQR || '';
        }
      } else if (cleanSrc.startsWith('PLACEHOLDER_SCREENSHOT')) {
        const conv = conversations.find(c => c.id === currentConvId);
        if (conv && conv.mediaAssets && conv.mediaAssets[cleanSrc]) {
          cleanSrc = conv.mediaAssets[cleanSrc];
        } else {
          cleanSrc = lastGeneratedScreenshot || '';
        }
      }
      return `<img class="md-img" src="${cleanSrc}" alt="${alt}">`;
    });
    result = result.replace(/(?<!\!)\[([^\]]*)\]\s*\(([^)]*)\)/g, (match, text, href) => {
      const cleanHref = href.replace(/\s+/g, '');
      return `<a class="md-link" href="${cleanHref}" target="_blank">${text}</a>`;
    });

    // 2. 表格（简单支持）
    result = result.replace(/(\|.+\|\n\|[-: |]+\|\n(?:\|.+\|\n?)+)/g, (table) => {
      const rows = table.trim().split('\n');
      const headers = rows[0].split('|').filter(c => c.trim()).map(c => `<th>${escHtml(c.trim())}</th>`).join('');
      const body = rows.slice(2).map(row => {
        const cells = row.split('|').filter(c => c.trim()).map(c => `<td>${escHtml(c.trim())}</td>`).join('');
        return `<tr>${cells}</tr>`;
      }).join('');
      return `<table class="md-table"><thead><tr>${headers}</tr></thead><tbody>${body}</tbody></table>`;
    });

    // 3. 标题
    result = result
      .replace(/^### (.+)$/gm, '<h3 class="md-h3">$1</h3>')
      .replace(/^## (.+)$/gm, '<h2 class="md-h2">$1</h2>')
      .replace(/^# (.+)$/gm, '<h1 class="md-h1">$1</h1>');

    // 4. 有序列表
    result = result.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li>${l.replace(/^\d+\. /, '')}</li>`).join('');
      return `<ol class="md-ol">${items}</ol>`;
    });

    // 5. 无序列表
    result = result.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li>${l.replace(/^[-*] /, '')}</li>`).join('');
      return `<ul class="md-ul">${items}</ul>`;
    });

    // 6. 内联格式
    result = result
      .replace(/`([^`]+)`/g, '<code class="md-code">$1</code>')
      .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/~~(.+?)~~/g, '<del>$1</del>');

    // 7. 分隔线
    result = result.replace(/^---$/gm, '<hr class="md-hr">');

    // 8. 换行（非 HTML 标签前面的换行）
    result = result.replace(/\n(?!<)/g, '<br>');

    return result;
  }

  // ─── 事件绑定 ──────────────────────────────────────────────────

  const msgInput = document.getElementById('msgInput');

  // 自动调整输入框高度
  msgInput.addEventListener('input', () => {
    if (!msgInput.value) {
      msgInput.style.height = '24px';
    } else {
      msgInput.style.height = 'auto';
      msgInput.style.height = Math.min(200, msgInput.scrollHeight) + 'px';
    }
  });

  // Enter 发送，Shift+Enter 换行
  msgInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  document.getElementById('btnSend').addEventListener('click', sendMessage);
  document.getElementById('btnNewChat').addEventListener('click', startNewChat);
  document.getElementById('btnClearChat').addEventListener('click', () => {
    messages = [];
    const container = document.getElementById('chatMessages');
    container.innerHTML = '';
    container.appendChild(createWelcomeScreen());
    saveConversations();
  });

  // AI 设置按钮（showAISettingsModal 由 common.js 提供）
  document.getElementById('btnSettings').addEventListener('click', () => {
    if (typeof showAISettingsModal === 'function') showAISettingsModal();
  });

  // 侧边栏快捷提示按钮
  document.querySelectorAll('.quick-prompt').forEach(btn => {
    btn.addEventListener('click', () => {
      msgInput.value = btn.dataset.q;
      sendMessage();
    });
  });

  // 侧边栏返回全景导航页
  const sidebarBrand = document.getElementById('sidebarBrand');
  if (sidebarBrand) {
    sidebarBrand.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.tabs.create({ url: chrome.runtime.getURL('pages/index.html') });
      }
    });
  }

  // ─── 图片放大查看器交互逻辑 ───────────────────────────────────────────
  const imageViewer = document.getElementById('imageViewer');
  const viewerImage = document.getElementById('viewerImage');
  const viewerClose = document.getElementById('viewerClose');
  const viewerZoomIn = document.getElementById('viewerZoomIn');
  const viewerZoomOut = document.getElementById('viewerZoomOut');
  const viewerActualSize = document.getElementById('viewerActualSize');
  const viewerRotate = document.getElementById('viewerRotate');
  const viewerDownload = document.getElementById('viewerDownload');
  const viewerContent = document.getElementById('viewerContent');

  let viewerScale = 1;
  let viewerRotation = 0;
  let viewerIsDragging = false;
  let viewerStartX = 0;
  let viewerStartY = 0;
  let viewerTranslateX = 0;
  let viewerTranslateY = 0;

  // 使用事件委托，监听聊天区域中对图片的点击
  const chatMessagesEl = document.getElementById('chatMessages');
  if (chatMessagesEl) {
    chatMessagesEl.addEventListener('click', (e) => {
      if (e.target && e.target.classList.contains('md-img')) {
        const imgSrc = e.target.src;
        if (imgSrc) {
          openImageViewer(imgSrc);
        }
      }
    });
  }

  function openImageViewer(src) {
    viewerImage.src = src;
    viewerScale = 1;
    viewerRotation = 0;
    viewerTranslateX = 0;
    viewerTranslateY = 0;
    updateViewerTransform();
    
    imageViewer.style.display = 'flex';
    // 强制重绘
    imageViewer.offsetHeight;
    imageViewer.classList.add('show');
  }

  function closeImageViewer() {
    imageViewer.classList.remove('show');
    setTimeout(() => {
      imageViewer.style.display = 'none';
      viewerImage.src = '';
    }, 300);
  }

  function updateViewerTransform() {
    viewerImage.style.transform = `translate(${viewerTranslateX}px, ${viewerTranslateY}px) scale(${viewerScale}) rotate(${viewerRotation}deg)`;
  }

  // 控制操作事件
  if (viewerZoomIn) {
    viewerZoomIn.addEventListener('click', () => {
      viewerScale = Math.min(10, viewerScale + 0.25);
      updateViewerTransform();
    });
  }
  if (viewerZoomOut) {
    viewerZoomOut.addEventListener('click', () => {
      viewerScale = Math.max(0.1, viewerScale - 0.25);
      updateViewerTransform();
    });
  }
  if (viewerActualSize) {
    viewerActualSize.addEventListener('click', () => {
      viewerScale = 1;
      viewerRotation = 0;
      viewerTranslateX = 0;
      viewerTranslateY = 0;
      updateViewerTransform();
    });
  }
  if (viewerRotate) {
    viewerRotate.addEventListener('click', () => {
      viewerRotation = (viewerRotation + 90) % 360;
      updateViewerTransform();
    });
  }
  if (viewerDownload) {
    viewerDownload.addEventListener('click', () => {
      const src = viewerImage.src;
      if (!src) return;
      const link = document.createElement('a');
      link.href = src;
      link.download = `DevHelper_Image_${Date.now()}.png`;
      link.click();
    });
  }
  if (viewerClose) {
    viewerClose.addEventListener('click', closeImageViewer);
  }

  // 点击背景或按 ESC 键关闭
  if (imageViewer) {
    imageViewer.addEventListener('click', (e) => {
      if (e.target === imageViewer || e.target === viewerContent) {
        closeImageViewer();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && imageViewer && imageViewer.classList.contains('show')) {
      closeImageViewer();
    }
  });

  // 滚轮放大缩小
  if (viewerContent) {
    viewerContent.addEventListener('wheel', (e) => {
      if (!imageViewer || !imageViewer.classList.contains('show')) return;
      e.preventDefault();
      
      const zoomFactor = 0.1;
      if (e.deltaY < 0) {
        viewerScale = Math.min(10, viewerScale + zoomFactor);
      } else {
        viewerScale = Math.max(0.1, viewerScale - zoomFactor);
      }
      updateViewerTransform();
    }, { passive: false });
  }

  // 鼠标拖拽平移
  if (viewerImage) {
    viewerImage.addEventListener('mousedown', (e) => {
      if (!imageViewer || !imageViewer.classList.contains('show')) return;
      e.preventDefault();
      viewerIsDragging = true;
      viewerStartX = e.clientX - viewerTranslateX;
      viewerStartY = e.clientY - viewerTranslateY;
      viewerContent.style.cursor = 'grabbing';
    });
  }

  document.addEventListener('mousemove', (e) => {
    if (!viewerIsDragging) return;
    viewerTranslateX = e.clientX - viewerStartX;
    viewerTranslateY = e.clientY - viewerStartY;
    updateViewerTransform();
  });

  document.addEventListener('mouseup', () => {
    if (viewerIsDragging) {
      viewerIsDragging = false;
      viewerContent.style.cursor = 'grab';
    }
  });

  // ─── 初始化 ────────────────────────────────────────────────────
  loadHistory();
});
