/**
 * DevHelper AI 服务模块
 * 统一管理 AI 调用，支持：
 * - Chrome 内置 AI (Gemini Nano)
 * - OpenAI 兼容接口（自定义 API URL + Key）
 */

const AI_PROVIDERS = {
  BUILTIN: 'builtin',
  OPENAI: 'openai',
};

/** 从 storage 读取 AI 配置 */
async function getAIConfig() {
  const data = await chrome.storage.local.get(['aiConfig']);
  return data.aiConfig || {
    provider: AI_PROVIDERS.OPENAI,
    apiKey: '',
    apiUrl: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
  };
}

/** 保存 AI 配置 */
async function saveAIConfig(config) {
  await chrome.storage.local.set({ aiConfig: config });
}

/**
 * 检测 Chrome 内置 AI 是否可用
 * 强兼容各种不同 Chrome 版本（window.ai.languageModel, window.ai.assistant, window.LanguageModel）
 */
async function checkBuiltinAI() {
  const aiObj = window.ai || window.model || {};
  const lm = aiObj.languageModel || aiObj.assistant || window.LanguageModel;
  if (!lm) return false;
  try {
    if (typeof lm.capabilities === 'function') {
      const caps = await lm.capabilities();
      return caps.available !== 'no';
    }
    if (typeof lm.availability === 'function') {
      const avail = await lm.availability();
      return avail === 'available' || avail === 'downloadable';
    }
    return true;
  } catch (e) {
    console.warn('DevHelper AI 检测内置 AI 发生错误:', e);
    return false;
  }
}

/**
 * 调用 AI 接口（非流式）
 * @param {string} systemPrompt - 系统提示词
 * @param {string} userContent - 用户内容
 * @param {function} onChunk - 流式回调（可选）
 */
async function callAI(systemPrompt, userContent, onChunk = null) {
  // 兼容调用者传入对象参数的格式
  if (typeof systemPrompt === 'object' && systemPrompt !== null) {
    const opts = systemPrompt;
    systemPrompt = opts.systemPrompt || '';
    userContent = opts.userContent || opts.prompt || '';
    onChunk = opts.onChunk || onChunk;
  }

  const config = await getAIConfig();

  // 强化系统提示词以默认要求中文/双语输出
  const chineseConstraint = '\n\n【重要指令：请务必使用简体中文进行回答，若内容涉及代码、英文术语或原数据，进行翻译或者以简体中文为主的双语对照形式展示。】';
  const enhancedSystemPrompt = (systemPrompt || '') + chineseConstraint;

  if (config.provider === AI_PROVIDERS.BUILTIN) {
    let textPrompt = userContent;
    if (Array.isArray(userContent)) {
      const textItem = userContent.find(item => item.type === 'text');
      textPrompt = textItem ? textItem.text : '分析截图';
    }
    return callBuiltinAI(enhancedSystemPrompt, textPrompt, onChunk);
  }
  return callOpenAI(config, enhancedSystemPrompt, userContent, onChunk);
}

/** 调用 Chrome 内置 AI（强兼容版） */
async function callBuiltinAI(systemPrompt, userContent, onChunk) {
  const aiObj = window.ai || window.model || {};
  const lm = aiObj.languageModel || aiObj.assistant || window.LanguageModel;
  if (!lm) {
    throw new Error('未检测到 Chrome 内置 AI 功能，请按说明开启');
  }

  // Chrome LanguageModel API 会话配置
  // 显式声明 outputLanguage: 'en' 以消除 Chrome 核心对输出语言缺失的 Warning 收集
  const sessionOptions = {
    systemPrompt,
    expectedInputLanguages: ['zh', 'en'],
    outputLanguage: 'en',
  };

  let session;
  try {
    if (typeof lm.create === 'function') {
      session = await lm.create(sessionOptions);
    } else if (typeof lm.createTextSession === 'function') {
      session = await lm.createTextSession(sessionOptions);
    } else {
      throw new Error('当前 Chrome 版本的内置 AI 创建会话方法不受支持');
    }
  } catch (e) {
    let friendlyMsg = e.message;
    if (e.message.toLowerCase().includes('space') || e.message.toLowerCase().includes('download')) {
      friendlyMsg = '磁盘空间不足，无法下载/加载本地 Gemini Nano 模型。建议您清理系统磁盘空间（通常需要 10GB 以上空闲空间），或者在右上方配置「AI 设置」切换为云端 API 运行';
    }
    throw new Error(`创建本地 AI 会话失败：${friendlyMsg}`);
  }

  const prompt = userContent;

  try {
    if (onChunk && typeof session.promptStreaming === 'function') {
      const stream = session.promptStreaming(prompt);
      let fullText = '';
      for await (const chunk of stream) {
        if (fullText && chunk.startsWith(fullText)) {
          // 如果新 chunk 包含之前的 fullText，说明是全量模式，直接使用 chunk
          fullText = chunk;
        } else {
          // 否则是最新 Chrome 标准的增量模式，累加 Token
          fullText += chunk;
        }
        onChunk(fullText);
      }
      if (typeof session.destroy === 'function') session.destroy();
      return fullText;
    }

    const result = await session.prompt(prompt);
    if (typeof session.destroy === 'function') session.destroy();
    return result;
  } catch (e) {
    if (typeof session?.destroy === 'function') session.destroy();
    throw new Error(`本地 AI 会话执行失败：${e.message}`);
  }
}

/** 调用 OpenAI 兼容接口（支持流式） */
async function callOpenAI(config, systemPrompt, userContent, onChunk) {
  if (!config.apiKey) {
    throw new Error('请先在 AI 设置中配置 API Key');
  }

  const body = {
    model: config.model || 'gpt-4o-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userContent },
    ],
    stream: !!onChunk,
    temperature: 0.7,
    max_tokens: 2048,
  };

  let url = config.apiUrl || 'https://api.openai.com/v1/chat/completions';
  if (!url.endsWith('/chat/completions') && !url.includes('/chat/completions?')) {
    url = url.replace(/\/$/, '') + '/chat/completions';
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `HTTP ${response.status}`);
  }

  if (onChunk) {
    // SSE 流式解析（带包粘连/截断缓冲区与粘连合并包支持）
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';       // 最终答案（delta.content 累积）
    let reasoningText = '';  // 思维链（delta.reasoning_content 累积）
    let buffer = '';

    const processLine = (line) => {
      // 核心修复：使用正向先行断言，将单行内可能粘连的多个 data: 字段（如 data: {...}data: [DONE]）精准切分开
      const parts = line.split(/(?=data:)/);
      for (const part of parts) {
        const trimmed = part.trim();
        if (!trimmed || !trimmed.startsWith('data:')) continue;
        const data = trimmed.slice(5).trim();
        if (data === '[DONE]') continue;
        try {
          const parsed = JSON.parse(data);
          const delta = parsed.choices?.[0]?.delta || {};

          // 优先处理最终答案内容（delta.content）
          const contentDelta = delta.content || '';
          if (contentDelta) {
            fullText += contentDelta;
            onChunk(fullText, reasoningText);
            continue;
          }

          // 兼容推理模型的思维链输出（delta.reasoning_content）：
          const reasoningDelta = delta.reasoning_content || '';
          if (reasoningDelta) {
            reasoningText += reasoningDelta;
            // fullText 传空字符串，表示当前仍在思维链阶段
            onChunk('', reasoningText);
          }
        } catch (e) {
          console.warn('SSE 单包 JSON 解析异常，跳过残损包:', e, '原始片段:', trimmed);
        }
      }
    };

    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        if (buffer.trim()) processLine(buffer);
        break;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      // 截留最后一行可能不完整的段落到缓冲区
      buffer = lines.pop() || '';
      for (const line of lines) {
        processLine(line);
      }
    }
    return fullText;
  }

  const json = await response.json();
  return json.choices?.[0]?.message?.content || '';
}

// 导出供工具页面使用
window.DevHelperAI = { callAI, getAIConfig, saveAIConfig, checkBuiltinAI, AI_PROVIDERS };
