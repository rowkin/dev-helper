// DevHelper Popup 主脚本 - 工具列表、搜索、路由

// 工具配置列表
const TOOLS = [
  // JSON 处理
  { id: 'json-format', name: 'JSON 格式化', desc: '美化、压缩、校验 JSON 数据', icon: '{ }', color: 'color-indigo', category: 'data', badge: null, shortcut: '⌥1' },
  { id: 'json-diff', name: 'JSON 对比', desc: '两段 JSON 的差异对比分析', icon: 'DI', color: 'color-violet', category: 'data', badge: null },
  
  // 编解码
  { id: 'encode-decode', name: '编解码工具', desc: 'URL、Base64、Unicode、Hex 互转', icon: 'ENC', color: 'color-cyan', category: 'encode', badge: null, shortcut: '⌥2' },
  { id: 'jwt-parser', name: 'JWT 解析', desc: '解析和验证 JWT Token 结构', icon: 'JWT', color: 'color-sky', category: 'encode', badge: null },
  { id: 'hash-calc', name: '哈希计算', desc: 'MD5、SHA1、SHA256 哈希值计算', icon: '#', color: 'color-teal', category: 'encode', badge: null },
  
  // 格式转换
  { id: 'timestamp', name: '时间戳转换', desc: 'Unix 时间戳与日期字符串互转', icon: '⏱', color: 'color-amber', category: 'convert', badge: null, shortcut: '⌥3' },
  { id: 'color-convert', name: '颜色转换', desc: 'HEX / RGB / HSL / HSV 互转', icon: '🎨', color: 'color-pink', category: 'convert', badge: null },
  { id: 'number-base', name: '进制转换', desc: '2~36 进制数字互转', icon: '01', color: 'color-orange', category: 'convert', badge: null },
  
  // 开发工具
  { id: 'api-tester', name: 'API 调试', desc: '轻量 Postman，支持 GET/POST/PUT/DELETE', icon: 'API', color: 'color-emerald', category: 'dev', badge: 'hot', shortcut: '⌥4' },
  { id: 'code-beautify', name: '代码格式化', desc: 'JS/CSS/HTML/JSON 代码美化', icon: 'JS', color: 'color-indigo', category: 'dev', badge: null },
  { id: 'markdown-editor', name: 'Markdown 编辑器', desc: '实时预览 · 代码高亮 · Mermaid 图表渲染', icon: 'MD', color: 'color-teal', category: 'dev', badge: 'new' },
  { id: 'regex-test', name: '正则测试', desc: '正则表达式在线调试匹配', icon: 'RE', color: 'color-violet', category: 'dev', badge: null },
  { id: 'page-timing', name: '页面性能检测', desc: '检测当前页面加载耗时及核心 Web 指标', icon: '⚡', color: 'color-orange', category: 'dev', badge: 'new', shortcut: '⌥5' },
  { id: 'ip-speed', name: 'IP 与网速检测', desc: '查询内外网 IP 地址与网络延迟，测试网络实时下载速度', icon: '🌐', color: 'color-indigo', category: 'dev', badge: 'new', shortcut: '⌥6' },
  
  // 生成工具
  { id: 'qrcode', name: '二维码工具', desc: '生成/解码二维码，支持自定义', icon: 'QR', color: 'color-cyan', category: 'generate', badge: null },
  { id: 'uuid-gen', name: 'UUID 生成器', desc: 'UUID v4、雪花 ID、NanoID 批量生成', icon: 'ID', color: 'color-sky', category: 'generate', badge: null },
  { id: 'password-gen', name: '密码生成器', desc: '按规则生成安全随机密码', icon: '🔐', color: 'color-rose', category: 'generate', badge: null },
  
  // 图片工具
  { id: 'img-base64', name: '图片 Base64', desc: '图片与 Base64 字符串互转', icon: 'IMG', color: 'color-amber', category: 'image', badge: null },
  { id: 'screenshot', name: '屏幕截图', desc: '可视区域、整个页面、自定义区域截图并支持标注', icon: '📸', color: 'color-rose', category: 'image', badge: 'new' },
];

// 类别标签
const CATEGORIES = [
  { id: 'all', label: '全部' },
  { id: 'data', label: '数据处理' },
  { id: 'encode', label: '编解码' },
  { id: 'convert', label: '格式转换' },
  { id: 'dev', label: '开发工具' },
  { id: 'generate', label: '生成工具' },
  { id: 'image', label: '图片工具' },
];

// 状态
let state = {
  currentTab: 'all',
  searchQuery: '',
  recentTools: [],
  favoriteTools: [],
};

// 初始化主题（支持时间段判定与用户手动覆盖偏好）
function initTheme() {
  const manual = localStorage.getItem('devhelper-theme-manual') === 'true';
  let theme = 'light';
  if (manual) {
    theme = localStorage.getItem('devhelper-theme') || 'light';
  } else {
    const hour = new Date().getHours();
    theme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
    localStorage.setItem('devhelper-theme', theme);
  }
  document.documentElement.setAttribute('data-theme', theme);
  return theme;
}

// 切换主题并持久化覆盖标识
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('devhelper-theme', next);
  localStorage.setItem('devhelper-theme-manual', 'true');
  
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.set({ 'devhelper-theme': next, 'devhelper-theme-manual': 'true' }).catch(() => {});
  }
  
  updateThemeToggleIcons(next);
}

// 更新界面所有的 ☀️/🌙 开关图标
function updateThemeToggleIcons(theme) {
  document.querySelectorAll('.theme-toggle-icon').forEach(el => {
    el.textContent = theme === 'dark' ? '☀️' : '🌙';
  });
}

// 初始化
async function init() {
  const currentTheme = initTheme();
  
  await loadStorage();
  
  // 延迟微调，确保 DOM 加载完全后设置 icon 状态
  requestAnimationFrame(() => {
    updateThemeToggleIcons(currentTheme);
  });
  
  renderAllTools();
  renderRecentTools();
  bindEvents();
  focusSearch();
}

// 从 storage 加载持久化数据
async function loadStorage() {
  const data = await chrome.storage.local.get(['recentTools', 'favoriteTools']);
  state.recentTools = data.recentTools || [];
  state.favoriteTools = data.favoriteTools || [];
}

// 渲染全部工具列表
function renderAllTools(filter = '') {
  const list = document.getElementById('allToolsList');
  const countEl = document.getElementById('allCount');
  const emptyState = document.getElementById('emptyState');
  const section = document.getElementById('allToolsSection');

  const query = filter.toLowerCase().trim();
  const filtered = TOOLS.filter(t => {
    if (!query) return true;
    return t.name.toLowerCase().includes(query) ||
           t.desc.toLowerCase().includes(query) ||
           t.category.toLowerCase().includes(query);
  });

  countEl.textContent = filtered.length;
  list.innerHTML = '';

  if (filtered.length === 0 && query) {
    section.style.display = 'none';
    emptyState.style.display = 'flex';
    return;
  }

  emptyState.style.display = 'none';
  section.style.display = '';

  filtered.forEach(tool => {
    list.appendChild(createToolItem(tool));
  });
}

// 渲染最近使用
function renderRecentTools() {
  const section = document.getElementById('recentSection');
  const list = document.getElementById('recentList');
  const countEl = document.getElementById('recentCount');

  const recentItems = state.recentTools
    .map(id => TOOLS.find(t => t.id === id))
    .filter(Boolean)
    .slice(0, 4);

  if (recentItems.length === 0 || state.searchQuery) {
    section.style.display = 'none';
    return;
  }

  section.style.display = '';
  countEl.textContent = recentItems.length;
  list.innerHTML = '';
  recentItems.forEach(tool => list.appendChild(createToolItem(tool)));
}

// 创建工具条目 DOM
function createToolItem(tool) {
  const item = document.createElement('button');
  item.className = `tool-item${state.favoriteTools.includes(tool.id) ? ' favorited' : ''}`;
  item.dataset.toolId = tool.id;

  const iconContent = tool.icon.length <= 3
    ? `<span style="font-size:11px;font-weight:700;letter-spacing:-0.5px">${tool.icon}</span>`
    : `<span style="font-size:11px">${tool.icon}</span>`;

  const isFav = state.favoriteTools.includes(tool.id);

  item.innerHTML = `
    <div class="tool-icon ${tool.color}">${iconContent}</div>
    <div class="tool-info">
      <div class="tool-name">${tool.name}</div>
      <div class="tool-desc">${tool.desc}</div>
    </div>
    ${tool.badge ? `<span class="tool-badge badge-${tool.badge}">${tool.badge === 'hot' ? '热门' : '新'}</span>` : ''}
    <button class="tool-fav-star-btn${isFav ? ' favorited' : ''}" title="收藏/取消收藏">
      ${isFav ? '★' : '☆'}
    </button>
    <div class="tool-arrow">
      <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
    </div>
  `;

  item.addEventListener('click', () => openTool(tool));
  
  // 绑定五角星按钮的点击事件
  const favStar = item.querySelector('.tool-fav-star-btn');
  favStar.addEventListener('click', async (e) => {
    e.stopPropagation(); // 阻止触发 item.click 打开页面
    await toggleFavorite(tool.id);
    renderAllTools(state.searchQuery);
    renderRecentTools();
    if (state.currentTab === 'favorites') {
      switchTab('favorites');
    }
  });

  return item;
}

// 打开工具页面
async function openTool(tool) {
  // 记录最近使用
  state.recentTools = [tool.id, ...state.recentTools.filter(id => id !== tool.id)].slice(0, 10);
  await chrome.storage.local.set({ recentTools: state.recentTools });

  let url = chrome.runtime.getURL(`pages/${tool.id}.html`);
  
  // 如果是页面性能检测或屏幕截图工具，尝试携带当前活动页面 Tab ID
  if (tool.id === 'page-timing' || tool.id === 'screenshot') {
    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab && activeTab.url && !activeTab.url.startsWith('chrome') && !activeTab.url.startsWith('chrome-extension') && !activeTab.url.startsWith('edge') && !activeTab.url.startsWith('about:')) {
        const paramName = tool.id === 'screenshot' ? 'sourceTabId' : 'tabId';
        url += `?${paramName}=${activeTab.id}`;
      }
    } catch (e) {
      console.log('无法查询当前活跃 Tab:', e);
    }
  }

  chrome.tabs.create({ url });
  window.close();
}

// 切换收藏
async function toggleFavorite(toolId) {
  if (state.favoriteTools.includes(toolId)) {
    state.favoriteTools = state.favoriteTools.filter(id => id !== toolId);
  } else {
    state.favoriteTools = [toolId, ...state.favoriteTools];
  }
  await chrome.storage.local.set({ favoriteTools: state.favoriteTools });
}

// 绑定事件
function bindEvents() {
  // 搜索
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', (e) => {
    state.searchQuery = e.target.value;
    if (state.currentTab === 'all') {
      renderAllTools(state.searchQuery);
      renderRecentTools();
    } else if (state.currentTab === 'favorites') {
      renderFavorites(state.searchQuery);
    }
  });

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      state.searchQuery = '';
      if (state.currentTab === 'all') {
        renderAllTools();
        renderRecentTools();
      } else if (state.currentTab === 'favorites') {
        renderFavorites();
      }
    }
  });

  // 快捷键 / 聚焦搜索
  document.addEventListener('keydown', (e) => {
    if (e.key === '/') {
      e.preventDefault();
      focusSearch();
    }
  });

  // 底部标签
  document.querySelectorAll('.footer-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.footer-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      showTab(btn.dataset.tab);
    });
  });

  // 设置按钮
  document.getElementById('btnSettings').addEventListener('click', openSettings);

  // 主题快速切换按钮
  document.getElementById('btnThemeToggle')?.addEventListener('click', toggleTheme);

  // Logo 点击跳转全景工具导航页
  document.querySelector('.header-brand')?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('pages/index.html') });
  });
}

// 显示对应标签内容
function showTab(tab) {
  state.currentTab = tab;
  const mainContent = document.getElementById('mainContent');

  if (tab === 'all') {
    mainContent.innerHTML = `
      <section class="tool-section" id="recentSection">
        <div class="section-header">
          <span class="section-title">最近使用</span>
          <span class="section-count" id="recentCount">0</span>
        </div>
        <div class="tool-list" id="recentList"></div>
      </section>
      <section class="tool-section" id="allToolsSection">
        <div class="section-header">
          <span class="section-title">全部工具</span>
          <span class="section-count" id="allCount">0</span>
        </div>
        <div class="tool-list" id="allToolsList"></div>
      </section>
      <div class="empty-state" id="emptyState" style="display:none;">
        <svg viewBox="0 0 64 64" fill="none"><circle cx="28" cy="28" r="16" stroke="currentColor" stroke-width="3"/><line x1="40" y1="40" x2="56" y2="56" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>
        <p>未找到匹配的工具</p><span>试试其他关键词</span>
      </div>`;
    renderAllTools(state.searchQuery);
    renderRecentTools();
  } else if (tab === 'favorites') {
    renderFavorites(state.searchQuery);
  } else if (tab === 'feedback') {
    renderFeedback();
  }
}

// 渲染收藏视图
function renderFavorites(filter = '') {
  const mainContent = document.getElementById('mainContent');
  const favItems = state.favoriteTools.map(id => TOOLS.find(t => t.id === id)).filter(Boolean);

  const query = filter.toLowerCase().trim();
  const filtered = favItems.filter(t => {
    if (!query) return true;
    return t.name.toLowerCase().includes(query) ||
           t.desc.toLowerCase().includes(query) ||
           t.category.toLowerCase().includes(query);
  });

  if (filtered.length === 0) {
    if (query) {
      mainContent.innerHTML = `
        <div class="empty-state" id="emptyState">
          <svg viewBox="0 0 64 64" fill="none"><circle cx="28" cy="28" r="16" stroke="currentColor" stroke-width="3"/><line x1="40" y1="40" x2="56" y2="56" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>
          <p>未找到匹配的工具</p><span>试试其他关键词</span>
        </div>`;
    } else {
      mainContent.innerHTML = `
        <div class="favorites-empty">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          <p>暂无收藏工具</p>
          <span>右键点击工具可收藏</span>
        </div>`;
    }
    return;
  }

  mainContent.innerHTML = `
    <section class="tool-section">
      <div class="section-header">
        <span class="section-title">我的收藏</span>
        <span class="section-count">${filtered.length}</span>
      </div>
      <div class="tool-list" id="favList"></div>
    </section>`;
  const list = document.getElementById('favList');
  filtered.forEach(tool => list.appendChild(createToolItem(tool)));
}

// 渲染反馈视图
function renderFeedback() {
  const mainContent = document.getElementById('mainContent');
  mainContent.innerHTML = `
    <div class="feedback-view">
      <div class="feedback-card">
        <h3>问题反馈 / 功能建议</h3>
        <p>发现 Bug 或有新功能想法？欢迎提交 Issue 到 GitHub 仓库</p>
        <button class="feedback-btn" id="btnGithub">
          <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path fill-rule="evenodd" d="M10 0C4.477 0 0 4.484 0 10.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0110 4.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.203 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.942.359.31.678.921.678 1.856 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0020 10.017C20 4.484 15.522 0 10 0z" clip-rule="evenodd"/></svg>
          GitHub Issues
        </button>
      </div>
      <div class="version-info">
        <p>DevHelper v1.4.0 · 七九在线科技</p>
      </div>
    </div>`;

  document.getElementById('btnGithub').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://github.com/rowkin/dev-helper/issues' });
  });
}

// 打开设置面板
function openSettings() {
  let panel = document.getElementById('settingsPanel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'settingsPanel';
    panel.className = 'settings-panel';
    panel.innerHTML = `
      <div class="settings-header">
        <button class="btn-back" id="btnBack">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
        </button>
        <h2>设置</h2>
      </div>
      <div class="settings-body">
        <div class="settings-group">
          <div class="settings-group-title">通用快捷键</div>
          
          <div class="settings-item hoverable" id="itemSystemShortcut" title="点击前往 Chrome 设置中心修改">
            <div style="flex:1">
              <div class="settings-item-label">系统唤起快捷键</div>
              <div class="settings-item-desc" style="color:var(--primary)">Alt+Shift+D (点击可前往 Chrome 设置修改)</div>
            </div>
            <span style="font-size:12px;color:var(--text-tertiary)">→</span>
          </div>
          
          <div class="settings-item" style="flex-direction:column;align-items:stretch;gap:8px">
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div class="settings-item-label">页面内 AI 助手快捷键</div>
              <button class="text-btn-accent" id="btnResetShortcut" style="font-size:11px;color:var(--accent);background:none;border:none;cursor:pointer;padding:2px 6px;border-radius:4px">还原默认</button>
            </div>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="text" id="shortcutInput" readonly placeholder="按下按键组合自定义..." 
                     style="flex:1;padding:6px 10px;border-radius:6px;border:1px solid var(--border-light);background:var(--bg-base);color:var(--text-primary);font-size:12px;text-align:center;font-weight:700">
            </div>
            <div class="settings-item-desc" style="margin-top:-2px">在任意工具页面中，按下该组合键即可快速唤醒/隐藏右侧 AI 助手。</div>
          </div>
        </div>
        
        <div class="settings-group">
          <div class="settings-group-title">关于</div>
          <div class="settings-item">
            <div class="settings-item-label">版本</div>
            <div style="font-size:12px;color:var(--text-tertiary)">v1.4.0</div>
          </div>
        </div>
      </div>`;
      
    document.getElementById('app').appendChild(panel);
    
    // 返回按钮
    panel.querySelector('#btnBack').addEventListener('click', () => {
      panel.classList.remove('open');
    });
    
    // 系统快捷键点击事件：跳转到 Chrome 原生设置中心
    panel.querySelector('#itemSystemShortcut').addEventListener('click', () => {
      chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
    });
    
    // 快捷键输入框录入逻辑
    const input = panel.querySelector('#shortcutInput');
    
    // 读取持久化值
    chrome.storage.local.get(['custom-ai-shortcut']).then((res) => {
      input.value = res['custom-ai-shortcut'] || 'Alt+Shift+A';
    });
    
    input.addEventListener('keydown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return;
      
      const keys = [];
      if (e.ctrlKey) keys.push('Ctrl');
      if (e.shiftKey) keys.push('Shift');
      if (e.altKey) keys.push('Alt');
      if (e.metaKey) keys.push('Meta');
      
      let keyName = e.key;
      if (keyName === ' ') keyName = 'Space';
      else if (keyName.length === 1) keyName = keyName.toUpperCase();
      
      keys.push(keyName);
      
      const shortcutStr = keys.join('+');
      input.value = shortcutStr;
      
      chrome.storage.local.set({ 'custom-ai-shortcut': shortcutStr });
    });
    
    // 还原默认快捷键按钮
    panel.querySelector('#btnResetShortcut').addEventListener('click', () => {
      input.value = 'Alt+Shift+A';
      chrome.storage.local.set({ 'custom-ai-shortcut': 'Alt+Shift+A' });
      // 触发 toast 提示
      if (typeof showToast !== 'undefined') {
        showToast('已恢复默认快捷键');
      } else {
        alert('已恢复默认快捷键');
      }
    });
  }
  requestAnimationFrame(() => panel.classList.add('open'));
}

function focusSearch() {
  document.getElementById('searchInput')?.focus();
}

// 启动
document.addEventListener('DOMContentLoaded', init);
