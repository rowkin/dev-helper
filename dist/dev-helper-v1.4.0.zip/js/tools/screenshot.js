// DevHelper - 屏幕截图工具脚本
// 支持可视区域、整页滚动拼接、区域截取、本地上传与 Canvas 标注功能

let sourceTabId = null;
let myTabId = null;

// 画布相关状态
let canvas = null;
let ctx = null;
let bgImage = null; // 背景截图 Image 对象
let isDrawing = false;
let startX = 0;
let startY = 0;
let lastX = 0;
let lastY = 0;

// 当前标注工具配置
let currentTool = 'brush'; // 'brush', 'rect', 'arrow', 'text', 'mosaic'
let currentColor = '#ef4444';
let currentLineWidth = 4;

// 撤销历史
let historyList = [];
let maxHistory = 20;
let currentExtractedText = '';
let currentCaptureType = 'visible'; // 'visible', 'full', 'area', or 'local'

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
  canvas = document.getElementById('editorCanvas');
  ctx = canvas.getContext('2d', { willReadFrequently: true });

  // 获取自己的 Tab ID
  if (window.chrome && chrome.tabs) {
    chrome.tabs.getCurrent(tab => {
      if (tab) myTabId = tab.id;
    });
  }

  // 解析 URL 参数获取要截取的目标 Tab
  const urlParams = new URLSearchParams(window.location.search);
  const tabIdStr = urlParams.get('sourceTabId');
  if (tabIdStr) {
    sourceTabId = parseInt(tabIdStr);
    // 验证 Tab 是否合法
    chrome.tabs.get(sourceTabId, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        sourceTabId = null;
        showTabErrorTip();
      } else if (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
        sourceTabId = null;
        showTabErrorTip('受浏览器安全限制，无法截取系统级页面（chrome://）。您可以使用下方“本地标注”功能。');
      }
    });
  } else {
    showTabErrorTip();
  }

  // 绑定截图控制面板事件
  document.getElementById('btnVisible').addEventListener('click', () => handleCapture('visible'));
  document.getElementById('btnFull').addEventListener('click', () => handleCapture('full'));
  document.getElementById('btnArea').addEventListener('click', () => handleCapture('area'));
  document.getElementById('btnDisplayMedia').addEventListener('click', captureScreenStream);

  // 绑定本地上传
  const uploadZone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  uploadZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', handleFileSelect);
  
  // 拖拽上传
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--primary)';
  });
  uploadZone.addEventListener('dragleave', () => {
    uploadZone.style.borderColor = 'var(--border)';
  });
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.borderColor = 'var(--border)';
    if (e.dataTransfer.files.length > 0) {
      loadImageFile(e.dataTransfer.files[0]);
    }
  });

  // 剪贴板粘贴
  document.addEventListener('paste', (e) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        const blob = items[i].getAsFile();
        loadImageFile(blob);
        break;
      }
    }
  });

  // 绑定编辑器标注工具
  setupEditorTools();
});

// 显示 Tab 不可用提示
function showTabErrorTip(msg) {
  const customMsg = msg || '提示：未检测到有效的目标网页。请在目标网页中打开 DevHelper 扩展图标，再启动“屏幕截图”工具。当前您仍可点击右下角上传或粘贴本地图片进行标注。';
  showToast(customMsg, 'info', 6000);
  
  // 禁用三大截图按钮
  document.getElementById('btnVisible').style.opacity = '0.5';
  document.getElementById('btnVisible').style.cursor = 'not-allowed';
  document.getElementById('btnFull').style.opacity = '0.5';
  document.getElementById('btnFull').style.cursor = 'not-allowed';
  document.getElementById('btnArea').style.opacity = '0.5';
  document.getElementById('btnArea').style.cursor = 'not-allowed';
}

// 统一处理截图触发（支持倒计时）
async function handleCapture(type) {
  if (!sourceTabId) {
    showToast('无有效网页连接，请使用本地标注或在具体网页中重新打开扩展', 'error');
    return;
  }

  const delaySelect = document.getElementById('optDelay');
  const delaySeconds = parseInt(delaySelect.value);

  if (delaySeconds > 0) {
    // 倒计时逻辑
    const overlay = document.getElementById('countdownOverlay');
    overlay.style.display = 'flex';
    overlay.textContent = delaySeconds;

    let count = delaySeconds;
    const interval = setInterval(async () => {
      count--;
      if (count <= 0) {
        clearInterval(interval);
        overlay.style.display = 'none';
        executeCapture(type);
      } else {
        overlay.textContent = count;
      }
    }, 1000);
  } else {
    executeCapture(type);
  }
}

// 执行具体的截图动作
async function executeCapture(type) {
  currentCaptureType = type;
  currentExtractedText = '';
  // 切回原 Tab
  await chrome.tabs.update(sourceTabId, { active: true });
  
  // 稍微等一下页面转场渲染
  setTimeout(async () => {
    try {
      if (type === 'visible') {
        captureVisibleFlow();
      } else if (type === 'area') {
        captureAreaFlow();
      } else if (type === 'full') {
        captureFullPageFlow();
      }
    } catch (e) {
      console.error(e);
      showToast('截图失败，网页可能已刷新或不可用', 'error');
      // 切回截图 Tab
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
    }
  }, 250);
}

// ==================== 1. 可视区截图流程 ====================
function captureVisibleFlow() {
  chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (response) => {
    if (myTabId) chrome.tabs.update(myTabId, { active: true });
    
    if (response && response.dataUrl) {
      processCaptureResult(response.dataUrl);
    } else {
      showToast('可视区域截图失败，请确保目标网页已加载完毕', 'error');
    }
  });
}

// ==================== 2. 区域截图流程 ====================
async function captureAreaFlow() {
  // 注入 content script
  await injectHelperScript();

  // 向 content script 发送指令启动框选
  chrome.tabs.sendMessage(sourceTabId, { action: 'startAreaSelect' }, (response) => {
    if (chrome.runtime.lastError) {
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
      showToast('无法在系统页面或已受保护的页面执行选择', 'error');
      return;
    }

    if (response && response.status === 'success') {
      const rect = response.rect;
      currentExtractedText = rect.extractedText || '';
      // 捕获当前可视区
      chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (capRes) => {
        if (myTabId) chrome.tabs.update(myTabId, { active: true });
        
        if (capRes && capRes.dataUrl) {
          cropImage(capRes.dataUrl, rect);
        } else {
          showToast('可视截图失败，无法裁剪选区', 'error');
        }
      });
    } else {
      // 取消或失败，返回
      if (myTabId) chrome.tabs.update(myTabId, { active: true });
    }
  });
}

// 注入 content script 的通用方法
async function injectHelperScript() {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript({
      target: { tabId: sourceTabId },
      files: ['js/content/screenshot-helper.js']
    }, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

// 根据选区坐标裁剪图片
function cropImage(dataUrl, rect) {
  const tempImg = new Image();
  tempImg.onload = () => {
    const dpr = rect.dpr || 1;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = rect.width * dpr;
    tempCanvas.height = rect.height * dpr;
    const tempCtx = tempCanvas.getContext('2d');

    // 裁剪绘制
    tempCtx.drawImage(
      tempImg,
      rect.x * dpr,
      rect.y * dpr,
      rect.width * dpr,
      rect.height * dpr,
      0,
      0,
      rect.width * dpr,
      rect.height * dpr
    );

    const croppedDataUrl = tempCanvas.toDataURL('image/png');
    processCaptureResult(croppedDataUrl);
  };
  tempImg.src = dataUrl;
}

// ==================== 3. 整页长截图流程 ====================
async function captureFullPageFlow() {
  await injectHelperScript();

  // 1. 获取页面初始尺寸并准备滚动
  const info = await new Promise((resolve) => {
    chrome.tabs.sendMessage(sourceTabId, { action: 'prepareScroll' }, (res) => {
      resolve(chrome.runtime.lastError ? null : res);
    });
  });

  if (!info) {
    if (myTabId) chrome.tabs.update(myTabId, { active: true });
    showToast('获取页面信息失败，无法进行整页截图', 'error');
    return;
  }

  let { totalHeight, viewportWidth, viewportHeight, dpr, containerRect } = info;
  const captureWidth = containerRect ? containerRect.width : viewportWidth;

  // 2. 创建拼图 Canvas，高度动态增长，初始留足空间
  // 浏览器/GPU 对 canvas 最大尺寸有限制（通常 16384px），超限时 getContext 返回 null
  const MAX_CANVAS_HEIGHT = 16000; // 留 384px 余量，避免恰好踩线
  let canvasHeight = Math.min(totalHeight * dpr, MAX_CANVAS_HEIGHT);
  const stitchCanvas = document.createElement('canvas');
  stitchCanvas.width = captureWidth * dpr;
  stitchCanvas.height = canvasHeight;
  const stitchCtx = stitchCanvas.getContext('2d');
  if (!stitchCtx) {
    if (myTabId) chrome.tabs.update(myTabId, { active: true });
    showToast('页面过长，Canvas 超出硬件限制，无法完成整页截图', 'error');
    return;
  }

  let currentScrollY = 0; // 下一帧的目标滚动 Y 值
  let drawnHeight = 0;    // 已经绘制到 stitchCanvas 的内容高度（像素，非 DPR）
  let frameCount = 0;

  showToast('正在生成整页长截图，请稍候...', 'info', 10000);

  // 3. 主循环：逐帧滚动 → 截图 → 拼接
  while (true) {
    frameCount++;

    // 3.1 发送滚动指令，等待 content script 确认（含 350ms 延迟 + RAF）
    const scrollRes = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), 6000); // 6s 超时保护
      chrome.tabs.sendMessage(sourceTabId, { action: 'scrollTo', y: currentScrollY }, (res) => {
        clearTimeout(timer);
        resolve(chrome.runtime.lastError ? null : res);
      });
    });

    if (!scrollRes) {
      // 消息通道超时或异常，结束
      console.warn('[DevHelper] scrollTo 无响应，结束整页截图');
      break;
    }

    const actualY = scrollRes.actualY;
    const currentTotalHeight = scrollRes.currentTotalHeight || totalHeight;
    const isBottom = scrollRes.isBottom;

    // 3.2 如果页面动态增高，扩展 stitchCanvas 高度（不超过硬件上限）
    const neededHeight = currentTotalHeight * dpr + 200 * dpr;
    if (neededHeight > stitchCanvas.height && stitchCanvas.height < MAX_CANVAS_HEIGHT) {
      const expandTo = Math.min(neededHeight, MAX_CANVAS_HEIGHT);
      try {
        const newCanvas = document.createElement('canvas');
        newCanvas.width = stitchCanvas.width;
        newCanvas.height = expandTo;
        const newCtx = newCanvas.getContext('2d');
        if (!newCtx) throw new Error('canvas getContext returned null');
        // 先把现有内容复制到新 canvas，再重置旧 canvas 并写回
        newCtx.drawImage(stitchCanvas, 0, 0);
        stitchCanvas.width = newCanvas.width;
        stitchCanvas.height = newCanvas.height;
        stitchCtx.drawImage(newCanvas, 0, 0);
      } catch (e) {
        // canvas 扩容失败（通常是超过 GPU 限制），停止扩展，继续截图直到当前高度满
        console.warn('[DevHelper] canvas 扩容失败，将截取至当前高度:', e);
      }
    }

    // 3.3 截取当前可视区
    const capRes = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (res) => {
        resolve(chrome.runtime.lastError ? null : res);
      });
    });

    if (!capRes || !capRes.dataUrl) {
      console.warn('[DevHelper] 截图失败，结束整页截图');
      break;
    }

    // 3.4 将截图绘制到拼图 Canvas
    await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        try {
          if (isBottom) {
            // === 最后一帧：精确裁切，只绘制"还没画过的部分" ===
            // actualY 是当前实际滚动位置（内容顶到视口顶的距离，CSS 像素）
            // drawnHeight 是已绘制到 stitchCanvas 的高度（CSS 像素）
            // sourceY 是从截图的哪一行（相对视口顶）开始取未绘制内容
            const remainContent = Math.max(0, currentTotalHeight - drawnHeight);
            if (remainContent > 0) {
              // 已绘高度 - 当前滚动位 = 截图中已被绘过的部分高度
              const sourceY = Math.max(0, drawnHeight - actualY);
              // 截图中实际可用高度，防止 sourceY 越界导致取到视口外
              const availableH = Math.min(remainContent, viewportHeight - sourceY);

              if (availableH > 0) {
                if (containerRect) {
                  stitchCtx.drawImage(
                    img,
                    containerRect.left * dpr,
                    (containerRect.top + sourceY) * dpr,
                    containerRect.width * dpr,
                    availableH * dpr,
                    0,
                    drawnHeight * dpr,
                    containerRect.width * dpr,
                    availableH * dpr
                  );
                } else {
                  stitchCtx.drawImage(
                    img,
                    0,
                    sourceY * dpr,
                    viewportWidth * dpr,
                    availableH * dpr,
                    0,
                    drawnHeight * dpr,
                    viewportWidth * dpr,
                    availableH * dpr
                  );
                }
                drawnHeight += availableH;
              }
            }
          } else {
            // === 普通帧：绘制整个视口高度 ===
            if (containerRect) {
              stitchCtx.drawImage(
                img,
                containerRect.left * dpr,
                containerRect.top * dpr,
                containerRect.width * dpr,
                containerRect.height * dpr,
                0,
                drawnHeight * dpr,
                containerRect.width * dpr,
                containerRect.height * dpr
              );
            } else {
              stitchCtx.drawImage(
                img,
                0, 0,
                viewportWidth * dpr,
                viewportHeight * dpr,
                0,
                drawnHeight * dpr,
                viewportWidth * dpr,
                viewportHeight * dpr
              );
            }
            drawnHeight += viewportHeight;
          }
        } catch (drawErr) {
          // drawImage 失败（通常是 canvas 被污染或 DOMException），记录后继续
          console.warn('[DevHelper] drawImage 异常，跳过当前帧:', drawErr);
        }
        resolve();
      };
      img.onerror = resolve;
      img.src = capRes.dataUrl;
    });

    // 3.5 终止判断：已到达底部（由 content script 精确判断）
    if (isBottom) {
      break;
    }

    // 3.6 计算下一帧目标位置：以已绘高度为准（而非 actualY+viewportHeight），
    // 确保下一帧从画布衔接处精确对齐，防止动态增高页面出现空白或重叠
    currentScrollY = drawnHeight;
  }

  // 4. 恢复页面滚动状态
  await new Promise((resolve) => {
    chrome.tabs.sendMessage(sourceTabId, { action: 'restoreScroll' }, () => resolve());
  });
  if (myTabId) chrome.tabs.update(myTabId, { active: true });

  // 5. 裁剪 Canvas 到实际绘制高度，移除多余空白
  try {
    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = captureWidth * dpr;
    finalCanvas.height = drawnHeight * dpr;
    const finalCtx = finalCanvas.getContext('2d');
    if (!finalCtx) throw new Error('finalCanvas getContext returned null');
    finalCtx.drawImage(stitchCanvas, 0, 0);
    // toDataURL 在 canvas 被污染时会抛出 SecurityError
    const stitchedDataUrl = finalCanvas.toDataURL('image/png');
    processCaptureResult(stitchedDataUrl);
    showToast(`整页截图完成（共 ${frameCount} 帧）`, 'success');
  } catch (e) {
    console.error('[DevHelper] 生成最终图片失败:', e);
    // SecurityError 说明 canvas 被跨域资源污染，降级：直接用 stitchCanvas 原尺寸输出
    try {
      const fallbackUrl = stitchCanvas.toDataURL('image/png');
      processCaptureResult(fallbackUrl);
      showToast(`整页截图完成（共 ${frameCount} 帧，使用降级模式）`, 'success');
    } catch (fallbackErr) {
      showToast(`整页截图失败：${e.message || 'Canvas 导出异常'}`, 'error');
    }
  }
}

// ==================== 4. 屏幕捕获 (DisplayMedia) ====================
async function captureScreenStream() {
  currentCaptureType = 'local';
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: { displaySurface: "monitor" },
      audio: false
    });

    const video = document.createElement('video');
    video.autoplay = true;
    video.playsInline = true;
    video.srcObject = stream;

    video.onloadedmetadata = () => {
      // 给视频缓冲一下帧
      setTimeout(() => {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = video.videoWidth;
        tempCanvas.height = video.videoHeight;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        
        // 彻底停止流，释放摄像头/屏幕捕获
        stream.getTracks().forEach(track => track.stop());
        
        const dataUrl = tempCanvas.toDataURL('image/png');
        processCaptureResult(dataUrl);
      }, 500);
    };
  } catch (err) {
    console.error(err);
    showToast('屏幕捕获已取消或失败', 'error');
  }
}

// ==================== 5. 本地图片上传和粘贴 ====================
function handleFileSelect(e) {
  if (e.target.files.length > 0) {
    loadImageFile(e.target.files[0]);
  }
}

function loadImageFile(file) {
  currentCaptureType = 'local';
  if (!file.type.startsWith('image/')) {
    showToast('请选择有效的图片文件', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = (event) => {
    processCaptureResult(event.target.result);
  };
  reader.readAsDataURL(file);
}

// ==================== 统一加载截图到画布编辑器 ====================
function processCaptureResult(dataUrl) {
  const optStorage = document.getElementById('optStorage').value;

  if (optStorage === 'download') {
    // 直接保存
    const link = document.createElement('a');
    link.download = `DevHelper_Screenshot_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
    showToast('截图已直接保存到本地', 'success');
  } else if (optStorage === 'clipboard') {
    // 直接复制到剪贴板
    copyDataUrlToClipboard(dataUrl);
  } else {
    // 默认：打开标注编辑器
    initCanvasEditor(dataUrl);
  }
}

// 复制 Base64 到剪贴板
function copyDataUrlToClipboard(dataUrl) {
  fetch(dataUrl)
    .then(res => res.blob())
    .then(blob => {
      navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]).then(() => {
        showToast('已复制图片到剪贴板', 'success');
      }).catch(err => {
        console.error(err);
        showToast('复制图片到剪贴板失败，请重试', 'error');
      });
    });
}

// ==================== 6. Canvas 涂鸦标注核心编辑器 ====================
function initCanvasEditor(dataUrl) {
  // 隐藏控制面板，显示编辑器
  document.getElementById('controlPanel').style.display = 'none';
  document.getElementById('editorPanel').style.display = 'flex';

  bgImage = new Image();
  bgImage.onload = () => {
    // 设置 Canvas 大小等于图片的原始物理像素大小，避免模糊
    canvas.width = bgImage.width;
    canvas.height = bgImage.height;

    // 清空历史
    historyList = [];
    
    // 渲染背景
    drawAll();
    
    // 保存初始帧
    saveHistory();

    // 重置 AI 截图助理面板状态并保持收起
    const sidebar = document.getElementById('editorAiSidebar');
    if (sidebar) sidebar.classList.remove('active');
    
    const ocrText = document.getElementById('ocrTextResult');
    if (ocrText) ocrText.value = '';
    
    const responseBox = document.getElementById('aiResponseContainer');
    if (responseBox) responseBox.innerHTML = '<span class="placeholder">等待您触发分析...</span>';
  };
  bgImage.src = dataUrl;
}

// 渲染所有内容（背景 + 标注）
function drawAll() {
  if (!bgImage) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bgImage, 0, 0);
}

// 保存当前 Canvas 像素状态到撤销历史
function saveHistory() {
  if (historyList.length >= maxHistory) {
    historyList.shift();
  }
  historyList.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
}

// 绑定标注工具的事件
function setupEditorTools() {
  const toolBtns = {
    brush: document.getElementById('toolBrush'),
    rect: document.getElementById('toolRect'),
    arrow: document.getElementById('toolArrow'),
    text: document.getElementById('toolText'),
    mosaic: document.getElementById('toolMosaic')
  };

  // 绑定工具切换
  Object.keys(toolBtns).forEach(tool => {
    toolBtns[tool].addEventListener('click', () => {
      Object.keys(toolBtns).forEach(t => toolBtns[t].classList.remove('active'));
      toolBtns[tool].classList.add('active');
      currentTool = tool;
    });
  });

  // 绑定颜色切换
  const colorDots = document.querySelectorAll('.color-dot');
  colorDots.forEach(dot => {
    dot.addEventListener('click', () => {
      colorDots.forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      currentColor = dot.dataset.color;
      document.getElementById('customColorInput').value = currentColor;
    });
  });

  // 自定义颜色
  const customColorInput = document.getElementById('customColorInput');
  customColorInput.addEventListener('input', (e) => {
    currentColor = e.target.value;
    colorDots.forEach(d => d.classList.remove('active'));
  });

  // Canvas 绘图事件
  canvas.addEventListener('mousedown', onCanvasMouseDown);
  canvas.addEventListener('mousemove', onCanvasMouseMove);
  canvas.addEventListener('mouseup', onCanvasMouseUp);
  canvas.addEventListener('mouseleave', onCanvasMouseLeave);

  // 动作按钮
  document.getElementById('btnUndo').addEventListener('click', handleUndo);
  document.getElementById('btnClear').addEventListener('click', handleClear);
  document.getElementById('btnCopy').addEventListener('click', handleCopy);
  document.getElementById('btnSave').addEventListener('click', handleSave);
  document.getElementById('btnExit').addEventListener('click', handleExit);
  
  // OCR 识别按钮与 AI 侧边栏按钮绑定
  document.getElementById('btnOCR').addEventListener('click', handleOCR);
  document.getElementById('btnCloseSidebar').addEventListener('click', () => {
    document.getElementById('editorAiSidebar').classList.remove('active');
  });
  document.getElementById('btnCopyOcrText').addEventListener('click', handleCopyOcrText);
  document.getElementById('btnAiAnalyzeText').addEventListener('click', handleAiAnalyzeText);
  document.getElementById('btnVisionAnalyze').addEventListener('click', handleVisionAnalyze);
}

// 获取 Canvas 上的相对坐标
function getMousePos(e) {
  const rect = canvas.getBoundingClientRect();
  // 必须考虑到 Canvas 在 CSS 中的缩放比
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  return {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  };
}

let tempFrameData = null; // 用于拖拽时重绘

function onCanvasMouseDown(e) {
  if (e.button !== 0) return; // 仅左键
  isDrawing = true;
  const pos = getMousePos(e);
  startX = pos.x;
  startY = pos.y;
  lastX = pos.x;
  lastY = pos.y;

  // 记录下本次绘制前的画布像素数据，以便在拖动矩形/箭头时进行“重擦”
  tempFrameData = ctx.getImageData(0, 0, canvas.width, canvas.height);
}

function onCanvasMouseMove(e) {
  if (!isDrawing) return;
  const pos = getMousePos(e);

  if (currentTool === 'brush') {
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentLineWidth;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastX = pos.x;
    lastY = pos.y;
  } else if (currentTool === 'mosaic') {
    drawMosaicBrush(pos.x, pos.y);
  } else if (currentTool === 'rect') {
    // 恢复成那一帧
    ctx.putImageData(tempFrameData, 0, 0);
    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentLineWidth;
    ctx.strokeRect(startX, startY, pos.x - startX, pos.y - startY);
  } else if (currentTool === 'arrow') {
    ctx.putImageData(tempFrameData, 0, 0);
    drawArrow(startX, startY, pos.x, pos.y, currentColor, currentLineWidth);
  }
}

function onCanvasMouseUp(e) {
  if (!isDrawing) return;
  isDrawing = false;
  const pos = getMousePos(e);

  if (currentTool === 'text') {
    // 文字绘制：点击后创建一个浮动输入框，输入完成后画到 Canvas 上
    createCanvasTextInput(e.clientX, e.clientY, pos.x, pos.y);
  } else {
    // 普通涂鸦，在抬起时存入 history
    saveHistory();
  }
  tempFrameData = null;
}

function onCanvasMouseLeave() {
  if (isDrawing) {
    isDrawing = false;
    saveHistory();
    tempFrameData = null;
  }
}

// 绘制箭头辅助函数
function drawArrow(x1, y1, x2, y2, color, width) {
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = width;
  
  // 画主线段
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // 计算箭头的两只小翅膀偏角
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const headLength = 15 + width; // 长度随粗细缩放

  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fill();
}

// 绘制马赛克效果 (对小块像素模糊填充)
function drawMosaicBrush(x, y) {
  const size = 16;
  const halfSize = size / 2;
  
  // 越界保护
  const bx = Math.max(0, Math.min(canvas.width - size, x - halfSize));
  const by = Math.max(0, Math.min(canvas.height - size, y - halfSize));

  try {
    const imgData = ctx.getImageData(bx, by, size, size);
    const data = imgData.data;
    
    // 计算块内平均颜色
    let r = 0, g = 0, b = 0, a = 0;
    const len = data.length;
    for (let i = 0; i < len; i += 4) {
      r += data[i];
      g += data[i+1];
      b += data[i+2];
      a += data[i+3];
    }
    const count = len / 4;
    r = Math.floor(r / count);
    g = Math.floor(g / count);
    b = Math.floor(b / count);
    a = Math.floor(a / count);

    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
    ctx.fillRect(bx, by, size, size);
  } catch (err) {
    console.error(err);
  }
}

// 创建浮动的 Canvas 文字输入框
function createCanvasTextInput(clientX, clientY, canvasX, canvasY) {
  // 防重复
  if (document.querySelector('.canvas-text-input')) return;

  const container = document.getElementById('canvasContainer');
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'canvas-text-input';
  input.style.left = `${clientX - container.getBoundingClientRect().left + container.scrollLeft}px`;
  input.style.top = `${clientY - container.getBoundingClientRect().top + container.scrollTop}px`;
  input.style.color = currentColor;
  
  container.appendChild(input);
  input.focus();

  // 完成输入的辅助函数
  function commitText() {
    const text = input.value.trim();
    if (text) {
      ctx.fillStyle = currentColor;
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textBaseline = 'top';
      ctx.fillText(text, canvasX, canvasY);
      saveHistory();
    }
    input.remove();
  }

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      commitText();
    } else if (e.key === 'Escape') {
      input.remove();
    }
  });

  input.addEventListener('blur', commitText);
}

// 撤销
function handleUndo() {
  if (historyList.length > 1) {
    historyList.pop(); // 弹出当前这一帧
    const prevFrame = historyList[historyList.length - 1];
    ctx.putImageData(prevFrame, 0, 0);
  } else {
    showToast('没有更多可撤销的步骤了', 'info');
  }
}

// 清除所有
function handleClear() {
  if (confirm('确认清除所有已绘制的标注吗？')) {
    drawAll();
    saveHistory();
  }
}

// 复制图片
function handleCopy() {
  canvas.toBlob(blob => {
    if (!blob) {
      showToast('图片复制失败', 'error');
      return;
    }
    navigator.clipboard.write([
      new ClipboardItem({ 'image/png': blob })
    ]).then(() => {
      showToast('标注后的图片已复制到剪贴板', 'success');
    }).catch(err => {
      console.error(err);
      showToast('剪贴板写入失败，请检查浏览器权限', 'error');
    });
  });
}

// 保存到本地
function handleSave() {
  canvas.toBlob(blob => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `DevHelper_Screenshot_Annotated_${Date.now()}.png`;
    link.href = url;
    link.click();
    
    // 垃圾回收，释放内存
    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 100);
    showToast('图片保存成功', 'success');
  });
}

// 退出
function handleExit() {
  if (confirm('确认退出标注编辑器吗？当前未保存的标注将会丢失。')) {
    // 销毁背景图和 Canvas，释放内存占用
    bgImage = null;
    historyList = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    document.getElementById('editorPanel').style.display = 'none';
    document.getElementById('controlPanel').style.display = 'block';
  }
}

// ==================== 7. AI 截图助手处理逻辑 ====================

// 触发 OCR 提取文本
async function handleOCR() {
  const sidebar = document.getElementById('editorAiSidebar');
  sidebar.classList.add('active');

  const textResultArea = document.getElementById('ocrTextResult');

  // 1. 如果有来自 DOM 逆向提取的现成文本，优先使用
  if (currentExtractedText && currentExtractedText.trim()) {
    textResultArea.value = currentExtractedText.trim();
    showToast('已自动从当前框选的 DOM 节点中精准提取文本！', 'success');
    return;
  }

  // 1.5 如果是网页截图且没有框选文本，尝试从原网页 DOM 中提取对应范围的文本
  if (sourceTabId && (currentCaptureType === 'visible' || currentCaptureType === 'full' || currentCaptureType === 'area')) {
    showToast('正在从网页中自动提取文本，请稍候...', 'info');
    try {
      await injectHelperScript();
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(sourceTabId, { 
          action: 'extractDOMText', 
          type: currentCaptureType 
        }, (res) => {
          if (chrome.runtime.lastError || !res) {
            resolve(null);
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.status === 'success' && response.text && response.text.trim()) {
        textResultArea.value = response.text.trim();
        showToast('已自动从网页 DOM 中提取全部文本！', 'success');
        return;
      }
    } catch (e) {
      console.warn('DOM 文本提取失败，将使用 AI OCR:', e);
    }
  }

  // 2. 否则，使用大模型的多模态视觉 OCR 提取文本
  showToast('正在利用 AI 多模态分析提取图像文字，请稍候...', 'info');
  textResultArea.value = '正在利用 AI 提取图片文字...\n';
  
  try {
    const dataUrl = canvas.toDataURL('image/png');
    const systemPrompt = '你是一个高精度的图像文本提取 (OCR) 助手。';
    const userContent = [
      {
        type: 'text',
        text: '请仔细观察并识别出这张图片中所有的可见文本，原样输出识别到的文本内容，保持原有的换行和格式，不要有任何多余的解释、前言、回复或 Markdown 包裹，仅输出提取出的文字内容。'
      },
      {
        type: 'image_url',
        image_url: {
          url: dataUrl
        }
      }
    ];

    textResultArea.value = ''; // 清空提示
    
    const result = await DevHelperAI.callAI(systemPrompt, userContent, (chunk, reasoningText) => {
      // 推理模型思维链阶段（chunk 为空），显示思考中占位
      if (!chunk && reasoningText) {
        textResultArea.value = '🤔 AI 正在深度分析图片，请稍候...';
      } else if (chunk) {
        textResultArea.value = chunk;
      }
    });

    // 非流式响应或流式结束后 result 有值但 value 仍为占位文本时，直接使用 result
    if (result && (!textResultArea.value || textResultArea.value.startsWith('🤔'))) {
      textResultArea.value = result;
    }
    
    showToast('AI 文本识别完成！', 'success');
  } catch (err) {
    console.error('AI OCR 失败:', err);
    textResultArea.value = `AI 文字识别失败：${err.message}\n请检查您的 AI 设置（API Key 是否配置正确）。当前您仍可手动在文本框中编辑内容。`;
    showToast('AI 文字识别失败，请检查配置', 'error');
  }
}

// 复制 OCR 结果
function handleCopyOcrText() {
  const textVal = document.getElementById('ocrTextResult').value.trim();
  if (!textVal) {
    showToast('没有可复制的内容', 'info');
    return;
  }
  navigator.clipboard.writeText(textVal)
    .then(() => showToast('已成功复制到剪贴板！', 'success'))
    .catch(() => showToast('复制失败，请手动选择复制', 'error'));
}

// AI 一键分析提取出来的文本
async function handleAiAnalyzeText() {
  const textVal = document.getElementById('ocrTextResult').value.trim();
  if (!textVal) {
    showToast('请先进行文本提取或在文本框中输入内容', 'warning');
    return;
  }

  const responseContainer = document.getElementById('aiResponseContainer');
  responseContainer.innerHTML = '<div class="ai-loading-dots"><span></span><span></span><span></span></div> 正在深入分析文本...';

  try {
    const systemPrompt = '你是一个专业的全栈软件开发专家和 UI 设计师。';
    const userPrompt = `请分析以下这段提取自系统截图的文本内容，指出其中可能存在的逻辑漏洞、错误日志、UI 文本缺陷，或者根据内容提供相应的代码改进方案：\n\n${textVal}`;
    
    let answerText = '';
    const result = await DevHelperAI.callAI(systemPrompt, userPrompt, (chunk, reasoningText) => {
      if (!chunk && reasoningText) {
        // 推理模型思维链阶段：显示进度提示，告知用户 AI 正在推理
        responseContainer.innerHTML = `<div class="ai-loading-dots"><span></span><span></span><span></span></div>&nbsp;<span style="font-size:11px;color:var(--text-tertiary)">正在深度思考中... (${reasoningText.length} 字)</span>`;
      } else if (chunk) {
        answerText = chunk;
        responseContainer.innerHTML = formatMarkdown(answerText);
      }
      responseContainer.scrollTop = responseContainer.scrollHeight;
    });
    if (result && !answerText) {
      answerText = result;
      responseContainer.innerHTML = formatMarkdown(answerText);
      responseContainer.scrollTop = responseContainer.scrollHeight;
    }
  } catch (err) {
    console.error('AI 文本分析失败:', err);
    responseContainer.innerHTML = `<span style="color: var(--danger);">分析失败：${err.message}</span>`;
  }
}

// AI 原生多模态视觉分析
async function handleVisionAnalyze() {
  const responseContainer = document.getElementById('aiResponseContainer');
  responseContainer.innerHTML = '<div class="ai-loading-dots"><span></span><span></span><span></span></div> 正在传输并多模态解析图片...';

  // 打开侧边栏
  document.getElementById('editorAiSidebar').classList.add('active');

  try {
    const dataUrl = canvas.toDataURL('image/png');
    const systemPrompt = '你是一个资深的前端开发专家、UI 缺陷检测专家和软件测试工程师。';
    const userContent = [
      {
        type: 'text',
        text: '这是当前系统的网页截图（可能包含用户的红色框线圈出或画笔标注）。请仔细审查这张图片，指出页面上的任何 UI/UX 缺陷（如排版对齐错误、文字截断重叠、色彩反差低等）、敏感情报泄泄密或可能出现的软件报错，并给出修改代码或优化的具体建议。请以清晰的 Markdown 结构展示。'
      },
      {
        type: 'image_url',
        image_url: {
          url: dataUrl
        }
      }
    ];

    let answerText = '';
    const result = await DevHelperAI.callAI(systemPrompt, userContent, (chunk, reasoningText) => {
      if (!chunk && reasoningText) {
        // 推理模型思维链阶段：显示推理进度，避免 loading 卡死
        responseContainer.innerHTML = `<div class="ai-loading-dots"><span></span><span></span><span></span></div>&nbsp;<span style="font-size:11px;color:var(--text-tertiary)">正在深度分析截图... (${reasoningText.length} 字)</span>`;
      } else if (chunk) {
        answerText = chunk;
        responseContainer.innerHTML = formatMarkdown(answerText);
      }
      responseContainer.scrollTop = responseContainer.scrollHeight;
    });
    if (result && !answerText) {
      answerText = result;
      responseContainer.innerHTML = formatMarkdown(answerText);
      responseContainer.scrollTop = responseContainer.scrollHeight;
    }
  } catch (err) {
    console.error('多模态分析失败:', err);
    responseContainer.innerHTML = `<span style="color: var(--danger);">多模态分析失败：${err.message}。请确保您配置的 AI 提供商和模型支持多模态（如 gpt-4o-mini 或 gemini-1.5-pro）。</span>`;
  }
}


// Markdown 渲染器（截图 AI 侧边栏专用）
// 支持：代码块、内联代码、标题(#/##/###)、有序/无序列表、表格、分隔线、加粗、斜体
function formatMarkdown(text) {
  if (!text) return '';

  function escHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // 1. 优先提取代码块，替换为占位符，防止内容被后续规则污染
  const codeBlocks = [];
  let result = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const idx = codeBlocks.length;
    codeBlocks.push(
      `<pre style="background:rgba(0,0,0,0.08);border:1px solid var(--border-light);border-radius:6px;padding:10px 12px;font-size:11px;overflow-x:auto;margin:8px 0;white-space:pre-wrap;word-break:break-all;"><code class="lang-${escHtml(lang)}">${escHtml(code.trim())}</code></pre>`
    );
    return `\x00CODE_BLOCK_${idx}\x00`;
  });

  // 2. 转义普通文本中的 HTML 特殊字符（代码块已提取，不会被转义）
  result = escHtml(result);

  // 3. 还原代码块占位符（escHtml 会把 \x00 中的内容原样保留，这里重新插入真实 HTML）
  result = result.replace(/\x00CODE_BLOCK_(\d+)\x00/g, (_, i) => codeBlocks[parseInt(i)]);

  // 4. 表格（| header | ... | 格式）
  result = result.replace(/(\|.+\|\n\|[-: |]+\|\n(?:\|.+\|\n?)+)/g, (table) => {
    const rows = table.trim().split('\n');
    const headers = rows[0].split('|').filter(c => c.trim())
      .map(c => `<th style="padding:5px 10px;border:1px solid var(--border-light);background:var(--bg-elevated);">${c.trim()}</th>`).join('');
    const body = rows.slice(2).map(row => {
      const cells = row.split('|').filter(c => c.trim())
        .map(c => `<td style="padding:5px 10px;border:1px solid var(--border-light);">${c.trim()}</td>`).join('');
      return `<tr>${cells}</tr>`;
    }).join('');
    return `<table style="border-collapse:collapse;width:100%;margin:8px 0;font-size:11px;"><thead><tr>${headers}</tr></thead><tbody>${body}</tbody></table>`;
  });

  // 5. 标题 (### / ## / #)
  result = result
    .replace(/^### (.+)$/gm, '<h4 style="margin:10px 0 6px;color:var(--primary);font-size:13px;">$1</h4>')
    .replace(/^## (.+)$/gm, '<h3 style="margin:12px 0 8px;color:var(--primary);font-size:14px;">$1</h3>')
    .replace(/^# (.+)$/gm, '<h2 style="margin:14px 0 10px;color:var(--primary);font-size:15px;">$1</h2>');

  // 6. 有序列表（连续 1. 2. 3. 块）
  result = result.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n')
      .map(l => `<li style="margin-bottom:4px;">${l.replace(/^\d+\. /, '')}</li>`).join('');
    return `<ol style="padding-left:20px;margin:6px 0;">${items}</ol>`;
  });

  // 7. 无序列表（连续 - / * 块）
  result = result.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n')
      .map(l => `<li style="margin-bottom:4px;">${l.replace(/^[-*] /, '')}</li>`).join('');
    return `<ul style="padding-left:20px;margin:6px 0;">${items}</ul>`;
  });

  // 8. 内联格式（加粗、斜体、行内代码、删除线）
  result = result
    .replace(/`([^`]+)`/g, '<code style="background:rgba(0,0,0,0.08);padding:1px 4px;border-radius:3px;font-size:11px;">$1</code>')
    .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/~~(.+?)~~/g, '<del>$1</del>');

  // 9. 分隔线
  result = result.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid var(--border-light);margin:10px 0;">');

  // 10. 换行（HTML 标签前后的换行不重复转换）
  result = result.replace(/\n(?!<)/g, '<br>');

  return result;
}
