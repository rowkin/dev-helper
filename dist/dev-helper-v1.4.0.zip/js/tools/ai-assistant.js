/**
 * AI 助手页面逻辑
 * 提取自 pages/ai-assistant.html，符合 Chrome MV3 CSP 要求
 * 功能：多会话管理、流式输出、Markdown 渲染、快捷提示、历史记录
 */

// 等待 DOM 和所有依赖脚本加载完毕再执行
document.addEventListener('DOMContentLoaded', () => {
  // 初始化主题（由 common.js 提供）
  if (typeof initTheme === 'function') initTheme();

  const SYSTEM_PROMPT = `你是 DevHelper AI，七九在线科技的专属技术助手。
你擅长：前端开发（Vue/React/JavaScript/CSS）、后端开发、API 调试、代码审查、性能优化、数据库查询等。
回答要求：
1. 优先给出可直接使用的代码示例
2. 代码块使用 Markdown 代码格式（\`\`\`language ... \`\`\`）
3. 回答简洁准确，重点突出
4. 如果遇到模糊问题，先理解再给出最优答案
5. 请务必使用简体中文进行回答，若有英文术语或原代码，进行翻译或提供双语对照形式展示。`;

  let messages = [];      // 当前会话消息历史
  let conversations = []; // 所有会话列表
  let currentConvId = null;
  let isGenerating = false;

  // ─── 历史记录管理 ─────────────────────────────────────────────

  async function loadHistory() {
    const data = await chrome.storage.local.get(['aiConversations']);
    conversations = data.aiConversations || [];
    renderHistory();
    // 如果没有历史会话则开启新对话
    if (!conversations.length) {
      startNewChat();
    } else {
      // 加载最近一条会话
      loadConversation(conversations[conversations.length - 1].id);
    }
  }

  function renderHistory() {
    const list = document.getElementById('historyList');
    list.innerHTML = '';
    conversations.slice().reverse().forEach(conv => {
      const item = document.createElement('div');
      item.className = 'history-item' + (conv.id === currentConvId ? ' active' : '');
      item.textContent = conv.title || '新对话';
      item.addEventListener('click', () => loadConversation(conv.id));
      list.appendChild(item);
    });
  }

  function startNewChat() {
    const id = Date.now().toString();
    const conv = { id, title: '新对话', messages: [], createdAt: Date.now() };
    conversations.push(conv);
    currentConvId = id;
    messages = [];

    const container = document.getElementById('chatMessages');
    container.innerHTML = '';

    // 恢复欢迎屏
    const welcome = createWelcomeScreen();
    container.appendChild(welcome);

    renderHistory();
    saveConversations();
  }

  function loadConversation(id) {
    const conv = conversations.find(c => c.id === id);
    if (!conv) return;
    currentConvId = id;
    messages = conv.messages || [];

    const container = document.getElementById('chatMessages');
    container.innerHTML = '';

    if (messages.length === 0) {
      container.appendChild(createWelcomeScreen());
    } else {
      messages.forEach(m => appendMessage(m.role, m.content, false));
    }
    renderHistory();
  }

  async function saveConversations() {
    const conv = conversations.find(c => c.id === currentConvId);
    if (conv) {
      conv.messages = messages;
      // 用第一条用户消息前 30 字作为会话标题
      if (messages.length > 0 && conv.title === '新对话') {
        const firstUserMsg = messages.find(m => m.role === 'user');
        if (firstUserMsg) conv.title = firstUserMsg.content.slice(0, 30) + (firstUserMsg.content.length > 30 ? '...' : '');
      }
    }
    await chrome.storage.local.set({ aiConversations: conversations.slice(-20) });
  }

  // ─── 欢迎屏 ───────────────────────────────────────────────────

  function createWelcomeScreen() {
    const div = document.createElement('div');
    div.className = 'welcome-screen';
    div.id = 'welcomeScreen';
    div.innerHTML = `
      <svg class="welcome-logo" viewBox="0 0 56 56" fill="none">
        <rect width="56" height="56" rx="16" fill="url(#wg2)"/>
        <path d="M14 22L22 30L14 38M26 38H42" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
        <defs><linearGradient id="wg2" x1="0" y1="0" x2="56" y2="56" gradientUnits="userSpaceOnUse"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs>
      </svg>
      <div class="welcome-title">DevHelper AI 助手</div>
      <div class="welcome-desc">你好！我是你的专属 AI 助手，不管是查 BUG、写代码，还是咨询技术问题，都可以问我。</div>
      <div class="welcome-cards">
        <div class="welcome-card" data-q="用 JS 写一个防抖函数的 Demo"><div class="welcome-card-icon">⚡</div><div class="welcome-card-title">写一个防抖 Demo</div><div class="welcome-card-desc">JavaScript 代码示例</div></div>
        <div class="welcome-card" data-q="JS 里的 Fetch API 怎么用"><div class="welcome-card-icon">🌐</div><div class="welcome-card-title">Fetch API 使用</div><div class="welcome-card-desc">网络请求最佳实践</div></div>
        <div class="welcome-card" data-q="帮我写一个单网页版的俄罗斯方块游戏（HTML+CSS+JS）"><div class="welcome-card-icon">🎮</div><div class="welcome-card-title">写一个小游戏</div><div class="welcome-card-desc">HTML + CSS + JS 实现</div></div>
        <div class="welcome-card" data-q="解释 Vue 3 的响应式原理 Proxy vs Object.defineProperty"><div class="welcome-card-icon">🔍</div><div class="welcome-card-title">Vue 3 响应式原理</div><div class="welcome-card-desc">Proxy vs defineProperty</div></div>
      </div>`;

    // 绑定欢迎卡片的点击事件（避免内联 onclick）
    div.querySelectorAll('[data-q]').forEach(card => {
      card.addEventListener('click', () => {
        document.getElementById('msgInput').value = card.dataset.q;
        sendMessage();
      });
    });
    return div;
  }

  // ─── 发送消息 ──────────────────────────────────────────────────

  async function sendMessage() {
    const msgInput = document.getElementById('msgInput');
    const text = msgInput.value.trim();
    if (!text || isGenerating) return;

    // 隐藏欢迎屏
    document.getElementById('welcomeScreen')?.remove();

    msgInput.value = '';
    msgInput.style.height = '24px';

    appendMessage('user', text);
    messages.push({ role: 'user', content: text });

    isGenerating = true;
    document.getElementById('btnSend').disabled = true;

    const thinkEl = appendThinking();

    let aiBubble = null;
    try {
      // 构建带历史上下文的提示，最多取最近 10 条
      const historyCtx = messages.slice(-10).map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`).join('\n');
      const prompt = messages.length > 1
        ? `对话历史:\n${historyCtx}\n\n请回答最后一条用户问题`
        : text;

      let fullReply = '';
      aiBubble = document.createElement('div');
      aiBubble.className = 'msg assistant';
      aiBubble.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble"></div>`;
      const bubbleContent = aiBubble.querySelector('.msg-bubble');

      const result = await DevHelperAI.callAI(SYSTEM_PROMPT, prompt, (chunk, reasoningText) => {
        if (thinkEl && thinkEl.parentNode) {
          thinkEl.remove();
        }
        if (!aiBubble.parentNode) {
          document.getElementById('chatMessages').appendChild(aiBubble);
        }

        // chunk 为空说明当前处于推理模型的思维链阶段（reasoning_content）
        // 显示一个"正在深度思考"的占位状态，等待最终答案（content）到来
        if (!chunk && reasoningText) {
          bubbleContent.innerHTML = `<div class="thinking-dots"><span></span><span></span><span></span></div><span style="font-size:12px;color:var(--text-tertiary);margin-left:6px">正在深度思考中...</span>`;
        } else if (chunk) {
          fullReply = chunk;
          if (bubbleContent) {
            bubbleContent.innerHTML = renderMarkdown(chunk);
          }
        }
        scrollToBottom();
      });

      // callAI 完成后统一处理：确保 thinkEl 和 aiBubble 状态正确
      // 若 onChunk 从未被调用（非流式响应/SSE 解析失败），需手动 append 气泡并渲染内容
      if (thinkEl && thinkEl.parentNode) {
        thinkEl.remove();
      }
      if (!aiBubble.parentNode) {
        document.getElementById('chatMessages').appendChild(aiBubble);
      }
      if (!fullReply && result) {
        fullReply = result;
        bubbleContent.innerHTML = renderMarkdown(fullReply);
        scrollToBottom();
      }

      messages.push({ role: 'assistant', content: fullReply });
      await saveConversations();
      renderHistory();
    } catch (err) {
      if (thinkEl && thinkEl.parentNode) {
        thinkEl.remove();
      }
      // 如果气泡已添加到页面，直接在里面显示错误
      if (aiBubble && aiBubble.parentNode) {
        const bContent = aiBubble.querySelector('.msg-bubble');
        if (bContent) {
          bContent.innerHTML = `<span style="color:var(--error);font-weight:600">❌ AI 调用失败：${err.message}</span>\n\n请点击右上角「AI 设置」配置 API Key。`;
        }
      } else {
        appendMessage('assistant', `❌ AI 调用失败：${err.message}\n\n请点击右上角「AI 设置」配置 API Key。`);
      }
    } finally {
      isGenerating = false;
      document.getElementById('btnSend').disabled = false;
    }
  }

  // ─── DOM 工具函数 ──────────────────────────────────────────────

  function appendMessage(role, content, scroll = true) {
    const container = document.getElementById('chatMessages');
    const el = document.createElement('div');
    el.className = `msg ${role}`;
    const avatar = role === 'user' ? '👤' : '🤖';
    el.innerHTML = `<div class="msg-avatar">${avatar}</div><div class="msg-bubble">${renderMarkdown(content)}</div>`;
    container.appendChild(el);
    if (scroll) scrollToBottom();
    return el;
  }

  function appendThinking() {
    const container = document.getElementById('chatMessages');
    const el = document.createElement('div');
    el.className = 'msg assistant';
    el.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble"><div class="thinking-dots"><span></span><span></span><span></span></div></div>`;
    container.appendChild(el);
    scrollToBottom();
    return el;
  }

  function scrollToBottom() {
    const c = document.getElementById('chatMessages');
    c.scrollTop = c.scrollHeight;
  }

  // ─── Markdown 渲染 ─────────────────────────────────────────────
  // 轻量级渲染器，支持：代码块、内联代码、粗/斜体、标题、有序列表、无序列表、表格、分隔线

  function renderMarkdown(text) {
    if (!text) return '';

    // 转义 HTML（避免 XSS）
    function escHtml(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // 1. 代码块（优先处理，防止其内容被后续规则污染）
    let result = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
      `<pre class="md-pre"><code class="lang-${lang}">${escHtml(code.trim())}</code></pre>`);

    // 2. 表格（简单支持）
    result = result.replace(/(\|.+\|\n\|[-: |]+\|\n(?:\|.+\|\n?)+)/g, (table) => {
      const rows = table.trim().split('\n');
      const headers = rows[0].split('|').filter(c => c.trim()).map(c => `<th>${escHtml(c.trim())}</th>`).join('');
      const body = rows.slice(2).map(row => {
        const cells = row.split('|').filter(c => c.trim()).map(c => `<td>${escHtml(c.trim())}</td>`).join('');
        return `<tr>${cells}</tr>`;
      }).join('');
      return `<table class="md-table"><thead><tr>${headers}</tr></thead><tbody>${body}</tbody></table>`;
    });

    // 3. 标题
    result = result
      .replace(/^### (.+)$/gm, '<h3 class="md-h3">$1</h3>')
      .replace(/^## (.+)$/gm, '<h2 class="md-h2">$1</h2>')
      .replace(/^# (.+)$/gm, '<h1 class="md-h1">$1</h1>');

    // 4. 有序列表
    result = result.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li>${l.replace(/^\d+\. /, '')}</li>`).join('');
      return `<ol class="md-ol">${items}</ol>`;
    });

    // 5. 无序列表
    result = result.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li>${l.replace(/^[-*] /, '')}</li>`).join('');
      return `<ul class="md-ul">${items}</ul>`;
    });

    // 6. 内联格式
    result = result
      .replace(/`([^`]+)`/g, '<code class="md-code">$1</code>')
      .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/~~(.+?)~~/g, '<del>$1</del>');

    // 7. 分隔线
    result = result.replace(/^---$/gm, '<hr class="md-hr">');

    // 8. 换行（非 HTML 标签前面的换行）
    result = result.replace(/\n(?!<)/g, '<br>');

    return result;
  }

  // ─── 事件绑定 ──────────────────────────────────────────────────

  const msgInput = document.getElementById('msgInput');

  // 自动调整输入框高度
  msgInput.addEventListener('input', () => {
    if (!msgInput.value) {
      msgInput.style.height = '24px';
    } else {
      msgInput.style.height = 'auto';
      msgInput.style.height = Math.min(200, msgInput.scrollHeight) + 'px';
    }
  });

  // Enter 发送，Shift+Enter 换行
  msgInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  document.getElementById('btnSend').addEventListener('click', sendMessage);
  document.getElementById('btnNewChat').addEventListener('click', startNewChat);
  document.getElementById('btnClearChat').addEventListener('click', () => {
    messages = [];
    const container = document.getElementById('chatMessages');
    container.innerHTML = '';
    container.appendChild(createWelcomeScreen());
    saveConversations();
  });

  // AI 设置按钮（showAISettingsModal 由 common.js 提供）
  document.getElementById('btnSettings').addEventListener('click', () => {
    if (typeof showAISettingsModal === 'function') showAISettingsModal();
  });

  // 侧边栏快捷提示按钮
  document.querySelectorAll('.quick-prompt').forEach(btn => {
    btn.addEventListener('click', () => {
      msgInput.value = btn.dataset.q;
      sendMessage();
    });
  });

  // 侧边栏返回全景导航页
  const sidebarBrand = document.getElementById('sidebarBrand');
  if (sidebarBrand) {
    sidebarBrand.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.tabs.create({ url: chrome.runtime.getURL('pages/index.html') });
      }
    });
  }

  // ─── 初始化 ────────────────────────────────────────────────────
  loadHistory();
});
