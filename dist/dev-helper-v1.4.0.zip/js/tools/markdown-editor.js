/**
 * DevHelper - Markdown 编辑器工具逻辑
 * 功能：实时渲染、Mermaid 图表、工具栏操作、文件导入导出、拖拽调整分栏比例
 */

/* ─── 初始化 Marked（Markdown 解析引擎）─────────────────── */

// 初始化 highlight.js 代码高亮
if (typeof hljs !== 'undefined') {
  marked.setOptions({
    highlight: (code, lang) => {
      const language = hljs.getLanguage(lang) ? lang : 'plaintext';
      return hljs.highlight(code, { language }).value;
    },
    langPrefix: 'hljs language-',
    breaks: true,
    gfm: true,
  });
} else {
  marked.setOptions({ breaks: true, gfm: true });
}

/* ─── Mermaid 动态按需加载（CSP 兼容策略）────────────────── */

let mermaidReady = false;
let mermaidLoading = false;

/**
 * 确保 Mermaid 库已被加载。
 * 只有在解析到 Mermaid 代码块时，才会动态将 js/lib/mermaid.min.js 插入页面，提升首屏响应速度。
 */
function ensureMermaidLoaded() {
  return new Promise((resolve, reject) => {
    if (mermaidReady) {
      resolve();
      return;
    }
    if (mermaidLoading) {
      // 若已有其他渲染任务在触发加载，等待其加载完毕
      const checkTimer = setInterval(() => {
        if (mermaidReady) {
          clearInterval(checkTimer);
          resolve();
        }
      }, 50);
      return;
    }

    mermaidLoading = true;
    const script = document.createElement('script');
    script.src = '../js/lib/mermaid.min.js';
    script.onload = () => {
      initMermaid();
      resolve();
    };
    script.onerror = (err) => {
      mermaidLoading = false;
      console.error('[DevHelper MD] 动态加载 Mermaid 库失败：', err);
      reject(new Error('无法下载或解析 Mermaid 库'));
    };
    document.body.appendChild(script);
  });
}

function initMermaid() {
  window.mermaid.initialize({
    startOnLoad: false,
    theme: document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'default',
    fontFamily: 'Inter, sans-serif',
    securityLevel: 'loose',
  });
  mermaidReady = true;
  document.getElementById('statMermaid').textContent = '✦ Mermaid 已就绪';
  // 触发已有内容的重新渲染
  scheduleRender();
}

/* ─── 状态变量 ─────────────────────────────────────────── */

// 防抖渲染计时器 ID
let renderTimer = null;

// 当前视图模式
let currentView = 'split';

// 历史记录（撤销/重做）
const MAX_HISTORY = 50;
let history = [];
let historyIndex = -1;
let isFromHistory = false;

// 拖拽分栏状态
let isDragging = false;
let dragStartX = 0;
let dragStartEditorWidth = 0;
let savedEditorWidth = null;

// 滚动同步活跃源 (editor / preview)
let activeScrollSource = null;



/* ─── DOM 引用 ─────────────────────────────────────────── */

const mdInput    = document.getElementById('mdInput');
const mdPreview  = document.getElementById('mdPreview');
const emptyHint  = document.getElementById('emptyHint');
const editorPane = document.getElementById('editorPane');
const previewPane= document.getElementById('previewPane');
const editorWrap = document.getElementById('editorWrap');
const lineCounter= document.getElementById('lineCounter');

/* ─── 渲染逻辑 ─────────────────────────────────────────── */

/**
 * 调度防抖渲染（用户停止输入 120ms 后触发）。
 * 避免频繁操作 DOM 造成性能劣化。
 */
function scheduleRender() {
  clearTimeout(renderTimer);
  renderTimer = setTimeout(doRender, 120);
}

/**
 * 主渲染函数：将 Markdown 转换为 HTML，然后处理 Mermaid 代码块。
 */
async function doRender() {
  const raw = mdInput.value;

  if (!raw.trim()) {
    mdPreview.innerHTML = '';
    emptyHint && mdPreview.appendChild(emptyHint);
    emptyHint.style.display = 'flex';
    updateStats(raw);
    updateLineCounter();
    return;
  }

  // 隐藏空提示
  if (emptyHint) emptyHint.style.display = 'none';

  // Mermaid 代码块预处理：替换为 <div class="mermaid-placeholder"> 以便后续渲染
  let processedRaw = raw;
  const mermaidBlocks = [];

  // 无论当前 mermaidReady 状态如何，都检测并生成占位符，以便之后进行按需加载渲染
  processedRaw = raw.replace(/```mermaid\n([\s\S]*?)```/g, (_, code) => {
    const idx = mermaidBlocks.length;
    mermaidBlocks.push(code.trim());
    return `<div class="mermaid-placeholder" data-idx="${idx}"></div>`;
  });

  // 解析 Markdown
  let html;
  try {
    html = marked.parse(processedRaw);
  } catch (e) {
    html = `<pre style="color:var(--danger)">${escapeHtml(e.message)}</pre>`;
  }

  // 保留滚动位置
  const prevScrollTop = mdPreview.scrollTop;
  mdPreview.innerHTML = html;

  // 渲染 Mermaid 占位块
  if (mermaidBlocks.length > 0) {
    if (mermaidReady) {
      await renderMermaidBlocks(mermaidBlocks);
    } else {
      // 引擎未就绪时，先展示加载中提示
      const placeholders = mdPreview.querySelectorAll('.mermaid-placeholder');
      placeholders.forEach(el => {
        el.innerHTML = `<div style="padding: 12px; background: var(--bg-elevated); border: 1px solid var(--border-light); border-radius: var(--radius-md); font-size: 12px; color: var(--text-tertiary);">⏳ 正在加载 Mermaid 渲染引擎...</div>`;
      });

      try {
        await ensureMermaidLoaded();
        await renderMermaidBlocks(mermaidBlocks);
      } catch (err) {
        placeholders.forEach(el => {
          el.innerHTML = `<div class="mermaid-error">⚠️ 无法加载 Mermaid 渲染引擎：${escapeHtml(err.message || String(err))}</div>`;
        });
      }
    }
  }

  mdPreview.scrollTop = prevScrollTop;
  updateStats(raw);
  updateLineCounter();
}

/**
 * 渲染预览区中所有 Mermaid 占位符。
 */
async function renderMermaidBlocks(blocks) {
  const placeholders = mdPreview.querySelectorAll('.mermaid-placeholder');
  for (const el of placeholders) {
    const idx = parseInt(el.dataset.idx, 10);
    const code = blocks[idx];
    if (code === undefined) continue;

    const wrap = document.createElement('div');
    wrap.className = 'mermaid-wrap';

    try {
      const uniqueId = `mermaid-${Date.now()}-${idx}`;
      const { svg } = await window.mermaid.render(uniqueId, code);
      wrap.innerHTML = svg;
    } catch (err) {
      wrap.innerHTML = `<div class="mermaid-error">⚠️ Mermaid 解析错误：\n${escapeHtml(err.message || String(err))}</div>`;
    }

    el.replaceWith(wrap);
  }
}

/* ─── 行号 & 状态栏更新 ────────────────────────────────── */

function updateLineCounter() {
  const lines = mdInput.value.split('\n').length;
  let html = '';
  for (let i = 1; i <= lines; i++) {
    html += `<span>${i}</span>`;
  }
  lineCounter.innerHTML = html;
  // 同步行号滚动
  lineCounter.scrollTop = mdInput.scrollTop;
}

function updateStats(text) {
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const lines = text.split('\n').length;
  const readMin = Math.max(1, Math.round(words / 200));

  document.getElementById('statWords').textContent = `字数 ${words}`;
  document.getElementById('statChars').textContent = `字符 ${chars}`;
  document.getElementById('statLines').textContent = `行数 ${lines}`;
  document.getElementById('statReadTime').textContent = `阅读时长 ~${readMin} 分钟`;
}

function updateCursorPos() {
  const textarea = mdInput;
  const val = textarea.value;
  const pos = textarea.selectionStart;
  const lines = val.substring(0, pos).split('\n');
  const line = lines.length;
  const col = lines[lines.length - 1].length + 1;
  document.getElementById('cursorPos').textContent = `行 ${line}，列 ${col}`;
}

/* ─── 工具栏操作 ───────────────────────────────────────── */

/**
 * 在光标位置插入或包裹文本。
 * @param {string} before 插入到选区之前的标记
 * @param {string} after  插入到选区之后的标记
 * @param {string} placeholder 无选区时的占位文字
 */
function wrapText(before, after = '', placeholder = '') {
  const start = mdInput.selectionStart;
  const end = mdInput.selectionEnd;
  const selectedText = mdInput.value.substring(start, end) || placeholder;
  const newText = before + selectedText + after;

  mdInput.setRangeText(newText, start, end, 'select');
  // 重新选中插入的核心文字
  if (!mdInput.value.substring(start, end)) {
    mdInput.selectionStart = start + before.length;
    mdInput.selectionEnd = start + before.length + selectedText.length;
  } else {
    mdInput.selectionStart = start + before.length;
    mdInput.selectionEnd = start + before.length + selectedText.length;
  }
  mdInput.focus();
  scheduleRender();
}

/**
 * 在当前行首插入前缀（适合标题、列表等行级操作）。
 */
function prefixLine(prefix) {
  const start = mdInput.selectionStart;
  const val = mdInput.value;
  const lineStart = val.lastIndexOf('\n', start - 1) + 1;
  const lineEnd = val.indexOf('\n', start);
  const end = lineEnd === -1 ? val.length : lineEnd;
  const line = val.substring(lineStart, end);

  // 如已有相同前缀则移除（切换效果）
  if (line.startsWith(prefix)) {
    mdInput.setRangeText(line.substring(prefix.length), lineStart, end, 'preserve');
  } else {
    mdInput.setRangeText(prefix + line, lineStart, end, 'preserve');
  }
  mdInput.focus();
  scheduleRender();
}

/**
 * 在光标处插入代码块。
 */
function insertBlock(template) {
  const start = mdInput.selectionStart;
  mdInput.setRangeText(template, start, start, 'end');
  mdInput.focus();
  scheduleRender();
}

/* ─── 历史记录（简易撤销/重做）─────────────────────────── */

function saveHistory(value) {
  if (isFromHistory) return;
  // 如果当前不是历史末尾，截断后续历史
  history = history.slice(0, historyIndex + 1);
  history.push(value);
  if (history.length > MAX_HISTORY) history.shift();
  historyIndex = history.length - 1;
}

/* ─── 视图切换 ─────────────────────────────────────────── */

function setView(view) {
  currentView = view;

  // 更新按钮活跃态
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });

  switch (view) {
    case 'split':
      // 恢复之前的拖拽宽度，如果未拖拽过则清空行内样式，走 CSS 均分
      if (savedEditorWidth) {
        const totalWidth = document.getElementById('mdMain').getBoundingClientRect().width;
        const newPreviewWidth = Math.max(200, totalWidth - savedEditorWidth - 4);
        editorPane.style.flex = 'none';
        editorPane.style.width = savedEditorWidth + 'px';
        previewPane.style.flex = 'none';
        previewPane.style.width = newPreviewWidth + 'px';
      } else {
        editorPane.style.flex = '';
        editorPane.style.width = '';
        previewPane.style.flex = '';
        previewPane.style.width = '';
      }
      editorPane.classList.remove('hidden');
      previewPane.classList.remove('hidden');
      document.getElementById('mdResizer').style.display = '';
      break;
    case 'editor':
      // 编辑器模式：完全铺满，隐藏预览区，清空行内样式以防拖拽影响
      editorPane.style.flex = '';
      editorPane.style.width = '';
      editorPane.classList.remove('hidden');
      previewPane.classList.add('hidden');
      document.getElementById('mdResizer').style.display = 'none';
      break;
    case 'preview':
      // 预览模式：完全铺满，隐藏编辑器，清空行内样式以防拖拽影响
      previewPane.style.flex = '';
      previewPane.style.width = '';
      editorPane.classList.add('hidden');
      previewPane.classList.remove('hidden');
      document.getElementById('mdResizer').style.display = 'none';
      doRender();
      break;
  }
}

/* ─── 拖拽调整分栏宽度 ──────────────────────────────────── */

function initResizer() {
  const resizer = document.getElementById('mdResizer');
  const main = document.getElementById('mdMain');

  resizer.addEventListener('mousedown', e => {
    isDragging = true;
    dragStartX = e.clientX;
    dragStartEditorWidth = editorPane.getBoundingClientRect().width;
    resizer.classList.add('dragging');
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  });

  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartX;
    const totalWidth = main.getBoundingClientRect().width;
    const newEditorWidth = Math.max(200, Math.min(totalWidth - 200, dragStartEditorWidth + dx));
    const newPreviewWidth = totalWidth - newEditorWidth - 4; // 4px for resizer
    editorPane.style.flex = 'none';
    editorPane.style.width = newEditorWidth + 'px';
    previewPane.style.flex = 'none';
    previewPane.style.width = newPreviewWidth + 'px';
    // 保存用户的拖动宽度
    savedEditorWidth = newEditorWidth;
  });

  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      resizer.classList.remove('dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });
}

/* ─── 文件导入导出 ─────────────────────────────────────── */

function importMarkdown() {
  document.getElementById('fileImport').click();
}

function exportMarkdown() {
  const content = mdInput.value;
  if (!content.trim()) {
    showToast('内容为空，无法导出', 'error');
    return;
  }

  // 默认导出的文件名为 document
  let fileName = 'document';

  // 尝试匹配文章中第一个 Markdown 一级标题（例如: "# 标题内容"）
  const match = content.match(/^#\s+(.+)$/m);
  if (match && match[1]) {
    // 过滤掉文件名中不允许出现的特殊字符（如斜杠、冒号等），并去除首尾空格
    const sanitized = match[1].trim().replace(/[\/\\:*?"<>|#]/g, '_');
    if (sanitized) {
      fileName = sanitized;
    }
  }

  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${fileName}.md`;
  a.click();
  URL.revokeObjectURL(url);
  showToast(`已导出 ${fileName}.md`);
}

/* ─── 示例文档 ─────────────────────────────────────────── */

const SAMPLE_MD = `# DevHelper Markdown 编辑器 ✨

欢迎使用 **DevHelper Markdown 编辑器**！支持 GitHub Flavored Markdown（GFM）扩展语法，以及 Mermaid 图表在线渲染。

---

## 基础排版

这是一段普通段落。支持 **粗体**、*斜体*、~~删除线~~ 和 \`行内代码\`。

> 💡 **提示**：在左侧编辑，右侧实时预览渲染结果。工具栏提供了常用 Markdown 快捷操作。

## 代码高亮

\`\`\`javascript
// 异步获取用户信息
async function fetchUser(id) {
  const res = await fetch(\`/api/users/\${id}\`);
  if (!res.ok) throw new Error(\`HTTP \${res.status}\`);
  return res.json();
}
\`\`\`

## 任务列表

- [x] 实现 Markdown 实时预览
- [x] 支持 Mermaid 图表渲染
- [x] 代码高亮（Highlight.js）
- [ ] 持久化草稿到本地
- [ ] AI 辅助文章润色

## 表格

| 工具名称 | 分类 | 状态 |
|---|---|---|
| JSON 格式化 | 数据处理 | ✅ 已安装 |
| Markdown 编辑器 | 开发工具 | 🆕 新功能 |
| 二维码生成 | 图形图像 | ✅ 已安装 |

## Mermaid 流程图

\`\`\`mermaid
flowchart LR
    A[用户输入 Markdown] --> B{语法解析}
    B -->|标准语法| C[marked.js 渲染]
    B -->|Mermaid 块| D[Mermaid.js 渲染]
    C --> E[HTML 预览]
    D --> E
    E --> F((实时展示))
\`\`\`

## Mermaid 时序图

\`\`\`mermaid
sequenceDiagram
    participant U as 用户
    participant E as 编辑器
    participant R as 渲染引擎

    U->>E: 输入 Markdown
    E->>R: 防抖 120ms 后触发解析
    R->>R: marked.parse()
    R->>R: Mermaid.render()
    R->>E: 返回 HTML
    E->>U: 更新预览区
\`\`\`
`;

/* ─── 工具函数 ─────────────────────────────────────────── */

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* ─── 持久化草稿 ────────────────────────────────────────── */

const STORAGE_KEY = 'devhelper-md-draft';

function saveDraft() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ [STORAGE_KEY]: mdInput.value }).catch(() => {});
    } else {
      localStorage.setItem(STORAGE_KEY, mdInput.value);
    }
  } catch {}
}

function loadDraft() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get([STORAGE_KEY], data => {
        if (data[STORAGE_KEY]) {
          mdInput.value = data[STORAGE_KEY];
          scheduleRender();
          updateLineCounter();
        }
      });
    } else {
      const draft = localStorage.getItem(STORAGE_KEY);
      if (draft) {
        mdInput.value = draft;
        scheduleRender();
        updateLineCounter();
      }
    }
  } catch {}
}

// 每 5s 自动保存草稿
let draftTimer = null;
function scheduleDraftSave() {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(saveDraft, 5000);
}

/* ─── 键盘快捷键 ───────────────────────────────────────── */

mdInput.addEventListener('keydown', e => {
  const ctrl = e.ctrlKey || e.metaKey;

  if (ctrl && e.key === 'b') { e.preventDefault(); wrapText('**', '**', '粗体文字'); }
  if (ctrl && e.key === 'i') { e.preventDefault(); wrapText('*', '*', '斜体文字'); }
  if (ctrl && e.key === '`') { e.preventDefault(); wrapText('`', '`', 'code'); }
  if (ctrl && e.key === 'k') { e.preventDefault(); wrapText('[', '](url)', '链接文字'); }

  // Tab 键缩进（插入两个空格，不丢失焦点）
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = mdInput.selectionStart;
    const end = mdInput.selectionEnd;
    if (e.shiftKey) {
      // 反向缩进：移除行首的 2 个空格
      const val = mdInput.value;
      const lineStart = val.lastIndexOf('\n', start - 1) + 1;
      if (val.substring(lineStart, lineStart + 2) === '  ') {
        mdInput.setRangeText('', lineStart, lineStart + 2, 'preserve');
      }
    } else {
      mdInput.setRangeText('  ', start, end, 'end');
    }
    scheduleRender();
    return;
  }

  // 回车：列表自动延续
  if (e.key === 'Enter') {
    const val = mdInput.value;
    const pos = mdInput.selectionStart;
    const lineStart = val.lastIndexOf('\n', pos - 1) + 1;
    const line = val.substring(lineStart, pos);

    const ulMatch = line.match(/^(\s*)([-*+] |\d+\. |- \[[ x]\] )/);
    if (ulMatch) {
      // 空列表项回车：退出列表
      if (line.trim() === ulMatch[2].trim()) {
        e.preventDefault();
        mdInput.setRangeText('\n', lineStart, pos, 'end');
        // 删除空列表标记
        const newPos = mdInput.selectionStart;
        mdInput.setRangeText('', lineStart, lineStart + ulMatch[0].length, 'end');
        scheduleRender();
      } else {
        // 继续列表
        e.preventDefault();
        const isOrdered = ulMatch[2].match(/^(\d+)\. /);
        if (isOrdered) {
          const nextNum = parseInt(isOrdered[1], 10) + 1;
          mdInput.setRangeText(`\n${ulMatch[1]}${nextNum}. `, pos, pos, 'end');
        } else {
          mdInput.setRangeText(`\n${ulMatch[1]}${ulMatch[2]}`, pos, pos, 'end');
        }
        scheduleRender();
      }
    }
  }
});

/* ─── 主初始化 ─────────────────────────────────────────── */

document.addEventListener('DOMContentLoaded', () => {
  // 导航栏
  createNavbar('Markdown 编辑器');

  // 加载草稿
  loadDraft();

  // 行号区域启用
  editorWrap.classList.add('show-lines');

  // 拖拽分隔条
  initResizer();

  // 编辑器事件监听
  mdInput.addEventListener('input', () => {
    scheduleRender();
    scheduleDraftSave();
    updateLineCounter();
    saveHistory(mdInput.value);
  });

  // ── 滚动同步事件绑定 ──────────────────────────
  mdInput.addEventListener('mouseenter', () => { activeScrollSource = 'editor'; });
  mdInput.addEventListener('touchstart', () => { activeScrollSource = 'editor'; }, { passive: true });
  mdInput.addEventListener('focus', () => { activeScrollSource = 'editor'; });

  mdPreview.addEventListener('mouseenter', () => { activeScrollSource = 'preview'; });
  mdPreview.addEventListener('touchstart', () => { activeScrollSource = 'preview'; }, { passive: true });

  mdInput.addEventListener('scroll', () => {
    // 始终保持行号同步滚动
    lineCounter.scrollTop = mdInput.scrollTop;

    if (currentView !== 'split') return;
    if (activeScrollSource !== 'editor') return;

    const editorScrollHeight = mdInput.scrollHeight - mdInput.clientHeight;
    if (editorScrollHeight <= 0) return;
    const pct = mdInput.scrollTop / editorScrollHeight;
    mdPreview.scrollTop = pct * (mdPreview.scrollHeight - mdPreview.clientHeight);
  });

  mdPreview.addEventListener('scroll', () => {
    if (currentView !== 'split') return;
    if (activeScrollSource !== 'preview') return;

    const previewScrollHeight = mdPreview.scrollHeight - mdPreview.clientHeight;
    if (previewScrollHeight <= 0) return;
    const pct = mdPreview.scrollTop / previewScrollHeight;
    mdInput.scrollTop = pct * (mdInput.scrollHeight - mdInput.clientHeight);
    
    // 保持行号同步滚动
    lineCounter.scrollTop = mdInput.scrollTop;
  });

  mdInput.addEventListener('keyup', updateCursorPos);
  mdInput.addEventListener('click', updateCursorPos);

  // ── 工具栏按钮绑定 ──────────────────────────────
  document.getElementById('tbBold').addEventListener('click', () => wrapText('**', '**', '粗体'));
  document.getElementById('tbItalic').addEventListener('click', () => wrapText('*', '*', '斜体'));
  document.getElementById('tbStrike').addEventListener('click', () => wrapText('~~', '~~', '删除线'));
  document.getElementById('tbCode').addEventListener('click', () => wrapText('`', '`', 'code'));

  document.getElementById('tbH1').addEventListener('click', () => prefixLine('# '));
  document.getElementById('tbH2').addEventListener('click', () => prefixLine('## '));
  document.getElementById('tbH3').addEventListener('click', () => prefixLine('### '));

  document.getElementById('tbQuote').addEventListener('click', () => prefixLine('> '));
  document.getElementById('tbCodeBlock').addEventListener('click', () => insertBlock('```javascript\n// 代码块\n```\n'));
  document.getElementById('tbUl').addEventListener('click', () => prefixLine('- '));
  document.getElementById('tbOl').addEventListener('click', () => prefixLine('1. '));
  document.getElementById('tbTask').addEventListener('click', () => prefixLine('- [ ] '));

  document.getElementById('tbTable').addEventListener('click', () => insertBlock(
    '\n| 列 1 | 列 2 | 列 3 |\n|---|---|---|\n| 内容 | 内容 | 内容 |\n'
  ));

  document.getElementById('tbMermaid').addEventListener('click', () => insertBlock(
    '\n```mermaid\nflowchart LR\n    A[开始] --> B{判断}\n    B -->|是| C[执行]\n    B -->|否| D[结束]\n```\n'
  ));

  document.getElementById('tbLink').addEventListener('click', () => wrapText('[', '](https://)', '链接文字'));
  document.getElementById('tbImg').addEventListener('click', () => wrapText('![', '](https://image-url)', '图片描述'));
  document.getElementById('tbHr').addEventListener('click', () => insertBlock('\n---\n'));

  document.getElementById('tbCopy').addEventListener('click', () => copyText(mdInput.value));
  document.getElementById('tbCopyHtml').addEventListener('click', () => {
    const html = mdPreview.innerHTML;
    copyText(html);
  });

  document.getElementById('tbImport').addEventListener('click', importMarkdown);
  document.getElementById('tbExport').addEventListener('click', exportMarkdown);

  document.getElementById('tbSample').addEventListener('click', () => {
    mdInput.value = SAMPLE_MD;
    scheduleRender();
    updateLineCounter();
    showToast('已载入示例文档', 'info');
  });

  document.getElementById('tbClear').addEventListener('click', () => {
    if (!mdInput.value.trim()) return;
    if (confirm('确认清空所有内容？')) {
      mdInput.value = '';
      mdPreview.innerHTML = '';
      mdPreview.appendChild(emptyHint);
      emptyHint.style.display = 'flex';
      updateStats('');
      updateLineCounter();
      saveDraft();
      showToast('已清空');
    }
  });

  document.getElementById('tbPrint').addEventListener('click', () => window.print());

  // 文件导入
  document.getElementById('fileImport').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      mdInput.value = ev.target.result;
      scheduleRender();
      updateLineCounter();
      showToast(`已导入 ${file.name}`, 'success');
    };
    reader.readAsText(file, 'utf-8');
    // 重置 input 以允许重复选同一文件
    e.target.value = '';
  });

  // 视图切换
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => setView(btn.dataset.view));
  });

  // 暗色模式变化时重新初始化 Mermaid 主题
  const themeObserver = new MutationObserver(() => {
    if (typeof window.mermaid !== 'undefined') {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      window.mermaid.initialize({
        startOnLoad: false,
        theme: isDark ? 'dark' : 'default',
        fontFamily: 'Inter, sans-serif',
        securityLevel: 'loose',
      });
      scheduleRender();
    }
  });
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  // 初始渲染
  scheduleRender();
  updateLineCounter();

  // 兼容自动载入示例（用于生成截图）
  if (new URLSearchParams(window.location.search).get('sample') === 'true') {
    mdInput.value = SAMPLE_MD;
    scheduleRender();
    updateLineCounter();
  }
});

